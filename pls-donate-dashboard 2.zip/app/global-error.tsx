"use client"

import { useEffect } from "react"
import { generateErrorReference } from "@/lib/error-monitoring"

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  const errorRef = error.digest || generateErrorReference()

  useEffect(() => {
    // Report the error to our API
    fetch("/api/system/server-error", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        referenceCode: errorRef,
        message: error.message || "Global error",
        stack: error.stack,
        context: {
          digest: error.digest,
          type: "global_error",
          timestamp: new Date().toISOString(),
        },
      }),
    }).catch(console.error)
  }, [error, errorRef])

  return (
    <html>
      <body>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            height: "100vh",
            padding: "20px",
            textAlign: "center",
            fontFamily: "system-ui, sans-serif",
          }}
        >
          <div
            style={{
              maxWidth: "500px",
              padding: "20px",
              borderRadius: "8px",
              boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
              backgroundColor: "white",
            }}
          >
            <h1 style={{ color: "#e11d48", marginBottom: "16px" }}>Something went wrong!</h1>
            <p style={{ marginBottom: "16px" }}>We've encountered a critical error. Our team has been notified.</p>
            <div
              style={{
                padding: "12px",
                backgroundColor: "#f9fafb",
                borderRadius: "6px",
                marginBottom: "16px",
              }}
            >
              <p style={{ fontWeight: "bold", marginBottom: "4px" }}>Error Reference:</p>
              <p style={{ color: "#e11d48" }}>{errorRef}</p>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <button
                onClick={() => (window.location.href = "/")}
                style={{
                  padding: "8px 16px",
                  border: "1px solid #d1d5db",
                  borderRadius: "6px",
                  backgroundColor: "white",
                  cursor: "pointer",
                }}
              >
                Go to Home
              </button>
              <button
                onClick={reset}
                style={{
                  padding: "8px 16px",
                  backgroundColor: "#3b82f6",
                  color: "white",
                  border: "none",
                  borderRadius: "6px",
                  cursor: "pointer",
                }}
              >
                Try Again
              </button>
            </div>
          </div>
        </div>
      </body>
    </html>
  )
}
