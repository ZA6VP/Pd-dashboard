import type React from "react"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { ErrorBoundary } from "@/components/error-boundary"
import { GlobalErrorHandler } from "@/components/global-error-handler"
import initializeSystem from "@/lib/init"

// Initialize system in a way that won't block rendering
let systemInitialized = false
let initializationPromise: Promise<boolean> | null = null

// Function to get initialization promise
export function getInitializationPromise() {
  if (!initializationPromise) {
    initializationPromise = initializeSystem().catch((error) => {
      console.error("Failed to initialize system:", error)
      return true // Return true to allow the application to continue
    })
  }
  return initializationPromise
}

// Initialize system but don't block rendering
if (!systemInitialized && typeof window === "undefined") {
  systemInitialized = true
  getInitializationPromise()
}

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "PLS DONATE Dashboard",
  description: "Admin dashboard for PLS DONATE games",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Add meta tags for security */}
        <meta name="referrer" content="strict-origin-when-cross-origin" />
        <meta
          httpEquiv="Content-Security-Policy"
          content="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self' https:;"
        />
        <meta httpEquiv="X-Content-Type-Options" content="nosniff" />
        <meta httpEquiv="X-Frame-Options" content="DENY" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </head>
      <body className={inter.className}>
        <ErrorBoundary>
          <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
            <GlobalErrorHandler />
            {children}
          </ThemeProvider>
        </ErrorBoundary>
      </body>
    </html>
  )
}
