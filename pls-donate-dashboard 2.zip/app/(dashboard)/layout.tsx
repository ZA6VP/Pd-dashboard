import type { ReactNode } from "react"
import { Sidebar } from "@/components/sidebar"
import { getSession } from "@/lib/auth"
import { redirect } from "next/navigation"

export default async function DashboardLayout({
  children,
}: {
  children: ReactNode
}) {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar user={{ username: session.username as string, role: session.role as string }} />
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  )
}
