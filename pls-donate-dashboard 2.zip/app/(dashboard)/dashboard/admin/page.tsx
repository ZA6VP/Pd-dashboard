import { getSession } from "@/lib/auth"
import { redirect } from "next/navigation"
import { hasPermission } from "@/lib/admin-roles"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AdminUserManager } from "@/components/admin-user-manager"
import { MaintenanceToggle } from "@/components/maintenance-toggle"

export default async function AdminPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  // Check if user has permission to manage admins or toggle maintenance
  const canManageAdmins = hasPermission(session.role, "canManageAdmins")
  const canToggleMaintenance = hasPermission(session.role, "canToggleMaintenance")

  if (!canManageAdmins && !canToggleMaintenance) {
    redirect("/dashboard")
  }

  return (
    <div className="p-6 animate-fade-in">
      <h1 className="text-3xl font-bold mb-2">Admin Management</h1>
      <p className="text-gray-500 mb-6">Manage admin users and system settings</p>

      <Tabs defaultValue={canManageAdmins ? "users" : "maintenance"} className="animate-slide-up">
        <TabsList className="mb-4">
          {canManageAdmins && <TabsTrigger value="users">Admin Users</TabsTrigger>}
          {canToggleMaintenance && <TabsTrigger value="maintenance">Maintenance Mode</TabsTrigger>}
        </TabsList>

        {canManageAdmins && (
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>Admin User Management</CardTitle>
                <CardDescription>Create, edit, and manage admin users</CardDescription>
              </CardHeader>
              <CardContent>
                <AdminUserManager />
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {canToggleMaintenance && (
          <TabsContent value="maintenance">
            <Card>
              <CardHeader>
                <CardTitle>Maintenance Mode</CardTitle>
                <CardDescription>Toggle system maintenance mode</CardDescription>
              </CardHeader>
              <CardContent>
                <MaintenanceToggle />
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  )
}
