import { getSession } from "@/lib/auth"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AuditLogViewer } from "@/components/audit-log-viewer"

export default async function AuditLogPage() {
  const session = await getSession()

  return (
    <div className="p-6 animate-fade-in">
      <h1 className="text-3xl font-bold mb-2">Audit Log</h1>
      <p className="text-gray-500 mb-6">Track all actions performed in the dashboard</p>

      <Card className="animate-slide-up">
        <CardHeader>
          <CardTitle>Activity Log</CardTitle>
          <CardDescription>A chronological record of all actions performed by administrators</CardDescription>
        </CardHeader>
        <CardContent>
          <AuditLogViewer />
        </CardContent>
      </Card>
    </div>
  )
}
