import { getSession } from "@/lib/auth"
import { redirect } from "next/navigation"
import NotificationDashboard from "@/components/notification-dashboard"

export default async function NotificationsPage() {
  try {
    // Check if user is logged in
    const session = await getSession()

    if (!session) {
      redirect("/login")
    }

    return (
      <div className="container mx-auto p-4">
        <h1 className="mb-6 text-2xl font-bold">Notifications</h1>
        <NotificationDashboard />
      </div>
    )
  } catch (error) {
    console.error("Notifications page error:", error)

    // Fallback UI in case of error
    return (
      <div className="container mx-auto p-4">
        <h1 className="mb-6 text-2xl font-bold">Notifications</h1>
        <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-red-800">
          <p>There was an error loading the notifications. Please try again later.</p>
        </div>
      </div>
    )
  }
}
