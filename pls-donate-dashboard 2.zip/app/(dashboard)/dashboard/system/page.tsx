import { getSession } from "@/lib/auth"
import { redirect } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SystemStatusPanel } from "@/components/system-status-panel"
import { ErrorLogViewer } from "@/components/error-log-viewer"
import { BackupManager } from "@/components/backup-manager"
import { PerformanceDashboard } from "@/components/performance-dashboard"
import { ActivityLogViewer } from "@/components/activity-log-viewer"

export default async function SystemPage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  return (
    <div className="container mx-auto py-6 space-y-6">
      <h1 className="text-3xl font-bold">System Status</h1>
      <p className="text-gray-500">Monitor and manage system health, performance, and maintenance</p>

      <Tabs defaultValue="status">
        <TabsList className="grid grid-cols-5 w-full max-w-3xl">
          <TabsTrigger value="status">Status</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="errors">Errors</TabsTrigger>
          <TabsTrigger value="backups">Backups</TabsTrigger>
        </TabsList>

        <TabsContent value="status" className="mt-6">
          <SystemStatusPanel />
        </TabsContent>

        <TabsContent value="performance" className="mt-6">
          <PerformanceDashboard />
        </TabsContent>

        <TabsContent value="activity" className="mt-6">
          <ActivityLogViewer />
        </TabsContent>

        <TabsContent value="errors" className="mt-6">
          <ErrorLogViewer />
        </TabsContent>

        <TabsContent value="backups" className="mt-6">
          <BackupManager />
        </TabsContent>
      </Tabs>
    </div>
  )
}
