import { getSession } from "@/lib/auth"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, ExternalLink, Users } from "lucide-react"
import Link from "next/link"
import { StoreDataTable } from "@/components/store-data-table"
import { connectToDatabase } from "@/lib/db"
import { Game, Store } from "@/lib/models"

export default async function GamePage({
  params,
}: {
  params: { placeId: string }
}) {
  const session = await getSession()
  const placeId = Number(params.placeId)

  // Fetch game and stores from the database
  await connectToDatabase()
  const game = await Game.findOne({ placeId })
  const stores = await Store.find({ gameId: placeId }).distinct("storeName")

  // Fetch the first store data for initial tab
  let initialStoreData = {}
  if (stores.length > 0) {
    const storeDoc = await Store.findOne({ gameId: placeId, storeName: stores[0] })
    if (storeDoc) {
      initialStoreData = { [stores[0]]: storeDoc.data }
    }
  }

  if (!game) {
    return (
      <div className="p-6">
        <h1 className="text-3xl font-bold mb-6">Game Not Found</h1>
        <Button asChild>
          <Link href="/dashboard">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <Button asChild variant="outline" size="sm">
          <Link href="/dashboard">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">{game.name}</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Place ID</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{game.placeId}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Active Players</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center">
            <Users className="w-5 h-5 mr-2 text-blue-500" />
            <p className="text-2xl font-bold">{game.activePlayers.toLocaleString()}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Last Updated</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{new Date(game.lastUpdated).toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>

      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Data Stores</h2>
          <Button asChild variant="outline" size="sm">
            <a href={`https://www.roblox.com/games/${game.placeId}`} target="_blank" rel="noopener noreferrer">
              <ExternalLink className="w-4 h-4 mr-1" />
              Open in Roblox
            </a>
          </Button>
        </div>

        {stores.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-gray-500">No data stores available yet</p>
              <p className="text-sm text-gray-400 mt-2">
                Data stores will appear here once the game pushes data using the DashboardConnector ModuleScript.
              </p>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue={stores[0]}>
            <TabsList className="mb-4">
              {stores.map((store) => (
                <TabsTrigger key={store} value={store}>
                  {store}
                </TabsTrigger>
              ))}
            </TabsList>

            {stores.map((store, index) => (
              <TabsContent key={store} value={store}>
                <Card>
                  <CardHeader>
                    <CardTitle>{store}</CardTitle>
                    <CardDescription>Data from the {store} DataStore</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <StoreDataTable
                      storeId={store}
                      placeId={placeId}
                      initialData={index === 0 ? initialStoreData[store] : undefined}
                    />
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        )}
      </div>
    </div>
  )
}
