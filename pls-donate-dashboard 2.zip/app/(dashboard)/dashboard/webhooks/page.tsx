import { getSession } from "@/lib/auth"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SlackWebhookConfig } from "@/components/slack-webhook-config"
import { DiscordWebhookConfig } from "@/components/discord-webhook-config"
import { hasPermission } from "@/lib/admin-roles"

export default async function WebhooksPage() {
  const session = await getSession()

  if (!session) {
    return <div>Not authenticated</div>
  }

  // Check if user has permission to manage webhooks
  const canManageWebhooks = hasPermission(session.role, "canManageWebhooks")

  if (!canManageWebhooks) {
    return (
      <div className="p-6">
        <h1 className="text-3xl font-bold mb-6">Webhooks</h1>
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 rounded-md p-4">
          You do not have permission to manage webhooks.
        </div>
      </div>
    )
  }

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Webhooks</h1>

      <Tabs defaultValue="discord" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="discord">Discord</TabsTrigger>
          <TabsTrigger value="slack">Slack</TabsTrigger>
        </TabsList>

        <TabsContent value="discord">
          <DiscordWebhookConfig />
        </TabsContent>

        <TabsContent value="slack">
          <SlackWebhookConfig />
        </TabsContent>
      </Tabs>
    </div>
  )
}
