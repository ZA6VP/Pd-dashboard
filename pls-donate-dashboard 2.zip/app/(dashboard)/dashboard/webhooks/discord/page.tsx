"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { AlertCircle, CheckCircle2, Send } from "lucide-react"

export default function DiscordWebhookPage() {
  const [webhookUrl, setWebhookUrl] = useState("")
  const [webhookUsername, setWebhookUsername] = useState("PLS DONATE Dashboard")
  const [webhookAvatar, setWebhookAvatar] = useState("")
  const [webhookEnabled, setWebhookEnabled] = useState(false)
  const [testMessage, setTestMessage] = useState("This is a test message from PLS DONATE Dashboard")
  const [loading, setLoading] = useState(false)
  const [configLoading, setConfigLoading] = useState(true)

  // Load webhook configuration
  useEffect(() => {
    async function loadWebhookConfig() {
      try {
        const response = await fetch("/api/webhooks/discord/config")
        if (response.ok) {
          const data = await response.json()
          setWebhookUrl(data.url || "")
          setWebhookUsername(data.username || "PLS DONATE Dashboard")
          setWebhookAvatar(data.avatarUrl || "")
          setWebhookEnabled(data.enabled || false)
        }
      } catch (error) {
        console.error("Failed to load webhook config:", error)
        toast({
          title: "Error",
          description: "Failed to load webhook configuration",
          variant: "destructive",
        })
      } finally {
        setConfigLoading(false)
      }
    }

    loadWebhookConfig()
  }, [])

  // Save webhook configuration
  const saveWebhookConfig = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/webhooks/discord/config", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          url: webhookUrl,
          username: webhookUsername,
          avatarUrl: webhookAvatar,
          enabled: webhookEnabled,
        }),
      })

      if (response.ok) {
        toast({
          title: "Success",
          description: "Webhook configuration saved successfully",
        })
      } else {
        const error = await response.json()
        throw new Error(error.message || "Failed to save webhook configuration")
      }
    } catch (error) {
      console.error("Failed to save webhook config:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to save webhook configuration",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Test webhook
  const testWebhook = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/webhooks/discord/test", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: testMessage,
        }),
      })

      if (response.ok) {
        toast({
          title: "Success",
          description: "Test message sent successfully",
        })
      } else {
        const error = await response.json()
        throw new Error(error.message || "Failed to send test message")
      }
    } catch (error) {
      console.error("Failed to test webhook:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to send test message",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Discord Webhook Configuration</h1>

      <Tabs defaultValue="config">
        <TabsList className="mb-4">
          <TabsTrigger value="config">Configuration</TabsTrigger>
          <TabsTrigger value="test">Test Webhook</TabsTrigger>
          <TabsTrigger value="events">Event Types</TabsTrigger>
        </TabsList>

        <TabsContent value="config">
          <Card>
            <CardHeader>
              <CardTitle>Discord Webhook Settings</CardTitle>
              <CardDescription>
                Configure your Discord webhook to receive notifications from the dashboard
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="webhook-url">Webhook URL</Label>
                <Input
                  id="webhook-url"
                  placeholder="https://discord.com/api/webhooks/..."
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                />
                <p className="text-sm text-muted-foreground">
                  You can create a webhook URL in your Discord server settings
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="webhook-username">Bot Username</Label>
                <Input
                  id="webhook-username"
                  placeholder="PLS DONATE Dashboard"
                  value={webhookUsername}
                  onChange={(e) => setWebhookUsername(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="webhook-avatar">Bot Avatar URL (optional)</Label>
                <Input
                  id="webhook-avatar"
                  placeholder="https://example.com/avatar.png"
                  value={webhookAvatar}
                  onChange={(e) => setWebhookAvatar(e.target.value)}
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="webhook-enabled" checked={webhookEnabled} onCheckedChange={setWebhookEnabled} />
                <Label htmlFor="webhook-enabled">Enable Discord Notifications</Label>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveWebhookConfig} disabled={loading}>
                {loading ? "Saving..." : "Save Configuration"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="test">
          <Card>
            <CardHeader>
              <CardTitle>Test Discord Webhook</CardTitle>
              <CardDescription>Send a test message to verify your webhook is working correctly</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="test-message">Test Message</Label>
                <Textarea
                  id="test-message"
                  placeholder="Enter a test message"
                  value={testMessage}
                  onChange={(e) => setTestMessage(e.target.value)}
                  rows={4}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={testWebhook} disabled={loading || !webhookEnabled || !webhookUrl}>
                <Send className="mr-2 h-4 w-4" />
                {loading ? "Sending..." : "Send Test Message"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="events">
          <Card>
            <CardHeader>
              <CardTitle>Event Types</CardTitle>
              <CardDescription>The following events will be sent to your Discord webhook</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-2">
                  <AlertCircle className="h-5 w-5 text-red-500 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Errors</h3>
                    <p className="text-sm text-muted-foreground">Server-side errors and exceptions</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2">
                  <AlertCircle className="h-5 w-5 text-orange-500 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Console Errors</h3>
                    <p className="text-sm text-muted-foreground">
                      Client-side JavaScript errors and unhandled rejections
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-blue-500 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Stats Changes</h3>
                    <p className="text-sm text-muted-foreground">Significant changes in system statistics</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5" />
                  <div>
                    <h3 className="font-medium">System Events</h3>
                    <p className="text-sm text-muted-foreground">
                      Important system events like startup, shutdown, and maintenance
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-2">
                  <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Security Alerts</h3>
                    <p className="text-sm text-muted-foreground">
                      Security-related events like login attempts and suspicious activity
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-2">
                  <AlertCircle className="h-5 w-5 text-pink-500 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Performance Alerts</h3>
                    <p className="text-sm text-muted-foreground">Performance issues and threshold violations</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-purple-500 mt-0.5" />
                  <div>
                    <h3 className="font-medium">User Activity</h3>
                    <p className="text-sm text-muted-foreground">
                      Important user actions like logins and settings changes
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-teal-500 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Game Updates</h3>
                    <p className="text-sm text-muted-foreground">Game data updates and player count changes</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-emerald-500 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Donations</h3>
                    <p className="text-sm text-muted-foreground">New donations and significant donation events</p>
                  </div>
                </div>

                <div className="flex items-start space-x-2">
                  <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
                  <div>
                    <h3 className="font-medium">Bans</h3>
                    <p className="text-sm text-muted-foreground">User ban events and moderation actions</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
