import { getSession } from "@/lib/auth"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ThemeSettings } from "@/components/theme-settings"
import { ABTestSettings } from "@/components/ab-test-settings"

export default async function ConfigurationPage() {
  const session = await getSession()

  // Check if user is SuperAdmin
  const isSuperAdmin = session?.role === "SuperAdmin"

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">Configuration</h1>

      <Tabs defaultValue="themes">
        <TabsList className="mb-4">
          <TabsTrigger value="themes">Themes</TabsTrigger>
          <TabsTrigger value="ab-tests" disabled={!isSuperAdmin}>
            AB Tests
          </TabsTrigger>
        </TabsList>

        <TabsContent value="themes">
          <Card>
            <CardHeader>
              <CardTitle>Theme Settings</CardTitle>
              <CardDescription>Customize the appearance of the dashboard</CardDescription>
            </CardHeader>
            <CardContent>
              <ThemeSettings />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ab-tests">
          <Card>
            <CardHeader>
              <CardTitle>A/B Test Settings</CardTitle>
              <CardDescription>Configure A/B tests for your games</CardDescription>
            </CardHeader>
            <CardContent>
              {isSuperAdmin ? (
                <ABTestSettings />
              ) : (
                <p className="text-gray-500">You need SuperAdmin permissions to access this section.</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
