import { getSession } from "@/lib/auth"
import { redirect } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

export default async function DashboardPage() {
  try {
    // Check if user is logged in
    const session = await getSession()

    if (!session) {
      redirect("/login")
    }

    // Render the dashboard
    return (
      <div className="container mx-auto p-4">
        <h1 className="mb-6 text-2xl font-bold">Dashboard</h1>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Welcome, {session.username}</CardTitle>
              <CardDescription>Role: {session.role}</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Use the sidebar to navigate to different sections of the dashboard.</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Stats</CardTitle>
              <CardDescription>Overview of your games</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Loading stats...</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Latest events</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Loading activity...</p>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  } catch (error) {
    console.error("Dashboard page error:", error)

    // Fallback UI in case of error
    return (
      <div className="container mx-auto p-4">
        <h1 className="mb-6 text-2xl font-bold">Dashboard</h1>

        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            There was an error loading the dashboard. Some features may be unavailable.
          </AlertDescription>
        </Alert>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle>Welcome</CardTitle>
              <CardDescription>PLS DONATE Dashboard</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Use the sidebar to navigate to different sections of the dashboard.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }
}
