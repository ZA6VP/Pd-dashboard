import { getSession } from "@/lib/auth"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LeaderboardTable } from "@/components/leaderboard-table"

export default async function LeaderboardsPage() {
  const session = await getSession()

  return (
    <div className="p-6 animate-fade-in">
      <h1 className="text-3xl font-bold mb-2">Leaderboards</h1>
      <p className="text-gray-500 mb-6">View top donors and donation statistics</p>

      <Tabs defaultValue="donors" className="animate-slide-up">
        <TabsList className="mb-4">
          <TabsTrigger value="donors">Top Donors</TabsTrigger>
          <TabsTrigger value="recipients">Top Recipients</TabsTrigger>
          <TabsTrigger value="games">Game Statistics</TabsTrigger>
        </TabsList>

        <TabsContent value="donors">
          <Card>
            <CardHeader>
              <CardTitle>Top Donors</CardTitle>
              <CardDescription>Players who have donated the most Robux across all games</CardDescription>
            </CardHeader>
            <CardContent>
              <LeaderboardTable type="donors" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recipients">
          <Card>
            <CardHeader>
              <CardTitle>Top Recipients</CardTitle>
              <CardDescription>Players who have received the most donations</CardDescription>
            </CardHeader>
            <CardContent>
              <LeaderboardTable type="recipients" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="games">
          <Card>
            <CardHeader>
              <CardTitle>Game Statistics</CardTitle>
              <CardDescription>Donation statistics by game</CardDescription>
            </CardHeader>
            <CardContent>
              <LeaderboardTable type="games" />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
