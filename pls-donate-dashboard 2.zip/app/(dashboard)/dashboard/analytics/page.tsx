import { getSession } from "@/lib/auth"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AnalyticsDashboard } from "@/components/analytics-dashboard"

export default async function AnalyticsPage() {
  const session = await getSession()

  return (
    <div className="p-6 animate-fade-in">
      <h1 className="text-3xl font-bold mb-2">Analytics</h1>
      <p className="text-gray-500 mb-6">Detailed statistics and insights for your games</p>

      <Tabs defaultValue="overview" className="animate-slide-up">
        <TabsList className="mb-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="donations">Donations</TabsTrigger>
          <TabsTrigger value="players">Players</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <AnalyticsDashboard type="overview" />
        </TabsContent>

        <TabsContent value="donations">
          <AnalyticsDashboard type="donations" />
        </TabsContent>

        <TabsContent value="players">
          <AnalyticsDashboard type="players" />
        </TabsContent>

        <TabsContent value="performance">
          <AnalyticsDashboard type="performance" />
        </TabsContent>
      </Tabs>
    </div>
  )
}
