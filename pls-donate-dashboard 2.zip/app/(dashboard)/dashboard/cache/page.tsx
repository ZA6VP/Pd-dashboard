import { getSession } from "@/lib/auth"
import { redirect } from "next/navigation"
import { hasPermission } from "@/lib/admin-roles"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CacheManager } from "@/components/cache-manager"

export default async function CachePage() {
  const session = await getSession()

  if (!session) {
    redirect("/login")
  }

  // Check if user has permission to manage cache
  const canManageCache = hasPermission(session.role, "canManageCache")

  if (!canManageCache) {
    redirect("/dashboard")
  }

  return (
    <div className="p-6 animate-fade-in">
      <h1 className="text-3xl font-bold mb-2">Cache Management</h1>
      <p className="text-gray-500 mb-6">View and clear application cache</p>

      <Card className="animate-slide-up">
        <CardHeader>
          <CardTitle>Redis Cache</CardTitle>
          <CardDescription>Manage cached data to improve application performance</CardDescription>
        </CardHeader>
        <CardContent>
          <CacheManager />
        </CardContent>
      </Card>
    </div>
  )
}
