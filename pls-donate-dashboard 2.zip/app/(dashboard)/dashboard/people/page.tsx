import { getSession } from "@/lib/auth"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { UserSearch } from "@/components/user-search"
import { UserBanForm } from "@/components/user-ban-form"

export default async function PeoplePage() {
  const session = await getSession()

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">People Management</h1>

      <Tabs defaultValue="find">
        <TabsList className="mb-4">
          <TabsTrigger value="find">Find User</TabsTrigger>
          <TabsTrigger value="blacklist">Blacklist</TabsTrigger>
        </TabsList>

        <TabsContent value="find">
          <Card>
            <CardHeader>
              <CardTitle>Find User</CardTitle>
              <CardDescription>Search for a user by username or user ID</CardDescription>
            </CardHeader>
            <CardContent>
              <UserSearch />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="blacklist">
          <Card>
            <CardHeader>
              <CardTitle>Blacklist Management</CardTitle>
              <CardDescription>Ban users from accessing the games</CardDescription>
            </CardHeader>
            <CardContent>
              <UserBanForm />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
