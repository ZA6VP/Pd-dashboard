import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { logActivity } from "@/lib/activity-logger"
import { sendBanToDiscord } from "@/lib/discord-webhook"

export async function POST(request: Request) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse request body
    const data = await request.json()
    const { placeId, userId, reason, duration } = data

    if (!placeId || !userId || !reason) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // In a real implementation, you would:
    // 1. Store the ban in your database
    // 2. Notify the game server via MessagingService or HttpService

    // For this example, we'll just simulate a successful ban
    const ban = {
      id: `ban_${Date.now()}`,
      placeId,
      userId,
      reason,
      duration: duration || "permanent",
      bannedBy: session.user.name,
      createdAt: new Date().toISOString(),
      expiresAt: duration ? new Date(Date.now() + Number.parseInt(duration) * 1000).toISOString() : null,
    }

    // Log the activity
    await logActivity(
      "ban_user",
      session.user.name,
      {
        placeId,
        userId,
        reason,
        duration: duration || "permanent",
      },
      request,
    )

    // Send ban notification to Discord
    await sendBanToDiscord(
      userId.toString(),
      reason,
      duration ? `${duration} seconds` : "Permanent",
      session.user.name,
      placeId,
      `Game ${placeId}`, // In a real implementation, you would get the game name
    )

    return NextResponse.json({ success: true, ban })
  } catch (error) {
    console.error("Error banning user:", error)
    return NextResponse.json({ error: "Failed to ban user" }, { status: 500 })
  }
}
