import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { connectToDatabase } from "@/lib/db"
import { Ban, Game } from "@/lib/models"
import { withCache, cacheKey, CACHE_TTL } from "@/lib/redis"

export async function GET() {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    // Use Redis cache
    const bansWithGameNames = await withCache(cacheKey.bans(), CACHE_TTL.BANS, async () => {
      await connectToDatabase()

      // Get recent bans
      const bans = await Ban.find({}).sort({ createdAt: -1 }).limit(10)

      // Get game names for the bans
      const gameIds = [...new Set(bans.map((ban) => ban.gameId))]
      const games = await Game.find({ placeId: { $in: gameIds } })

      // Map game names to bans
      const gameMap = new Map(games.map((game) => [game.placeId, game.name]))

      return bans.map((ban) => {
        const banObj = ban.toObject()
        return {
          ...banObj,
          gameName: gameMap.get(ban.gameId) || `Game ${ban.gameId}`,
        }
      })
    })

    return NextResponse.json(bansWithGameNames)
  } catch (error) {
    console.error("Error fetching recent bans:", error)
    return NextResponse.json({ error: "Failed to fetch recent bans" }, { status: 500 })
  }
}
