import { type NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { markAllNotificationsAsRead } from "@/lib/notification-system"

export async function POST(request: NextRequest) {
  try {
    const session = await getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const success = await markAllNotificationsAsRead(session.username)

    return NextResponse.json({ success })
  } catch (error) {
    console.error("POST /api/notifications/read-all error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
