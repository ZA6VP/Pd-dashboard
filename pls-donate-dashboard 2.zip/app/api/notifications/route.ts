import { type NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getUserNotifications } from "@/lib/notification-system"

export async function GET(request: NextRequest) {
  try {
    const session = await getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Parse query parameters
    const searchParams = request.nextUrl.searchParams
    const includeRead = searchParams.get("includeRead") === "true"

    // Get notifications with minimal options to avoid errors
    const { notifications, total } = await getUserNotifications(session.username, {
      includeRead,
    })

    return NextResponse.json({
      notifications,
      total,
    })
  } catch (error) {
    console.error("GET /api/notifications error:", error)
    return NextResponse.json({ error: "Internal server error", notifications: [] }, { status: 500 })
  }
}
