import { type NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { markNotificationAsRead } from "@/lib/notification-system"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const id = params.id

    const success = await markNotificationAsRead(id)

    if (!success) {
      return NextResponse.json({ error: "Notification not found" }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("POST /api/notifications/[id]/read error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
