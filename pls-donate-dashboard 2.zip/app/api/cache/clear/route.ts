import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { hasPermission } from "@/lib/admin-roles"
import redis from "@/lib/redis"

export async function POST(request: Request) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  // Check if user has permission to manage cache
  if (!hasPermission(session.role, "canManageCache")) {
    return NextResponse.json({ error: "Insufficient permissions" }, { status: 403 })
  }

  try {
    const { pattern } = await request.json()

    if (!pattern) {
      return NextResponse.json({ error: "Pattern is required" }, { status: 400 })
    }

    // Get keys matching pattern
    const keys = await redis.keys(pattern)

    if (keys.length === 0) {
      return NextResponse.json({ clearedKeys: 0 })
    }

    // Delete keys
    await redis.del(...keys)

    // Log the action
    await redis.lpush(
      "system:logs",
      JSON.stringify({
        action: "cache_cleared",
        username: session.username,
        timestamp: new Date().toISOString(),
        details: { pattern, clearedKeys: keys.length },
      }),
    )

    return NextResponse.json({ clearedKeys: keys.length })
  } catch (error) {
    console.error("Error clearing cache:", error)
    return NextResponse.json({ error: "Failed to clear cache" }, { status: 500 })
  }
}
