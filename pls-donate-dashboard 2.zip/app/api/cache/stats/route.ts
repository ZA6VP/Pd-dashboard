import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { hasPermission } from "@/lib/admin-roles"
import redis from "@/lib/redis"

export async function GET() {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  // Check if user has permission to manage cache
  if (!hasPermission(session.role, "canManageCache")) {
    return NextResponse.json({ error: "Insufficient permissions" }, { status: 403 })
  }

  try {
    // Get all keys
    const keys = await redis.keys("*")

    // Group keys by prefix
    const keysByPrefix: Record<string, number> = {}

    for (const key of keys) {
      const prefix = key.split(":")[0]

      if (!keysByPrefix[prefix]) {
        keysByPrefix[prefix] = 0
      }

      keysByPrefix[prefix]++
    }

    // Get memory usage (this is a mock since Upstash Redis REST API doesn't support INFO command)
    // In a real implementation, you would use the INFO command to get memory usage
    const memoryUsage = `${(keys.length * 0.5).toFixed(2)} MB`

    return NextResponse.json({
      totalKeys: keys.length,
      keysByPrefix,
      memoryUsage,
    })
  } catch (error) {
    console.error("Error getting cache statistics:", error)
    return NextResponse.json({ error: "Failed to get cache statistics" }, { status: 500 })
  }
}
