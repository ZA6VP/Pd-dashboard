import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import {
  getDailyActiveUsers,
  getDailyDonations,
  getDailyDonationCount,
  getTopDonors,
  getTopRecipients,
} from "@/lib/analytics"

export async function GET(request: Request) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  // Check if user is SuperAdmin or Moderator
  if (session.role !== "SuperAdmin" && session.role !== "Moderator") {
    return NextResponse.json({ error: "Insufficient permissions" }, { status: 403 })
  }

  try {
    const url = new URL(request.url)
    const date = url.searchParams.get("date") || undefined

    // Get analytics data
    const [activeUsers, totalDonations, donationCount, topDonors, topRecipients] = await Promise.all([
      getDailyActiveUsers(date),
      getDailyDonations(date),
      getDailyDonationCount(date),
      getTopDonors(date, 10),
      getTopRecipients(date, 10),
    ])

    return NextResponse.json({
      activeUsers,
      totalDonations,
      donationCount,
      averageDonation: donationCount > 0 ? totalDonations / donationCount : 0,
      topDonors,
      topRecipients,
      date: date || new Date().toISOString().split("T")[0],
    })
  } catch (error) {
    console.error("Error fetching analytics data:", error)
    return NextResponse.json({ error: "Failed to fetch analytics data" }, { status: 500 })
  }
}
