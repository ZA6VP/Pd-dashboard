import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { connectToDatabase } from "@/lib/db"
import { Store } from "@/lib/models"

export async function GET(request: Request, { params }: { params: { placeId: string } }) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const placeId = Number(params.placeId)

  try {
    await connectToDatabase()
    const stores = await Store.find({ gameId: placeId }).distinct("storeName")

    if (!stores || stores.length === 0) {
      return NextResponse.json([])
    }

    return NextResponse.json(stores)
  } catch (error) {
    console.error(`Error fetching stores for game ${placeId}:`, error)
    return NextResponse.json({ error: "Failed to fetch stores" }, { status: 500 })
  }
}
