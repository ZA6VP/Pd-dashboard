import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { connectToDatabase } from "@/lib/db"
import { Store } from "@/lib/models"
import { withCache, cacheKey, CACHE_TTL } from "@/lib/redis"

export async function GET(request: Request, { params }: { params: { placeId: string; storeName: string } }) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { placeId, storeName } = params
  const gameId = Number(placeId)

  try {
    // Use Redis cache
    const storeData = await withCache(cacheKey.store(gameId, storeName), CACHE_TTL.STORE, async () => {
      await connectToDatabase()
      const store = await Store.findOne({ gameId, storeName })

      if (!store) {
        throw new Error("Store not found")
      }

      return store.data
    })

    return NextResponse.json(storeData)
  } catch (error) {
    console.error(`Error fetching store ${storeName} for game ${placeId}:`, error)
    if (error.message === "Store not found") {
      return NextResponse.json({ error: "Store not found" }, { status: 404 })
    }
    return NextResponse.json({ error: "Failed to fetch store data" }, { status: 500 })
  }
}
