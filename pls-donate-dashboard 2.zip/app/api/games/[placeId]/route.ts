import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { connectToDatabase } from "@/lib/db"
import { Game, Store } from "@/lib/models"
import { withCache, cacheKey, CACHE_TTL } from "@/lib/redis"

export async function GET(request: Request, { params }: { params: { placeId: string } }) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const placeId = Number(params.placeId)

  try {
    // Use Redis cache
    const gameData = await withCache(cacheKey.game(placeId), CACHE_TTL.GAME, async () => {
      await connectToDatabase()
      const game = await Game.findOne({ placeId })

      if (!game) {
        throw new Error("Game not found")
      }

      // Get store names for this game
      const stores = await Store.find({ gameId: placeId }).distinct("storeName")

      return {
        ...game.toObject(),
        stores,
      }
    })

    return NextResponse.json(gameData)
  } catch (error) {
    console.error(`Error fetching game ${placeId}:`, error)
    if (error.message === "Game not found") {
      return NextResponse.json({ error: "Game not found" }, { status: 404 })
    }
    return NextResponse.json({ error: "Failed to fetch game" }, { status: 500 })
  }
}
