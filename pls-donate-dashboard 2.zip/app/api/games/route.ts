import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { connectToDatabase } from "@/lib/db"
import { Game } from "@/lib/models"
import { withCache, cacheKey, CACHE_TTL } from "@/lib/redis"

export async function GET() {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    // Use Redis cache
    const games = await withCache(cacheKey.games(), CACHE_TTL.GAMES, async () => {
      await connectToDatabase()
      const games = await Game.find({}).sort({ lastUpdated: -1 })
      return games
    })

    return NextResponse.json(games)
  } catch (error) {
    console.error("Error fetching games:", error)
    return NextResponse.json({ error: "Failed to fetch games" }, { status: 500 })
  }
}
