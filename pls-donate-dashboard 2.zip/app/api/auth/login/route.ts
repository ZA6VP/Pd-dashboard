import { type NextRequest, NextResponse } from "next/server"
import { authenticateUser, createSession } from "@/lib/auth"
import { logError } from "@/lib/error-monitoring"
import { createNotification } from "@/lib/notification-system"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { username, password } = body

    if (!username || !password) {
      return NextResponse.json({ error: "Username and password are required" }, { status: 400 })
    }

    // Authenticate the user
    const { success, role } = await authenticateUser(username, password)

    if (!success) {
      // Log failed login attempt
      console.warn(`Failed login attempt for user: ${username}`)

      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 })
    }

    // Create a session
    const token = await createSession(username, role)

    // Create a response
    const response = NextResponse.json({ success: true, role })

    // Set the session cookie
    response.cookies.set({
      name: "session",
      value: token,
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      path: "/",
    })

    // Create a login notification
    try {
      await createNotification(
        "security",
        "medium",
        "Successful Login",
        `User ${username} logged in successfully.`,
        username,
        {
          ip: request.headers.get("x-forwarded-for") || "unknown",
          userAgent: request.headers.get("user-agent") || "unknown",
        },
      )
    } catch (notificationError) {
      console.error("Failed to create login notification:", notificationError)
      // Continue anyway
    }

    return response
  } catch (error) {
    logError(error, { context: "POST /api/auth/login" })
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
