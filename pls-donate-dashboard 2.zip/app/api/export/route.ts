import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { createExportJob, getExportJobs } from "@/lib/data-exporter"
import { logActivity } from "@/lib/activity-logger"

export async function POST(request: Request) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { type, format, parameters } = await request.json()

    // Create export job
    const jobId = await createExportJob(type, format, parameters, session.username)

    // Log activity
    await logActivity("export_data", session.username, { type, format, jobId })

    return NextResponse.json({ jobId })
  } catch (error) {
    console.error("Error creating export job:", error)
    return NextResponse.json({ error: "Failed to create export job" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { searchParams } = new URL(request.url)
    const username = searchParams.get("username") || undefined

    // Only SuperAdmins can see all export jobs
    if (username !== session.username && session.role !== "SuperAdmin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const jobs = await getExportJobs(username)

    return NextResponse.json(jobs)
  } catch (error) {
    console.error("Error getting export jobs:", error)
    return NextResponse.json({ error: "Failed to get export jobs" }, { status: 500 })
  }
}
