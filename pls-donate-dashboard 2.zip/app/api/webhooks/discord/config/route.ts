import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { getDiscordWebhook, updateDiscordWebhook } from "@/lib/discord-webhook"
import { logActivity } from "@/lib/activity-logger"
import { hasPermission } from "@/lib/admin-roles"

export async function GET(request: Request) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check permissions
    if (!hasPermission(session.user.role, "manage_webhooks")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Get webhook configuration
    const config = getDiscordWebhook()

    // Remove sensitive information for non-super admins
    if (session.user.role !== "SuperAdmin") {
      return NextResponse.json({
        enabled: config.enabled,
        username: config.username,
        avatarUrl: config.avatarUrl,
        url: config.url ? "********" : "",
      })
    }

    return NextResponse.json(config)
  } catch (error) {
    console.error("Error getting Discord webhook config:", error)
    return NextResponse.json({ error: "Failed to get webhook configuration" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check permissions
    if (!hasPermission(session.user.role, "manage_webhooks")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Parse request body
    const data = await request.json()
    const { url, username, avatarUrl, enabled } = data

    // Validate URL
    if (enabled && (!url || !url.startsWith("https://discord.com/api/webhooks/"))) {
      return NextResponse.json({ error: "Invalid webhook URL" }, { status: 400 })
    }

    // Update webhook configuration
    const config = updateDiscordWebhook({
      url,
      username,
      avatarUrl,
      enabled,
    })

    // Log activity
    await logActivity(
      "webhook_updated",
      session.user.name,
      {
        type: "discord",
        enabled,
      },
      request,
    )

    return NextResponse.json({ success: true, config })
  } catch (error) {
    console.error("Error updating Discord webhook config:", error)
    return NextResponse.json({ error: "Failed to update webhook configuration" }, { status: 500 })
  }
}
