import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { getDiscordWebhook, sendDiscordMessage } from "@/lib/discord-webhook"
import { logActivity } from "@/lib/activity-logger"
import { hasPermission } from "@/lib/admin-roles"

export async function POST(request: Request) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check permissions
    if (!hasPermission(session.user.role, "manage_webhooks")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Get webhook configuration
    const config = getDiscordWebhook()

    if (!config.enabled || !config.url) {
      return NextResponse.json({ error: "Discord webhook is not enabled" }, { status: 400 })
    }

    // Parse request body
    const data = await request.json()
    const { message } = data

    // Send test message
    const success = await sendDiscordMessage(
      "system_event",
      "Test Message",
      message || "This is a test message from PLS DONATE Dashboard",
      [
        {
          name: "Sent By",
          value: session.user.name,
          inline: true,
        },
        {
          name: "Timestamp",
          value: new Date().toISOString(),
          inline: true,
        },
      ],
    )

    if (!success) {
      return NextResponse.json({ error: "Failed to send test message" }, { status: 500 })
    }

    // Log activity
    await logActivity(
      "webhook_tested",
      session.user.name,
      {
        type: "discord",
      },
      request,
    )

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error testing Discord webhook:", error)
    return NextResponse.json({ error: "Failed to send test message" }, { status: 500 })
  }
}
