import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { processWebhookQueue } from "@/lib/webhook-queue"

// This endpoint will be called by a cron job to process the webhook queue
export async function POST(request: Request) {
  const session = await getSession()

  // Only allow SuperAdmin to manually trigger webhook processing
  if (!session || session.role !== "SuperAdmin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    // Process up to 20 webhooks at a time
    await processWebhookQueue(20)

    return NextResponse.json({ success: true, message: "Webhook queue processing started" })
  } catch (error) {
    console.error("Error processing webhook queue:", error)
    return NextResponse.json({ error: "Failed to process webhook queue" }, { status: 500 })
  }
}
