import { type NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { sendSlackMessage } from "@/lib/slack-webhook"
import { logError } from "@/lib/error-monitoring"
import { hasPermission } from "@/lib/admin-roles"

export async function POST(request: NextRequest) {
  try {
    const session = await getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if user has permission to manage webhooks
    if (!hasPermission(session.role, "canManageWebhooks")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const success = await sendSlackMessage(
      "system",
      "medium",
      "Test Notification",
      "This is a test notification from the PLS DONATE Dashboard.",
      {
        sentBy: session.username,
        timestamp: new Date().toISOString(),
      },
    )

    if (!success) {
      return NextResponse.json({ error: "Failed to send test notification" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    logError(error, { context: "POST /api/webhooks/slack/test" })
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
