import { type NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getSlackWebhook, updateSlackWebhook } from "@/lib/slack-webhook"
import { logError } from "@/lib/error-monitoring"
import { hasPermission } from "@/lib/admin-roles"

export async function GET(request: NextRequest) {
  try {
    const session = await getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if user has permission to manage webhooks
    if (!hasPermission(session.role, "canManageWebhooks")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const config = getSlackWebhook()

    // Don't expose the actual URL for security reasons
    return NextResponse.json({
      ...config,
      url: config.url ? "********" : "",
    })
  } catch (error) {
    logError(error, { context: "GET /api/webhooks/slack/config" })
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const session = await getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if user has permission to manage webhooks
    if (!hasPermission(session.role, "canManageWebhooks")) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const body = await request.json()

    // Don't update the URL if it's masked
    if (body.url === "********") {
      delete body.url
    }

    const config = updateSlackWebhook(body)

    // Don't expose the actual URL for security reasons
    return NextResponse.json({
      ...config,
      url: config.url ? "********" : "",
    })
  } catch (error) {
    logError(error, { context: "PUT /api/webhooks/slack/config" })
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
