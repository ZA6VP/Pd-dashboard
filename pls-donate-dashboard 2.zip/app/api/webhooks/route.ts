import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getWebhooks, saveWebhook, deleteWebhook, type WebhookConfig } from "@/lib/webhooks"

// Get all webhooks
export async function GET() {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const webhooks = await getWebhooks()
    return NextResponse.json(webhooks)
  } catch (error) {
    console.error("Error fetching webhooks:", error)
    return NextResponse.json({ error: "Failed to fetch webhooks" }, { status: 500 })
  }
}

// Create or update webhook
export async function POST(request: Request) {
  const session = await getSession()

  if (!session || session.role !== "SuperAdmin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const data = await request.json()

    // Validate webhook data
    if (!data.name || !data.provider || !data.url || !data.events || !Array.isArray(data.events)) {
      return NextResponse.json({ error: "Invalid webhook data" }, { status: 400 })
    }

    // Create webhook config
    const webhook: WebhookConfig = {
      id: data.id || `webhook-${Date.now()}`,
      name: data.name,
      provider: data.provider,
      url: data.url,
      events: data.events,
      enabled: data.enabled !== false,
      createdAt: data.createdAt ? new Date(data.createdAt) : new Date(),
      lastTriggered: data.lastTriggered ? new Date(data.lastTriggered) : undefined,
    }

    // Save webhook
    const savedWebhook = await saveWebhook(webhook)

    return NextResponse.json(savedWebhook)
  } catch (error) {
    console.error("Error saving webhook:", error)
    return NextResponse.json({ error: "Failed to save webhook" }, { status: 500 })
  }
}

// Delete webhook
export async function DELETE(request: Request) {
  const session = await getSession()

  if (!session || session.role !== "SuperAdmin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { id } = await request.json()

    if (!id) {
      return NextResponse.json({ error: "Webhook ID is required" }, { status: 400 })
    }

    const success = await deleteWebhook(id)

    if (!success) {
      return NextResponse.json({ error: "Failed to delete webhook" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting webhook:", error)
    return NextResponse.json({ error: "Failed to delete webhook" }, { status: 500 })
  }
}
