import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { type WebhookConfig, sendWebhook } from "@/lib/webhooks"

export async function POST(request: Request) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const data = await request.json()

    // Validate webhook data
    if (!data.webhook) {
      return NextResponse.json({ error: "Webhook configuration is required" }, { status: 400 })
    }

    const webhook: WebhookConfig = {
      id: data.webhook.id || `test-${Date.now()}`,
      name: data.webhook.name,
      provider: data.webhook.provider,
      url: data.webhook.url,
      events: data.webhook.events || ["test"],
      enabled: true,
      createdAt: new Date(),
    }

    // Send test webhook
    const result = await sendWebhook(webhook, "test", {
      message: "This is a test notification from PLS DONATE Dashboard",
      timestamp: new Date().toISOString(),
      sender: session.username,
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error("Error testing webhook:", error)
    return NextResponse.json({ error: "Failed to test webhook" }, { status: 500 })
  }
}
