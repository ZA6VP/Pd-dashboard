import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { trackApiRequest } from "@/lib/analytics"

export async function middleware(request: NextRequest) {
  // Get the start time
  const startTime = Date.now()

  // Continue to the API route
  const response = NextResponse.next()

  // After the API route has been processed
  response.on("finish", () => {
    // Calculate response time
    const responseTime = Date.now() - startTime

    // Track API request
    trackApiRequest(request.nextUrl.pathname, response.status)

    // Add response time header
    response.headers.set("X-Response-Time", `${responseTime}ms`)
  })

  return response
}

export const config = {
  matcher: ["/api/:path*"],
}
