import { type NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getUserNotificationSettings, updateUserNotificationSettings } from "@/lib/notification-system"
import { logError } from "@/lib/error-monitoring"

export async function GET(request: NextRequest, { params }: { params: { username: string } }) {
  try {
    const session = await getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only allow users to access their own settings or admins to access any settings
    if (session.username !== params.username && !["SuperAdmin", "HeadAdmin"].includes(session.role)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const settings = await getUserNotificationSettings(params.username)

    return NextResponse.json(settings)
  } catch (error) {
    logError(error, { context: "GET /api/users/[username]/notifications/settings" })
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { username: string } }) {
  try {
    const session = await getSession()

    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only allow users to update their own settings or admins to update any settings
    if (session.username !== params.username && !["SuperAdmin", "HeadAdmin"].includes(session.role)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const body = await request.json()
    const success = await updateUserNotificationSettings(params.username, body)

    if (!success) {
      return NextResponse.json({ error: "Failed to update settings" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    logError(error, { context: "PUT /api/users/[username]/notifications/settings" })
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
