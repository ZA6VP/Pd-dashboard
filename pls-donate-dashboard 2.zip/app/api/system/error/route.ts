import { NextResponse } from "next/server"
import { logError, logServerError } from "@/lib/error-monitoring"
import { sendConsoleErrorToDiscord } from "@/lib/discord-webhook"

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const referenceCode = data.referenceCode || Math.floor(Math.random() * 10000000000).toString()

    // Check if this is a server error with a specific reference code
    if (data.type === "server_error") {
      await logServerError(data.referenceCode || referenceCode, data.message || "Server error", data.stack, data)
    } else {
      // Log the error
      await logError(data.message || "Client error", { ...data, referenceCode })

      // Send to Discord
      if (data.type === "client") {
        await sendConsoleErrorToDiscord(
          data.message || "Client error",
          data.source || "Unknown source",
          data.lineno || 0,
          data.colno || 0,
          data.stack ? ({ stack: data.stack } as Error) : undefined,
        )
      }
    }

    return NextResponse.json({ success: true, referenceCode })
  } catch (error) {
    console.error("Error logging client error:", error)
    return NextResponse.json({ error: "Failed to log error" }, { status: 500 })
  }
}
