import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { toggleMaintenanceMode, getMaintenanceStatus } from "@/lib/system-settings"
import { hasPermission } from "@/lib/admin-roles"

// Get maintenance status
export async function GET() {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const status = await getMaintenanceStatus()
    return NextResponse.json(status)
  } catch (error) {
    console.error("Error getting maintenance status:", error)
    return NextResponse.json({ error: "Failed to get maintenance status" }, { status: 500 })
  }
}

// Toggle maintenance mode
export async function POST(request: Request) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  // Check if user has permission to toggle maintenance mode
  if (!hasPermission(session.role, "canToggleMaintenance")) {
    return NextResponse.json({ error: "Insufficient permissions" }, { status: 403 })
  }

  try {
    const { enabled, message } = await request.json()

    if (typeof enabled !== "boolean") {
      return NextResponse.json({ error: "Invalid request. 'enabled' must be a boolean." }, { status: 400 })
    }

    const success = await toggleMaintenanceMode(enabled, session.username, message)

    if (!success) {
      return NextResponse.json({ error: "Failed to toggle maintenance mode" }, { status: 500 })
    }

    return NextResponse.json({ success: true, enabled })
  } catch (error) {
    console.error("Error toggling maintenance mode:", error)
    return NextResponse.json({ error: "Failed to toggle maintenance mode" }, { status: 500 })
  }
}
