import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getBackupMetadata, createBackup } from "@/lib/backup-system"

export async function GET() {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const backups = await getBackupMetadata()
    return NextResponse.json(backups)
  } catch (error) {
    console.error("Error getting backups:", error)
    return NextResponse.json({ error: "Failed to get backups" }, { status: 500 })
  }
}

export async function POST() {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const backup = await createBackup()

    if (!backup) {
      return NextResponse.json({ error: "Failed to create backup" }, { status: 500 })
    }

    return NextResponse.json(backup)
  } catch (error) {
    console.error("Error creating backup:", error)
    return NextResponse.json({ error: "Failed to create backup" }, { status: 500 })
  }
}
