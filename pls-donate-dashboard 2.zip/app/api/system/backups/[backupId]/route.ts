import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { deleteBackup } from "@/lib/backup-system"

export async function DELETE(request: Request, { params }: { params: { backupId: string } }) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const success = await deleteBackup(params.backupId)

    if (!success) {
      return NextResponse.json({ error: "Failed to delete backup" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting backup:", error)
    return NextResponse.json({ error: "Failed to delete backup" }, { status: 500 })
  }
}
