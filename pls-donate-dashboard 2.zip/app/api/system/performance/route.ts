import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getRecentMetrics, getPerformanceSummary } from "@/lib/performance-monitor"

export async function GET(request: Request) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type") || undefined

    // Get performance summary
    const summary = await getPerformanceSummary()

    // Get metrics for each type
    const metrics: Record<string, any> = {}

    for (const metricType of Object.keys(summary)) {
      metrics[metricType] = await getRecentMetrics(metricType as any, 100)
    }

    return NextResponse.json({
      summary,
      metrics,
    })
  } catch (error) {
    console.error("Error getting performance metrics:", error)
    return NextResponse.json({ error: "Failed to get performance metrics" }, { status: 500 })
  }
}
