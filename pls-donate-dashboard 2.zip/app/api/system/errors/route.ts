import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getRecentErrors, clearErrorLog } from "@/lib/error-monitoring"

export async function GET() {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const errors = await getRecentErrors()
    return NextResponse.json(errors)
  } catch (error) {
    console.error("Error getting error logs:", error)
    return NextResponse.json({ error: "Failed to get error logs" }, { status: 500 })
  }
}

export async function DELETE() {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    await clearErrorLog()
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error clearing error logs:", error)
    return NextResponse.json({ error: "Failed to clear error logs" }, { status: 500 })
  }
}
