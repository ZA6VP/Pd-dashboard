import { NextResponse } from "next/server"
import redis from "@/lib/redis"
import { getOverallSystemStatus } from "@/lib/system-status"
import { getPerformanceSummary } from "@/lib/performance-monitor"
import { recordMetric } from "@/lib/performance-monitor"

export async function GET(request: Request) {
  const startTime = performance.now()

  try {
    // Check Redis connection
    let redisStatus = "unknown"
    try {
      const pong = await redis.ping()
      redisStatus = pong === "PONG" ? "operational" : "degraded"
    } catch (error) {
      redisStatus = "outage"
    }

    // Get system status
    const systemStatus = await getOverallSystemStatus()

    // Get performance summary
    const performanceSummary = await getPerformanceSummary()

    // Get memory usage
    const memoryUsage = process.memoryUsage()

    // Calculate response time
    const endTime = performance.now()
    const responseTime = endTime - startTime

    // Record response time metric
    await recordMetric("api_response_time", responseTime, {
      endpoint: "/api/system/health",
      method: "GET",
    })

    return NextResponse.json({
      status: "ok",
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      redis: redisStatus,
      systemStatus,
      performance: performanceSummary,
      memory: {
        rss: formatBytes(memoryUsage.rss),
        heapTotal: formatBytes(memoryUsage.heapTotal),
        heapUsed: formatBytes(memoryUsage.heapUsed),
        external: formatBytes(memoryUsage.external),
      },
      responseTime: `${responseTime.toFixed(2)}ms`,
    })
  } catch (error) {
    console.error("Health check error:", error)

    return NextResponse.json(
      {
        status: "error",
        timestamp: new Date().toISOString(),
        error: error.message,
      },
      { status: 500 },
    )
  }
}

// Helper function to format bytes
function formatBytes(bytes: number): string {
  if (bytes === 0) return "0 Bytes"

  const k = 1024
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"]
  const i = Math.floor(Math.log(bytes) / Math.log(k))

  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
}
