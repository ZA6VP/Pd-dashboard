import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { getRecentActivities } from "@/lib/activity-logger"

export async function GET(request: Request) {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "100")
    const type = searchParams.get("type") || undefined
    const username = searchParams.get("username") || undefined

    const activities = await getRecentActivities(limit, type as any, username)

    return NextResponse.json(activities)
  } catch (error) {
    console.error("Error getting activity logs:", error)
    return NextResponse.json({ error: "Failed to get activity logs" }, { status: 500 })
  }
}
