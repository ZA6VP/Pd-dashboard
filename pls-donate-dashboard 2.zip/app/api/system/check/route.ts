import { NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import { runSystemStatusCheck } from "@/lib/system-status"

export async function POST() {
  const session = await getSession()

  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    await runSystemStatusCheck()
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error running system check:", error)
    return NextResponse.json({ error: "Failed to run system check" }, { status: 500 })
  }
}
