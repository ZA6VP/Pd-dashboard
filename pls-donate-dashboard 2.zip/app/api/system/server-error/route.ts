import { NextResponse } from "next/server"
import { logServerError } from "@/lib/error-monitoring"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Validate required fields
    if (!data.referenceCode) {
      return NextResponse.json({ error: "Reference code is required" }, { status: 400 })
    }

    // Log the server error
    await logServerError(data.referenceCode, data.message || "Unknown server error", data.stack, data.context || {})

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error logging server error:", error)
    return NextResponse.json({ error: "Failed to log server error" }, { status: 500 })
  }
}
