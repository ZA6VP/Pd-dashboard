import { NextResponse } from "next/server"
import { handleSpecificErrorReference } from "@/lib/specific-error-handlers"

export async function POST(request: Request) {
  try {
    const data = await request.json()

    if (!data.referenceCode) {
      return NextResponse.json({ error: "Reference code is required" }, { status: 400 })
    }

    // Handle the specific error reference
    const handled = await handleSpecificErrorReference(data.referenceCode)

    return NextResponse.json({ success: true, handled })
  } catch (error) {
    console.error("Error handling specific error reference:", error)
    return NextResponse.json({ error: "Failed to handle specific error" }, { status: 500 })
  }
}
