import { type NextRequest, NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/db"
import { Game, Store, AuditLog } from "@/lib/models"
import { invalidateCache, cacheKey } from "@/lib/redis"
import { publishEvent } from "@/lib/websocket-pubsub"
import { trackGamePlayers, trackDonation } from "@/lib/analytics"

export async function POST(request: NextRequest, { params }: { params: { placeId: string } }) {
  const placeId = Number(params.placeId)

  try {
    const data = await request.json()

    // Validate the payload
    if (!data || !data.placeId || !data.timestamp || !data.stores) {
      return NextResponse.json({ error: "Invalid payload" }, { status: 400 })
    }

    // Ensure the placeId in the URL matches the one in the payload
    if (data.placeId !== placeId) {
      return NextResponse.json({ error: "PlaceId mismatch" }, { status: 400 })
    }

    await connectToDatabase()

    // Track player count for analytics
    if (data.activePlayers) {
      await trackGamePlayers(placeId, data.activePlayers)
    }

    // Check for donation data and track it
    if (data.stores.GlobalDonations) {
      // This is just an example - adjust based on your actual data structure
      const donations = data.stores.GlobalDonations

      if (donations.recent && Array.isArray(donations.recent)) {
        // Process recent donations
        for (const donation of donations.recent) {
          if (donation.amount && donation.donor && donation.recipient) {
            await trackDonation(placeId, donation.amount, donation.donor, donation.recipient)
          }
        }
      }

      // Track total donations if available
      if (donations.total) {
        // You might want to track the difference since last update
        // This would require storing the previous total
      }
    }

    // Update game info
    await Game.findOneAndUpdate(
      { placeId },
      {
        $set: {
          name: data.name || `Game ${placeId}`,
          ownerUserId: data.ownerUserId,
          groupId: data.groupId,
          lastUpdated: new Date(data.timestamp * 1000),
          activePlayers: data.activePlayers || 0,
        },
      },
      { upsert: true },
    )

    // Update stores
    for (const [storeName, storeData] of Object.entries(data.stores)) {
      await Store.findOneAndUpdate(
        { gameId: placeId, storeName },
        {
          $set: {
            data: storeData,
            updatedAt: new Date(),
          },
        },
        { upsert: true },
      )

      // Invalidate store cache
      await invalidateCache(cacheKey.store(placeId, storeName))
    }

    // Log the update
    await AuditLog.create({
      action: "game_update",
      username: "system",
      details: { placeId, timestamp: data.timestamp },
    })

    // Invalidate game and stores caches
    await invalidateCache(cacheKey.games())
    await invalidateCache(cacheKey.game(placeId))
    await invalidateCache(cacheKey.stores(placeId))

    // Publish WebSocket event for real-time updates
    await publishEvent({
      type: "GAME_UPDATE",
      data: {
        placeId,
        name: data.name || `Game ${placeId}`,
        activePlayers: data.activePlayers || 0,
        timestamp: new Date(data.timestamp * 1000).toISOString(),
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error(`Error updating game ${placeId}:`, error)
    return NextResponse.json({ error: "Failed to update game data" }, { status: 500 })
  }
}
