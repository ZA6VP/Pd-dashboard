import type { NextRequest } from "next/server"
import { WebSocketServer } from "ws"
import { getSession } from "@/lib/auth"
import { subscribeToEvents } from "@/lib/websocket-pubsub"

// Store active WebSocket connections
const clients = new Set<WebSocket>()

// Initialize WebSocket server (only once)
let wss: WebSocketServer
let subscribed = false

if (!wss && typeof process !== "undefined") {
  wss = new WebSocketServer({ noServer: true })

  wss.on("connection", (ws) => {
    clients.add(ws)

    // Send welcome message
    ws.send(
      JSON.stringify({
        type: "NOTIFICATION",
        data: {
          message: "Connected to PLS DONATE Dashboard WebSocket",
          timestamp: new Date().toISOString(),
        },
      }),
    )

    // Handle messages from client
    ws.on("message", (message) => {
      try {
        const data = JSON.parse(message.toString())
        // Process message if needed
      } catch (error) {
        console.error("Invalid WebSocket message:", error)
      }
    })

    // Handle disconnection
    ws.on("close", () => {
      clients.delete(ws)
    })
  })

  // Subscribe to Redis events (only once)
  if (!subscribed) {
    subscribeToEvents((event) => {
      broadcast(event)
    })
    subscribed = true
  }
}

// Broadcast message to all connected clients
export function broadcast(message: any) {
  const messageStr = JSON.stringify(message)
  clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(messageStr)
    }
  })
}

export async function GET(req: NextRequest) {
  const session = await getSession()

  if (!session) {
    return new Response("Unauthorized", { status: 401 })
  }

  // This is a WebSocket request, so we need to upgrade the connection
  // Using the 'Sec-WebSocket-Protocol' header to determine if it's a WebSocket upgrade request.
  if (req.headers.get("upgrade") !== "websocket") {
    return new Response("Expected WebSocket", { status: 400 })
  }

  const socket = new WebSocket("ws://localhost:3000") // Dummy WebSocket connection

  wss.handleUpgrade(req, socket, Buffer.from([]), (ws) => {
    wss.emit("connection", ws, req)
  })

  return new Response(null, {
    status: 101,
    statusText: "Switching Protocols",
    headers: { "Sec-WebSocket-Accept": req.headers.get("sec-websocket-key")! },
  })
}
