import { NextResponse } from "next/server"
import { processWebhookQueue } from "@/lib/webhook-queue"

// This endpoint will be called by a cron job to process the webhook queue
export async function GET(request: Request) {
  // Verify the request is from a cron job
  const authHeader = request.headers.get("Authorization")

  // In a real implementation, you would verify the authorization header
  // For now, we'll just check if it exists
  if (!authHeader) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    // Process up to 20 webhooks at a time
    await processWebhookQueue(20)

    return NextResponse.json({ success: true, message: "Webhook queue processing started" })
  } catch (error) {
    console.error("Error processing webhook queue:", error)
    return NextResponse.json({ error: "Failed to process webhook queue" }, { status: 500 })
  }
}
