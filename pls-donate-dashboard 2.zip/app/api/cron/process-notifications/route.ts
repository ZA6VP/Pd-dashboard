import { type NextRequest, NextResponse } from "next/server"
import { processBatchedNotifications } from "@/lib/notification-system"
import { logError } from "@/lib/error-monitoring"

export async function GET(request: NextRequest) {
  try {
    // Verify cron secret if provided
    const cronSecret = process.env.CRON_SECRET
    const authHeader = request.headers.get("authorization")

    if (cronSecret && (!authHeader || authHeader !== `Bearer ${cronSecret}`)) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Process batched notifications
    const processedCount = await processBatchedNotifications()

    return NextResponse.json({
      success: true,
      processedCount,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    logError(error, { context: "GET /api/cron/process-notifications" })
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
