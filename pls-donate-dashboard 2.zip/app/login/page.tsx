import { redirect } from "next/navigation"
import { getSession } from "@/lib/auth"
import LoginForm from "@/components/login-form"

export default async function LoginPage() {
  try {
    // Check if user is already logged in
    const session = await getSession()

    if (session) {
      redirect("/dashboard")
    }

    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100">
        <div className="w-full max-w-md">
          <div className="rounded-lg bg-white p-8 shadow-md">
            <h1 className="mb-6 text-center text-2xl font-bold">PLS DONATE Dashboard</h1>
            <LoginForm />
          </div>
        </div>
      </div>
    )
  } catch (error) {
    console.error("Login page error:", error)

    // Fallback UI in case of error
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100">
        <div className="w-full max-w-md">
          <div className="rounded-lg bg-white p-8 shadow-md">
            <h1 className="mb-6 text-center text-2xl font-bold">PLS DONATE Dashboard</h1>
            <LoginForm />
            <div className="mt-4 text-sm text-gray-500">Note: Some services may be temporarily unavailable.</div>
          </div>
        </div>
      </div>
    )
  }
}
