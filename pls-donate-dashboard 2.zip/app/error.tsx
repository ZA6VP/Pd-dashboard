"use client"

import { useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle } from "lucide-react"
import { generateErrorReference } from "@/lib/error-monitoring"

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  const errorRef = error.digest || generateErrorReference()

  useEffect(() => {
    // Report the error to our API
    fetch("/api/system/server-error", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        referenceCode: errorRef,
        message: error.message || "Unknown error",
        stack: error.stack,
        context: {
          digest: error.digest,
          url: typeof window !== "undefined" ? window.location.href : null,
          timestamp: new Date().toISOString(),
        },
      }),
    }).catch(console.error)
  }, [error, errorRef])

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-500" />
            <CardTitle>Something went wrong</CardTitle>
          </div>
          <CardDescription>An unexpected error occurred. Our team has been notified.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-gray-50 p-4 rounded-md text-sm">
            <p className="font-semibold">Error Reference:</p>
            <p className="text-red-600">{errorRef}</p>

            <p className="font-semibold mt-2">Message:</p>
            <p>{error.message || "Unknown error"}</p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => (window.location.href = "/")}>
            Go to Home
          </Button>
          <Button onClick={reset}>Try Again</Button>
        </CardFooter>
      </Card>
    </div>
  )
}
