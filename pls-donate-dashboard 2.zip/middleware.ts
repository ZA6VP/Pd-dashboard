import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  const response = NextResponse.next()

  // Check if the URL contains an error reference code (like 1968665631)
  const url = new URL(request.url)
  const errorRefMatch = url.pathname.match(/\/error\/(\d+)/)

  if (errorRefMatch) {
    const errorRef = errorRefMatch[1]

    // Redirect to the home page with the error reference as a query parameter
    const redirectUrl = new URL("/", url.origin)
    redirectUrl.searchParams.set("errorRef", errorRef)

    return NextResponse.redirect(redirectUrl)
  }

  return response
}

export const config = {
  matcher: ["/error/:path*"],
}
