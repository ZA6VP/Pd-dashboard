import { logError } from "./error-monitoring"

// Email configuration
interface EmailConfig {
  enabled: boolean
  fromEmail: string
  fromName: string
  replyTo: string
}

// Default email configuration
let emailConfig: EmailConfig = {
  enabled: false,
  fromEmail: "noreply@plsdonate-dashboard.com",
  fromName: "PLS DONATE Dashboard",
  replyTo: "support@plsdonate-dashboard.com",
}

// Initialize email service
export function initEmailService() {
  // Check if email service is configured
  const emailEnabled = process.env.EMAIL_ENABLED === "true"

  if (emailEnabled) {
    emailConfig = {
      ...emailConfig,
      enabled: true,
      fromEmail: process.env.EMAIL_FROM || emailConfig.fromEmail,
      fromName: process.env.EMAIL_FROM_NAME || emailConfig.fromName,
      replyTo: process.env.EMAIL_REPLY_TO || emailConfig.replyTo,
    }

    console.log("Email service initialized")
    return true
  }

  console.log("Email service not configured")
  return false
}

// Update email configuration
export function updateEmailConfig(config: Partial<EmailConfig>): EmailConfig {
  emailConfig = {
    ...emailConfig,
    ...config,
  }

  return emailConfig
}

// Get email configuration
export function getEmailConfig(): EmailConfig {
  return { ...emailConfig }
}

// Send email
export async function sendEmail(
  to: string,
  subject: string,
  message: string,
  details: Record<string, any> = {},
): Promise<boolean> {
  if (!emailConfig.enabled) {
    return false
  }

  try {
    // Format details as HTML
    let detailsHtml = ""

    if (Object.keys(details).length > 0) {
      detailsHtml = "<h3>Additional Details:</h3><ul>"

      for (const [key, value] of Object.entries(details)) {
        if (typeof value === "object") {
          detailsHtml += `<li><strong>${key}:</strong> <pre>${JSON.stringify(value, null, 2)}</pre></li>`
        } else {
          detailsHtml += `<li><strong>${key}:</strong> ${value}</li>`
        }
      }

      detailsHtml += "</ul>"
    }

    // Create HTML email body
    const htmlBody = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>${subject}</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background-color: #4a6cf7; color: white; padding: 10px 20px; border-radius: 5px 5px 0 0; }
          .content { padding: 20px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 5px 5px; }
          .footer { margin-top: 20px; font-size: 12px; color: #777; text-align: center; }
          pre { background-color: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h2>${subject}</h2>
          </div>
          <div class="content">
            <p>${message}</p>
            ${detailsHtml}
          </div>
          <div class="footer">
            <p>This is an automated message from PLS DONATE Dashboard. Please do not reply to this email.</p>
          </div>
        </div>
      </body>
      </html>
    `

    // Create text email body (fallback)
    const textBody = `
      ${subject}
      
      ${message}
      
      ${Object.keys(details).length > 0 ? "Additional Details:" : ""}
      ${Object.entries(details)
        .map(([key, value]) => `${key}: ${typeof value === "object" ? JSON.stringify(value, null, 2) : value}`)
        .join("\n")}
      
      This is an automated message from PLS DONATE Dashboard. Please do not reply to this email.
    `

    // In a real implementation, you would use a service like SendGrid, Mailgun, etc.
    // For this example, we'll just log the email
    console.log(`[EMAIL] To: ${to}, Subject: ${subject}`)

    // Simulate sending email
    // In a real implementation, you would use something like:
    /*
    const response = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.SENDGRID_API_KEY}`
      },
      body: JSON.stringify({
        personalizations: [{ to: [{ email: to }] }],
        from: { email: emailConfig.fromEmail, name: emailConfig.fromName },
        reply_to: { email: emailConfig.replyTo },
        subject,
        content: [
          { type: 'text/plain', value: textBody },
          { type: 'text/html', value: htmlBody }
        ]
      })
    })
    
    if (!response.ok) {
      throw new Error(`Failed to send email: ${response.statusText}`)
    }
    */

    return true
  } catch (error) {
    logError(error, { context: "sendEmail", to, subject })
    return false
  }
}
