import { logError } from "./error-monitoring"

// Discord webhook configuration
interface DiscordWebhookConfig {
  url: string
  username?: string
  avatarUrl?: string
  enabled: boolean
}

// Message types
export type DiscordMessageType =
  | "error"
  | "server_error"
  | "console_error"
  | "stats_change"
  | "system_event"
  | "security_alert"
  | "performance_alert"
  | "user_activity"
  | "game_update"
  | "donation"
  | "ban"

// Message colors
const MESSAGE_COLORS = {
  error: 0xed4245, // Red
  server_error: 0xff0000, // Bright Red
  console_error: 0xf04747, // Bright Red
  stats_change: 0x3498db, // Blue
  system_event: 0x57f287, // Green
  security_alert: 0xfee75c, // Yellow
  performance_alert: 0xeb459e, // Pink
  user_activity: 0x9b59b6, // Purple
  game_update: 0x1abc9c, // Teal
  donation: 0x2ecc71, // Emerald
  ban: 0xe74c3c, // Crimson
}

// Discord webhook configuration
let webhookConfig: DiscordWebhookConfig = {
  url: "",
  username: "PLS DONATE Dashboard",
  avatarUrl: "https://cdn.discordapp.com/avatars/123456789/dashboard.png",
  enabled: false,
}

// Initialize webhook from environment variable
export function initDiscordWebhook() {
  const webhookUrl = process.env.DISCORD_WEBHOOK_URL

  if (webhookUrl) {
    webhookConfig = {
      ...webhookConfig,
      url: webhookUrl,
      enabled: true,
    }
    console.log("Discord webhook initialized")
    return true
  }

  console.log("Discord webhook not configured")
  return false
}

// Update webhook configuration
export function updateDiscordWebhook(config: Partial<DiscordWebhookConfig>): DiscordWebhookConfig {
  webhookConfig = {
    ...webhookConfig,
    ...config,
  }

  return webhookConfig
}

// Get webhook configuration
export function getDiscordWebhook(): DiscordWebhookConfig {
  return { ...webhookConfig }
}

// Send message to Discord webhook
export async function sendDiscordMessage(
  type: DiscordMessageType,
  title: string,
  description: string,
  fields: { name: string; value: string; inline?: boolean }[] = [],
  additionalData: Record<string, any> = {},
): Promise<boolean> {
  if (!webhookConfig.enabled || !webhookConfig.url) {
    console.log("Discord webhook not enabled or URL not set")
    return false
  }

  try {
    const embed = {
      title,
      description,
      color: MESSAGE_COLORS[type] || 0x5865f2,
      fields,
      timestamp: new Date().toISOString(),
      footer: {
        text: `PLS DONATE Dashboard • ${type.replace("_", " ")}`,
      },
    }

    // Add additional data as fields if provided
    if (Object.keys(additionalData).length > 0) {
      for (const [key, value] of Object.entries(additionalData)) {
        if (typeof value === "object") {
          fields.push({
            name: key,
            value: "```json\n" + JSON.stringify(value, null, 2).substring(0, 1000) + "```",
            inline: false,
          })
        } else {
          fields.push({
            name: key,
            value: String(value).substring(0, 1000),
            inline: true,
          })
        }
      }
    }

    const payload = {
      username: webhookConfig.username,
      avatar_url: webhookConfig.avatarUrl,
      embeds: [embed],
    }

    console.log("Sending Discord webhook message:", type, title)

    const response = await fetch(webhookConfig.url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      throw new Error(`Discord webhook failed with status ${response.status}`)
    }

    console.log("Discord webhook message sent successfully")
    return true
  } catch (error) {
    console.error("Error sending Discord webhook message:", error)
    try {
      logError(error, { context: "sendDiscordMessage", type, title })
    } catch (logError) {
      console.error("Failed to log Discord webhook error:", logError)
    }
    return false
  }
}

// Send server error to Discord with user-friendly explanation
export async function sendServerErrorToDiscord(
  referenceCode: string,
  errorMessage: string,
  stack?: string,
  context: Record<string, any> = {},
): Promise<boolean> {
  // Create a user-friendly explanation
  const explanation = `
A server-side error occurred in the PLS DONATE Dashboard. This means the server encountered a problem while processing a request.

**What this means:**
• The server couldn't complete the requested operation
• This could be due to a code error, database issue, or resource limitation
• The error has been logged and our team will investigate

**What you can do:**
• Try refreshing the page
• Check if all required environment variables are set
• Verify database connections are working
• Look for any recent code changes that might have caused this
  `

  return sendDiscordMessage(
    "server_error",
    `Server Error: Reference #${referenceCode}`,
    explanation,
    [
      {
        name: "Error Message",
        value: errorMessage || "No error message available",
        inline: false,
      },
      {
        name: "Reference Code",
        value: referenceCode,
        inline: true,
      },
      {
        name: "Timestamp",
        value: new Date().toISOString(),
        inline: true,
      },
      {
        name: "Stack Trace",
        value: stack ? `\`\`\`\n${stack.substring(0, 1000)}\n\`\`\`` : "No stack trace available",
        inline: false,
      },
    ],
    context,
  )
}

// Send error to Discord
export async function sendErrorToDiscord(error: Error | string, context: Record<string, any> = {}): Promise<boolean> {
  const errorMessage = error instanceof Error ? error.message : error
  const errorStack = error instanceof Error ? error.stack : null

  return sendDiscordMessage(
    "error",
    "Error Detected",
    errorMessage,
    [
      {
        name: "Stack Trace",
        value: errorStack ? `\`\`\`\n${errorStack.substring(0, 1000)}\n\`\`\`` : "No stack trace available",
        inline: false,
      },
    ],
    context,
  )
}

// Send console error to Discord
export async function sendConsoleErrorToDiscord(
  message: string,
  source: string,
  lineno: number,
  colno: number,
  error?: Error,
): Promise<boolean> {
  return sendDiscordMessage("console_error", "Console Error Detected", message, [
    {
      name: "Source",
      value: source,
      inline: true,
    },
    {
      name: "Location",
      value: `Line ${lineno}, Column ${colno}`,
      inline: true,
    },
    {
      name: "Stack Trace",
      value: error?.stack ? `\`\`\`\n${error.stack.substring(0, 1000)}\n\`\`\`` : "No stack trace available",
      inline: false,
    },
  ])
}

// Send stats change to Discord
export async function sendStatsChangeToDiscord(
  statName: string,
  oldValue: any,
  newValue: any,
  gameId?: number,
): Promise<boolean> {
  return sendDiscordMessage(
    "stats_change",
    "Stats Change Detected",
    `The "${statName}" statistic has changed`,
    [
      {
        name: "Previous Value",
        value: String(oldValue),
        inline: true,
      },
      {
        name: "New Value",
        value: String(newValue),
        inline: true,
      },
      {
        name: "Change",
        value:
          typeof oldValue === "number" && typeof newValue === "number"
            ? `${(newValue - oldValue).toFixed(2)} (${(((newValue - oldValue) / oldValue) * 100).toFixed(2)}%)`
            : "N/A",
        inline: true,
      },
    ],
    gameId ? { gameId } : {},
  )
}

// Send system event to Discord
export async function sendSystemEventToDiscord(
  eventName: string,
  description: string,
  details: Record<string, any> = {},
): Promise<boolean> {
  const fields = Object.entries(details).map(([key, value]) => ({
    name: key,
    value: typeof value === "object" ? JSON.stringify(value) : String(value),
    inline: true,
  }))

  return sendDiscordMessage("system_event", `System Event: ${eventName}`, description, fields)
}

// Send security alert to Discord
export async function sendSecurityAlertToDiscord(
  alertType: string,
  description: string,
  details: Record<string, any> = {},
): Promise<boolean> {
  const fields = Object.entries(details).map(([key, value]) => ({
    name: key,
    value: typeof value === "object" ? JSON.stringify(value) : String(value),
    inline: true,
  }))

  return sendDiscordMessage("security_alert", `Security Alert: ${alertType}`, description, fields)
}

// Send performance alert to Discord
export async function sendPerformanceAlertToDiscord(
  metricName: string,
  value: number,
  threshold: number,
  details: Record<string, any> = {},
): Promise<boolean> {
  return sendDiscordMessage(
    "performance_alert",
    `Performance Alert: ${metricName}`,
    `The ${metricName} metric has exceeded the threshold of ${threshold}`,
    [
      {
        name: "Current Value",
        value: String(value),
        inline: true,
      },
      {
        name: "Threshold",
        value: String(threshold),
        inline: true,
      },
      {
        name: "Difference",
        value: `${(value - threshold).toFixed(2)} (${(((value - threshold) / threshold) * 100).toFixed(2)}%)`,
        inline: true,
      },
    ],
    details,
  )
}

// Send user activity to Discord
export async function sendUserActivityToDiscord(
  username: string,
  activityType: string,
  details: Record<string, any> = {},
): Promise<boolean> {
  const fields = Object.entries(details).map(([key, value]) => ({
    name: key,
    value: typeof value === "object" ? JSON.stringify(value) : String(value),
    inline: true,
  }))

  return sendDiscordMessage(
    "user_activity",
    `User Activity: ${activityType}`,
    `User ${username} performed ${activityType}`,
    fields,
  )
}

// Send game update to Discord
export async function sendGameUpdateToDiscord(
  gameId: number,
  gameName: string,
  updateType: string,
  details: Record<string, any> = {},
): Promise<boolean> {
  const fields = Object.entries(details).map(([key, value]) => ({
    name: key,
    value: typeof value === "object" ? JSON.stringify(value) : String(value),
    inline: true,
  }))

  return sendDiscordMessage(
    "game_update",
    `Game Update: ${gameName}`,
    `Game ${gameName} (ID: ${gameId}) has been updated: ${updateType}`,
    fields,
  )
}

// Send donation to Discord
export async function sendDonationToDiscord(
  amount: number,
  donor: string,
  recipient: string,
  gameId: number,
  gameName: string,
): Promise<boolean> {
  return sendDiscordMessage(
    "donation",
    `New Donation: ${amount} Robux`,
    `A new donation has been made in ${gameName}`,
    [
      {
        name: "Amount",
        value: `${amount} Robux`,
        inline: true,
      },
      {
        name: "Donor",
        value: donor,
        inline: true,
      },
      {
        name: "Recipient",
        value: recipient,
        inline: true,
      },
      {
        name: "Game",
        value: gameName,
        inline: true,
      },
      {
        name: "Game ID",
        value: String(gameId),
        inline: true,
      },
    ],
  )
}

// Send ban to Discord
export async function sendBanToDiscord(
  username: string,
  reason: string,
  duration: string,
  admin: string,
  gameId: number,
  gameName: string,
): Promise<boolean> {
  return sendDiscordMessage("ban", `User Banned: ${username}`, `User ${username} has been banned from ${gameName}`, [
    {
      name: "Reason",
      value: reason,
      inline: true,
    },
    {
      name: "Duration",
      value: duration,
      inline: true,
    },
    {
      name: "Admin",
      value: admin,
      inline: true,
    },
    {
      name: "Game",
      value: gameName,
      inline: true,
    },
    {
      name: "Game ID",
      value: String(gameId),
      inline: true,
    },
  ])
}
