import redis from "./redis"

// Status types
export type ServiceStatus = "operational" | "degraded" | "outage" | "maintenance" | "unknown"

// Service interface
export interface Service {
  id: string
  name: string
  description: string
  status: ServiceStatus
  lastChecked: string
  lastIncident?: string
  details?: string
}

// System status key
const SYSTEM_STATUS_KEY = "system:status"

// Default services
const DEFAULT_SERVICES: Service[] = [
  {
    id: "redis",
    name: "Redis Database",
    description: "Primary data storage and caching service",
    status: "unknown",
    lastChecked: new Date().toISOString(),
  },
  {
    id: "auth",
    name: "Authentication Service",
    description: "User authentication and session management",
    status: "unknown",
    lastChecked: new Date().toISOString(),
  },
  {
    id: "api",
    name: "API Services",
    description: "Backend API endpoints",
    status: "unknown",
    lastChecked: new Date().toISOString(),
  },
  {
    id: "websocket",
    name: "WebSocket Service",
    description: "Real-time communication service",
    status: "unknown",
    lastChecked: new Date().toISOString(),
  },
  {
    id: "webhook",
    name: "Webhook Service",
    description: "External integration service",
    status: "unknown",
    lastChecked: new Date().toISOString(),
  },
]

// Initialize system status
export async function initializeSystemStatus() {
  try {
    const exists = await redis.exists(SYSTEM_STATUS_KEY)

    if (!exists) {
      await redis.set(SYSTEM_STATUS_KEY, JSON.stringify(DEFAULT_SERVICES))
      console.log("Initialized system status")
    }
  } catch (error) {
    console.error("Failed to initialize system status:", error)
  }
}

// Get system status
export async function getSystemStatus(): Promise<Service[]> {
  try {
    const status = await redis.get(SYSTEM_STATUS_KEY)

    if (!status) {
      // Initialize if not exists
      await initializeSystemStatus()
      return DEFAULT_SERVICES
    }

    return JSON.parse(status)
  } catch (error) {
    console.error("Failed to get system status:", error)
    return DEFAULT_SERVICES
  }
}

// Update service status
export async function updateServiceStatus(
  serviceId: string,
  status: ServiceStatus,
  details?: string,
): Promise<boolean> {
  try {
    const services = await getSystemStatus()

    const serviceIndex = services.findIndex((s) => s.id === serviceId)

    if (serviceIndex === -1) {
      return false
    }

    // Update service
    services[serviceIndex] = {
      ...services[serviceIndex],
      status,
      lastChecked: new Date().toISOString(),
      details,
      ...(status !== "operational" && { lastIncident: new Date().toISOString() }),
    }

    // Save updated status
    await redis.set(SYSTEM_STATUS_KEY, JSON.stringify(services))

    return true
  } catch (error) {
    console.error(`Failed to update service status for ${serviceId}:`, error)
    return false
  }
}

// Check Redis status
export async function checkRedisStatus(): Promise<ServiceStatus> {
  try {
    const pong = await redis.ping()

    if (pong === "PONG") {
      await updateServiceStatus("redis", "operational")
      return "operational"
    } else {
      await updateServiceStatus("redis", "degraded", "Unexpected response from Redis")
      return "degraded"
    }
  } catch (error) {
    await updateServiceStatus("redis", "outage", error.message)
    return "outage"
  }
}

// Get overall system status
export async function getOverallSystemStatus(): Promise<ServiceStatus> {
  const services = await getSystemStatus()

  if (services.some((s) => s.status === "outage")) {
    return "outage"
  }

  if (services.some((s) => s.status === "degraded")) {
    return "degraded"
  }

  if (services.some((s) => s.status === "maintenance")) {
    return "maintenance"
  }

  if (services.every((s) => s.status === "operational")) {
    return "operational"
  }

  return "unknown"
}

// Run system status check
export async function runSystemStatusCheck() {
  try {
    // Check Redis
    await checkRedisStatus()

    // Check other services
    // TODO: Add checks for other services

    console.log("System status check completed")
  } catch (error) {
    console.error("Failed to run system status check:", error)
  }
}
