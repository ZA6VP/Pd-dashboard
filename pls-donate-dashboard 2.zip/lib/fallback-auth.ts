// Fallback authentication system that works without Redis
import { cookies } from "next/headers"
import { SignJWT, jwtVerify } from "jose"
import { type NextRequest, NextResponse } from "next/server"

// Initial hard-coded users
const USERS = [
  { username: "ZA6VP", password: "mack11100", role: "SuperAdmin" },
  { username: "Votiue", password: "kateandvotrsocool", role: "Moderator" },
  { username: "q_6nnn", password: "kateandvotrsocool", role: "Moderator" },
]

// JWT secret from environment variable
const JWT_SECRET = process.env.JWT_SECRET || "fallback-secret-key-please-set-jwt-secret-env-var"
const secret = new TextEncoder().encode(JWT_SECRET)

// Login function
export async function fallbackLogin(username: string, password: string) {
  // Find user
  const user = USERS.find((u) => u.username === username && u.password === password)

  if (!user) {
    return { success: false, message: "Invalid credentials" }
  }

  // Create JWT token
  const token = await new SignJWT({
    username: user.username,
    role: user.role,
    loginTime: new Date().toISOString(),
  })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("24h")
    .sign(secret)

  // Save token to cookie
  cookies().set("session", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24, // 1 day
    path: "/",
  })

  return { success: true, user: { username: user.username, role: user.role } }
}

// Get session data
export async function fallbackGetSession(token: string) {
  try {
    const { payload } = await jwtVerify(token, secret)
    return payload
  } catch (error) {
    console.error("Failed to verify token:", error)
    return null
  }
}

// Update session middleware
export async function fallbackUpdateSession(request: NextRequest) {
  const token = request.cookies.get("session")?.value
  if (!token) return NextResponse.redirect(new URL("/login", request.url))

  const session = await fallbackGetSession(token)
  if (!session) return NextResponse.redirect(new URL("/login", request.url))

  return NextResponse.next()
}

// Logout function
export async function fallbackLogout() {
  cookies().delete("session")
}

// Get all users (for admin management)
export function fallbackGetAllUsers() {
  return USERS.map(({ username, role }) => ({
    username,
    role,
    createdAt: new Date().toISOString(),
    lastLogin: null,
  }))
}

// Check if user exists
export function fallbackUserExists(username: string) {
  return USERS.some((u) => u.username === username)
}

// Get initial users
export function getInitialUsers() {
  return USERS
}
