import redis from "./redis"
import { logError } from "./error-monitoring"
import { logActivity } from "./activity-logger"

// Export formats
export type ExportFormat = "json" | "csv" | "xml"

// Export types
export type ExportType =
  | "games"
  | "game"
  | "stores"
  | "store"
  | "bans"
  | "users"
  | "activity_log"
  | "error_log"
  | "performance_metrics"
  | "system_status"
  | "backups"
  | "webhooks"

// Export job status
export type ExportJobStatus = "pending" | "processing" | "completed" | "failed"

// Export job interface
export interface ExportJob {
  id: string
  timestamp: string
  type: ExportType
  format: ExportFormat
  status: ExportJobStatus
  parameters: Record<string, any>
  result?: string
  error?: string
  username: string
}

// Export jobs key
const EXPORT_JOBS_KEY = "system:export_jobs"

// Create an export job
export async function createExportJob(
  type: ExportType,
  format: ExportFormat,
  parameters: Record<string, any>,
  username: string,
): Promise<string> {
  try {
    const jobId = `export_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`

    const job: ExportJob = {
      id: jobId,
      timestamp: new Date().toISOString(),
      type,
      format,
      status: "pending",
      parameters,
      username,
    }

    // Save job to Redis
    await redis.hset(EXPORT_JOBS_KEY, jobId, JSON.stringify(job))

    // Log activity
    await logActivity("export_data", username, { jobId, type, format, parameters })

    // Process the job asynchronously
    processExportJob(jobId).catch((error) => {
      logError(error, { context: "processExportJob", jobId })
    })

    return jobId
  } catch (error) {
    logError(error, { context: "createExportJob", type, format, parameters })
    throw error
  }
}

// Get an export job
export async function getExportJob(jobId: string): Promise<ExportJob | null> {
  try {
    const job = await redis.hget(EXPORT_JOBS_KEY, jobId)

    if (!job) {
      return null
    }

    return JSON.parse(job)
  } catch (error) {
    logError(error, { context: "getExportJob", jobId })
    return null
  }
}

// Get all export jobs
export async function getExportJobs(username?: string): Promise<ExportJob[]> {
  try {
    const jobs = await redis.hgetall(EXPORT_JOBS_KEY)

    if (!jobs) {
      return []
    }

    const parsedJobs = Object.values(jobs).map((job) => JSON.parse(job) as ExportJob)

    // Filter by username if provided
    if (username) {
      return parsedJobs.filter((job) => job.username === username)
    }

    return parsedJobs
  } catch (error) {
    logError(error, { context: "getExportJobs", username })
    return []
  }
}

// Delete an export job
export async function deleteExportJob(jobId: string): Promise<boolean> {
  try {
    const exists = await redis.hexists(EXPORT_JOBS_KEY, jobId)

    if (!exists) {
      return false
    }

    await redis.hdel(EXPORT_JOBS_KEY, jobId)
    return true
  } catch (error) {
    logError(error, { context: "deleteExportJob", jobId })
    return false
  }
}

// Process an export job
async function processExportJob(jobId: string): Promise<void> {
  try {
    // Get the job
    const jobData = await redis.hget(EXPORT_JOBS_KEY, jobId)

    if (!jobData) {
      throw new Error(`Export job ${jobId} not found`)
    }

    const job = JSON.parse(jobData) as ExportJob

    // Update job status to processing
    job.status = "processing"
    await redis.hset(EXPORT_JOBS_KEY, jobId, JSON.stringify(job))

    // Process the job based on type
    let result: any

    switch (job.type) {
      case "games":
        result = await exportGames()
        break
      case "game":
        result = await exportGame(job.parameters.placeId)
        break
      case "stores":
        result = await exportStores(job.parameters.placeId)
        break
      case "store":
        result = await exportStore(job.parameters.placeId, job.parameters.storeName)
        break
      case "bans":
        result = await exportBans()
        break
      case "users":
        result = await exportUsers()
        break
      case "activity_log":
        result = await exportActivityLog(job.parameters.limit)
        break
      case "error_log":
        result = await exportErrorLog(job.parameters.limit)
        break
      case "performance_metrics":
        result = await exportPerformanceMetrics(job.parameters.type, job.parameters.limit)
        break
      case "system_status":
        result = await exportSystemStatus()
        break
      case "backups":
        result = await exportBackups()
        break
      case "webhooks":
        result = await exportWebhooks()
        break
      default:
        throw new Error(`Unknown export type: ${job.type}`)
    }

    // Format the result based on the requested format
    let formattedResult: string

    switch (job.format) {
      case "json":
        formattedResult = JSON.stringify(result, null, 2)
        break
      case "csv":
        formattedResult = convertToCSV(result)
        break
      case "xml":
        formattedResult = convertToXML(result)
        break
      default:
        formattedResult = JSON.stringify(result)
    }

    // Update job with result
    job.status = "completed"
    job.result = formattedResult
    await redis.hset(EXPORT_JOBS_KEY, jobId, JSON.stringify(job))
  } catch (error) {
    // Update job with error
    const jobData = await redis.hget(EXPORT_JOBS_KEY, jobId)

    if (jobData) {
      const job = JSON.parse(jobData) as ExportJob
      job.status = "failed"
      job.error = error.message
      await redis.hset(EXPORT_JOBS_KEY, jobId, JSON.stringify(job))
    }

    logError(error, { context: "processExportJob", jobId })
  }
}

// Helper functions for data export
async function exportGames(): Promise<any> {
  const games = await redis.get("games:all")
  return games ? JSON.parse(games) : []
}

async function exportGame(placeId: number): Promise<any> {
  const game = await redis.get(`games:${placeId}`)
  return game ? JSON.parse(game) : null
}

async function exportStores(placeId: number): Promise<any> {
  const stores = await redis.get(`stores:${placeId}`)
  return stores ? JSON.parse(stores) : []
}

async function exportStore(placeId: number, storeName: string): Promise<any> {
  const store = await redis.get(`store:${placeId}:${storeName}`)
  return store ? JSON.parse(store) : null
}

async function exportBans(): Promise<any> {
  const bans = await redis.get("bans:recent")
  return bans ? JSON.parse(bans) : []
}

async function exportUsers(): Promise<any> {
  const users = await redis.hgetall("admin:users")

  if (!users) {
    return []
  }

  return Object.entries(users).map(([username, userData]) => {
    const user = JSON.parse(userData)
    return {
      username,
      role: user.role,
      createdAt: user.createdAt,
      lastLogin: user.lastLogin,
    }
  })
}

async function exportActivityLog(limit = 1000): Promise<any> {
  const activities = await redis.lrange("system:activity", 0, limit - 1)
  return activities.map((activity) => JSON.parse(activity))
}

async function exportErrorLog(limit = 1000): Promise<any> {
  const errors = await redis.lrange("system:errors", 0, limit - 1)
  return errors.map((error) => JSON.parse(error))
}

async function exportPerformanceMetrics(type?: string, limit = 1000): Promise<any> {
  const metrics = await redis.lrange("system:performance", 0, limit - 1)
  const parsedMetrics = metrics.map((metric) => JSON.parse(metric))

  if (type) {
    return parsedMetrics.filter((metric) => metric.type === type)
  }

  return parsedMetrics
}

async function exportSystemStatus(): Promise<any> {
  const status = await redis.get("system:status")
  return status ? JSON.parse(status) : []
}

async function exportBackups(): Promise<any> {
  const backups = await redis.get("system:backups")
  return backups ? JSON.parse(backups) : []
}

async function exportWebhooks(): Promise<any> {
  const webhooks = await redis.hgetall("webhooks")

  if (!webhooks) {
    return []
  }

  return Object.values(webhooks).map((webhook) => JSON.parse(webhook))
}

// Helper function to convert data to CSV
function convertToCSV(data: any[]): string {
  if (!Array.isArray(data) || data.length === 0) {
    return ""
  }

  // Get headers
  const headers = Object.keys(data[0])

  // Create CSV rows
  const csvRows = [
    headers.join(","), // Header row
    ...data.map((row) => {
      return headers
        .map((header) => {
          const value = row[header]

          // Handle different value types
          if (value === null || value === undefined) {
            return ""
          }

          if (typeof value === "object") {
            return `"${JSON.stringify(value).replace(/"/g, '""')}"`
          }

          if (typeof value === "string") {
            return `"${value.replace(/"/g, '""')}"`
          }

          return value
        })
        .join(",")
    }),
  ]

  return csvRows.join("\n")
}

// Helper function to convert data to XML
function convertToXML(data: any): string {
  if (Array.isArray(data)) {
    return `<?xml version="1.0" encoding="UTF-8"?>
<root>
  ${data.map((item) => objectToXML(item, "item")).join("\n  ")}
</root>`
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<root>
  ${objectToXML(data, "data")}
</root>`
}

// Helper function to convert an object to XML
function objectToXML(obj: any, tagName: string): string {
  if (obj === null || obj === undefined) {
    return `<${tagName}/>`
  }

  if (typeof obj !== "object") {
    return `<${tagName}>${escapeXML(String(obj))}</${tagName}>`
  }

  if (Array.isArray(obj)) {
    return `<${tagName}>
    ${obj.map((item, index) => objectToXML(item, `item_${index}`)).join("\n    ")}
  </${tagName}>`
  }

  return `<${tagName}>
    ${Object.entries(obj)
      .map(([key, value]) => objectToXML(value, key))
      .join("\n    ")}
  </${tagName}>`
}

// Helper function to escape XML special characters
function escapeXML(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;")
}
