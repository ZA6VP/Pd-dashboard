import { sendServerErrorToDiscord } from "./discord-webhook"

// Map of known error reference codes to their descriptions
const KNOWN_ERROR_REFERENCES: Record<string, string> = {
  "1968665631":
    "Application initialization error - This typically occurs when the application fails to start properly due to missing environment variables, database connection issues, or initialization failures.",
}

// Handle specific error reference codes
export async function handleSpecificErrorReference(referenceCode: string): Promise<boolean> {
  // Check if this is a known error reference
  const knownErrorDescription = KNOWN_ERROR_REFERENCES[referenceCode]

  if (knownErrorDescription) {
    // Send a more detailed explanation to Discord
    await sendServerErrorToDiscord(referenceCode, knownErrorDescription, null, {
      knownIssue: true,
      possibleSolutions: [
        "Check all required environment variables are set correctly",
        "Verify database connections are working",
        "Check Redis connection",
        "Review recent code changes that might affect initialization",
        "Check server logs for more detailed error information",
      ],
    })
    return true
  }

  return false
}
