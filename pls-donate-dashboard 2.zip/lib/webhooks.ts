import { queueWebhook } from "./webhook-queue"
import redis from "./redis"

// Webhook types
export type WebhookProvider = "discord" | "slack" | "custom"

export interface WebhookConfig {
  id: string
  name: string
  provider: WebhookProvider
  url: string
  events: string[]
  enabled: boolean
  createdAt: Date
  lastTriggered?: Date
}

export interface WebhookPayload {
  event: string
  data: any
  timestamp: string
}

// Send webhook notification
export async function sendWebhook(config: WebhookConfig, event: string, data: any) {
  if (!config.enabled || !config.url || !config.events.includes(event)) {
    return { success: false, message: "Webhook not enabled for this event" }
  }

  try {
    // Queue the webhook instead of sending directly
    const jobId = await queueWebhook(config, event, data)

    return { success: true, jobId }
  } catch (error) {
    console.error("Webhook error:", error)
    return { success: false, message: error.message }
  }
}

// Get all webhooks
export async function getWebhooks(): Promise<WebhookConfig[]> {
  try {
    const webhooks = ((await redis.get("webhooks:configs")) as WebhookConfig[]) || []
    return webhooks
  } catch (error) {
    console.error("Failed to get webhooks:", error)
    return []
  }
}

// Save webhook
export async function saveWebhook(webhook: WebhookConfig): Promise<WebhookConfig> {
  try {
    const webhooks = await getWebhooks()

    // Check if webhook exists
    const index = webhooks.findIndex((w) => w.id === webhook.id)

    if (index >= 0) {
      // Update existing webhook
      webhooks[index] = webhook
    } else {
      // Add new webhook
      webhooks.push(webhook)
    }

    // Save webhooks
    await redis.set("webhooks:configs", webhooks)

    return webhook
  } catch (error) {
    console.error("Failed to save webhook:", error)
    throw error
  }
}

// Delete webhook
export async function deleteWebhook(id: string): Promise<boolean> {
  try {
    const webhooks = await getWebhooks()

    // Filter out the webhook to delete
    const filteredWebhooks = webhooks.filter((w) => w.id !== id)

    // Save webhooks
    await redis.set("webhooks:configs", filteredWebhooks)

    return true
  } catch (error) {
    console.error("Failed to delete webhook:", error)
    return false
  }
}

// Format payload for Discord
function formatDiscordPayload(payload: WebhookPayload) {
  let color = 0x3b82f6 // Blue
  let title = "PLS DONATE Dashboard Notification"

  // Set color and title based on event
  switch (payload.event) {
    case "game_update":
      title = "Game Update"
      break
    case "user_ban":
      title = "User Banned"
      color = 0xef4444 // Red
      break
    case "donation":
      title = "New Donation"
      color = 0x10b981 // Green
      break
  }

  // Create fields based on data
  const fields = Object.entries(payload.data).map(([name, value]) => ({
    name,
    value: String(value),
    inline: true,
  }))

  return {
    embeds: [
      {
        title,
        color,
        fields,
        timestamp: payload.timestamp,
        footer: {
          text: "PLS DONATE Dashboard",
        },
      },
    ],
  }
}

// Format payload for Slack
function formatSlackPayload(payload: WebhookPayload) {
  let color = "#3b82f6" // Blue

  // Set color based on event
  switch (payload.event) {
    case "user_ban":
      color = "#ef4444" // Red
      break
    case "donation":
      color = "#10b981" // Green
      break
  }

  // Create fields based on data
  const fields = Object.entries(payload.data).map(([name, value]) => ({
    title: name,
    value: String(value),
    short: true,
  }))

  return {
    attachments: [
      {
        color,
        pretext: `PLS DONATE Dashboard: ${payload.event}`,
        fields,
        ts: Math.floor(new Date(payload.timestamp).getTime() / 1000),
      },
    ],
  }
}
