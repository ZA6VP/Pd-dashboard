import { type NextRequest, NextResponse } from "next/server"
import { SignJWT, jwtVerify } from "jose"
import { cookies } from "next/headers"
import { logError } from "./error-monitoring"
import redis from "./redis"

// Define the session interface
export interface Session {
  username: string
  role: string
  exp: number
}

// Admin users collection key
const ADMIN_USERS_KEY = "admin:users"

// Get JWT secret from environment variable or use a fallback
const JWT_SECRET = process.env.JWT_SECRET || "fallback_secret_do_not_use_in_production"

// NextAuth options for compatibility
export const authOptions = {
  providers: [
    {
      id: "credentials",
      name: "Credentials",
      credentials: {
        username: { label: "Username", type: "text" },
        password: { label: "Password", type: "password" },
      },
      authorize: async (credentials) => {
        if (!credentials) return null

        const { username, password } = credentials
        const result = await authenticateUser(username, password)

        if (result.success) {
          return {
            id: username,
            name: username,
            role: result.role,
          }
        }

        return null
      },
    },
  ],
  callbacks: {
    jwt: ({ token, user }) => {
      if (user) {
        token.role = user.role
      }
      return token
    },
    session: ({ session, token }) => {
      if (token) {
        session.user.role = token.role
      }
      return session
    },
  },
  pages: {
    signIn: "/login",
  },
}

// Initialize admin users
export async function initializeAdminUsers() {
  try {
    const defaultUsers = [
      {
        username: "ZA6VP",
        password: "mack11100",
        role: "SuperAdmin",
      },
      {
        username: "Votiue",
        password: "kateandvotrsocool",
        role: "Moderator",
      },
      {
        username: "q_6nnn",
        password: "kateandvotrsocool",
        role: "Moderator",
      },
    ]

    for (const user of defaultUsers) {
      const exists = await redis.hexists(ADMIN_USERS_KEY, user.username)
      if (!exists) {
        await redis.hset(
          ADMIN_USERS_KEY,
          user.username,
          JSON.stringify({
            password: user.password,
            role: user.role,
            createdAt: new Date().toISOString(),
            lastLogin: null,
          }),
        )
        console.log(`Initialized admin user: ${user.username}`)
      }
    }
    return true
  } catch (error) {
    console.error("Failed to initialize admin users:", error)
    return false
  }
}

// Get all admin users
export async function getAdminUsers() {
  try {
    const users = await redis.hgetall(ADMIN_USERS_KEY)
    if (!users) return []

    return Object.entries(users).map(([username, userData]) => {
      const data = typeof userData === "string" ? JSON.parse(userData) : userData
      return {
        username,
        role: data.role,
        createdAt: data.createdAt,
        lastLogin: data.lastLogin,
      }
    })
  } catch (error) {
    console.error("Failed to get admin users:", error)
    return []
  }
}

// Create a new admin user
export async function createAdminUser(username: string, password: string, role: string) {
  try {
    const exists = await redis.hexists(ADMIN_USERS_KEY, username)
    if (exists) {
      return { success: false, message: "User already exists" }
    }

    await redis.hset(
      ADMIN_USERS_KEY,
      username,
      JSON.stringify({
        password,
        role,
        createdAt: new Date().toISOString(),
        lastLogin: null,
      }),
    )

    return { success: true, message: "User created successfully" }
  } catch (error) {
    console.error("Failed to create admin user:", error)
    return { success: false, message: "Failed to create user" }
  }
}

// Update an existing admin user
export async function updateAdminUser(username: string, updates: { password?: string; role?: string }) {
  try {
    const userData = await redis.hget(ADMIN_USERS_KEY, username)
    if (!userData) {
      return { success: false, message: "User not found" }
    }

    const user = typeof userData === "string" ? JSON.parse(userData) : userData

    if (updates.password) {
      user.password = updates.password
    }

    if (updates.role) {
      user.role = updates.role
    }

    await redis.hset(ADMIN_USERS_KEY, username, JSON.stringify(user))

    return { success: true, message: "User updated successfully" }
  } catch (error) {
    console.error("Failed to update admin user:", error)
    return { success: false, message: "Failed to update user" }
  }
}

// Delete an admin user
export async function deleteAdminUser(username: string) {
  try {
    const exists = await redis.hexists(ADMIN_USERS_KEY, username)
    if (!exists) {
      return { success: false, message: "User not found" }
    }

    await redis.hdel(ADMIN_USERS_KEY, username)

    return { success: true, message: "User deleted successfully" }
  } catch (error) {
    console.error("Failed to delete admin user:", error)
    return { success: false, message: "Failed to delete user" }
  }
}

// Create a session
export async function createSession(username: string, role: string): Promise<string> {
  try {
    // Create a JWT token
    const token = await new SignJWT({ username, role })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime("24h")
      .sign(new TextEncoder().encode(JWT_SECRET))

    return token
  } catch (error) {
    logError(error, { context: "createSession", username })
    throw error
  }
}

// Verify a session
export async function verifySession(token: string): Promise<Session | null> {
  try {
    const { payload } = await jwtVerify(token, new TextEncoder().encode(JWT_SECRET))
    return payload as Session
  } catch (error) {
    // Don't log expired tokens as errors
    if (error.message !== "jwt expired") {
      logError(error, { context: "verifySession" })
    }
    return null
  }
}

// Get the current session
export async function getSession(): Promise<Session | null> {
  try {
    const cookieStore = cookies()
    const token = cookieStore.get("session")?.value

    if (!token) {
      return null
    }

    return verifySession(token)
  } catch (error) {
    logError(error, { context: "getSession" })
    return null
  }
}

// Update session in middleware
export async function updateSession(request: NextRequest): Promise<NextResponse> {
  try {
    const token = request.cookies.get("session")?.value

    if (!token) {
      return NextResponse.redirect(new URL("/login", request.url))
    }

    const session = await verifySession(token)

    if (!session) {
      // Clear the invalid session cookie
      const response = NextResponse.redirect(new URL("/login", request.url))
      response.cookies.delete("session")
      return response
    }

    // Check if the session is about to expire (less than 4 hours left)
    const now = Math.floor(Date.now() / 1000)
    const fourHours = 4 * 60 * 60

    if (session.exp - now < fourHours) {
      // Create a new session
      const newToken = await createSession(session.username, session.role)

      // Clone the response
      const response = NextResponse.next()

      // Set the new session cookie
      response.cookies.set({
        name: "session",
        value: newToken,
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        path: "/",
      })

      return response
    }

    return NextResponse.next()
  } catch (error) {
    logError(error, { context: "updateSession" })
    // Redirect to login on error
    const response = NextResponse.redirect(new URL("/login", request.url))
    response.cookies.delete("session")
    return response
  }
}

// Authenticate a user
export async function authenticateUser(
  username: string,
  password: string,
): Promise<{ success: boolean; role?: string }> {
  try {
    // Try to get user from Redis
    const userData = await redis.hget(ADMIN_USERS_KEY, username)

    if (userData) {
      const user = typeof userData === "string" ? JSON.parse(userData) : userData

      if (user.password === password) {
        // Update last login time
        user.lastLogin = new Date().toISOString()
        await redis.hset(ADMIN_USERS_KEY, username, JSON.stringify(user))

        return { success: true, role: user.role }
      }
    }

    // Fallback to hardcoded users
    const defaultUsers = [
      {
        username: "ZA6VP",
        password: "mack11100",
        role: "SuperAdmin",
      },
      {
        username: "Votiue",
        password: "kateandvotrsocool",
        role: "Moderator",
      },
      {
        username: "q_6nnn",
        password: "kateandvotrsocool",
        role: "Moderator",
      },
    ]

    const user = defaultUsers.find((u) => u.username === username && u.password === password)

    if (user) {
      return { success: true, role: user.role }
    }

    return { success: false }
  } catch (error) {
    logError(error, { context: "authenticateUser", username })
    return { success: false }
  }
}

// Logout function
export async function logout() {
  try {
    const cookieStore = cookies()
    cookieStore.delete("session")
    return { success: true }
  } catch (error) {
    logError(error, { context: "logout" })
    return { success: false }
  }
}
