import redis from "./redis"
import { logError } from "./error-monitoring"

// Backup metadata key
const BACKUP_METADATA_KEY = "system:backups"

// Backup interface
export interface Backup {
  id: string
  timestamp: string
  size: number
  keys: number
  status: "completed" | "failed" | "in_progress"
  error?: string
}

// Get backup metadata
export async function getBackupMetadata(): Promise<Backup[]> {
  try {
    const metadata = await redis.get(BACKUP_METADATA_KEY)

    if (!metadata) {
      return []
    }

    return JSON.parse(metadata)
  } catch (error) {
    logError(error, { context: "getBackupMetadata" })
    return []
  }
}

// Create a backup
export async function createBackup(): Promise<Backup | null> {
  try {
    // Generate backup ID
    const backupId = `backup-${Date.now()}`

    // Create backup metadata
    const backup: Backup = {
      id: backupId,
      timestamp: new Date().toISOString(),
      size: 0,
      keys: 0,
      status: "in_progress",
    }

    // Update backup metadata
    const backups = await getBackupMetadata()
    backups.unshift(backup)
    await redis.set(BACKUP_METADATA_KEY, JSON.stringify(backups.slice(0, 10))) // Keep only 10 most recent backups

    // Get all keys
    const keys = await redis.keys("*")

    // Create backup data
    const backupData: Record<string, any> = {}
    let totalSize = 0

    for (const key of keys) {
      // Skip backup metadata
      if (key === BACKUP_METADATA_KEY) continue

      // Get key type
      const type = await redis.type(key)

      // Backup based on type
      let value

      switch (type) {
        case "string":
          value = await redis.get(key)
          break
        case "hash":
          value = await redis.hgetall(key)
          break
        case "list":
          value = await redis.lrange(key, 0, -1)
          break
        case "set":
          value = await redis.smembers(key)
          break
        case "zset":
          value = await redis.zrange(key, 0, -1, "WITHSCORES")
          break
        default:
          value = null
      }

      if (value) {
        backupData[key] = { type, value }
        totalSize += JSON.stringify(value).length
      }
    }

    // Store backup data
    await redis.set(`backup:${backupId}`, JSON.stringify(backupData))

    // Update backup metadata
    backup.status = "completed"
    backup.size = totalSize
    backup.keys = Object.keys(backupData).length

    const updatedBackups = await getBackupMetadata()
    const backupIndex = updatedBackups.findIndex((b) => b.id === backupId)

    if (backupIndex !== -1) {
      updatedBackups[backupIndex] = backup
      await redis.set(BACKUP_METADATA_KEY, JSON.stringify(updatedBackups))
    }

    return backup
  } catch (error) {
    // Update backup metadata with error
    const backups = await getBackupMetadata()
    const backupIndex = backups.findIndex((b) => b.status === "in_progress")

    if (backupIndex !== -1) {
      backups[backupIndex].status = "failed"
      backups[backupIndex].error = error.message
      await redis.set(BACKUP_METADATA_KEY, JSON.stringify(backups))
    }

    logError(error, { context: "createBackup" })
    return null
  }
}

// Restore from backup
export async function restoreFromBackup(backupId: string): Promise<boolean> {
  try {
    // Get backup data
    const backupData = await redis.get(`backup:${backupId}`)

    if (!backupData) {
      throw new Error(`Backup ${backupId} not found`)
    }

    const data = JSON.parse(backupData)

    // Restore each key
    for (const [key, { type, value }] of Object.entries(data)) {
      // Skip backup metadata
      if (key === BACKUP_METADATA_KEY) continue

      // Delete existing key
      await redis.del(key)

      // Restore based on type
      switch (type) {
        case "string":
          await redis.set(key, value)
          break
        case "hash":
          for (const [field, val] of Object.entries(value)) {
            await redis.hset(key, field, val)
          }
          break
        case "list":
          if (value.length > 0) {
            await redis.rpush(key, ...value)
          }
          break
        case "set":
          if (value.length > 0) {
            await redis.sadd(key, ...value)
          }
          break
        case "zset":
          for (let i = 0; i < value.length; i += 2) {
            await redis.zadd(key, value[i + 1], value[i])
          }
          break
      }
    }

    return true
  } catch (error) {
    logError(error, { context: "restoreFromBackup", backupId })
    return false
  }
}

// Delete a backup
export async function deleteBackup(backupId: string): Promise<boolean> {
  try {
    // Delete backup data
    await redis.del(`backup:${backupId}`)

    // Update backup metadata
    const backups = await getBackupMetadata()
    const updatedBackups = backups.filter((b) => b.id !== backupId)
    await redis.set(BACKUP_METADATA_KEY, JSON.stringify(updatedBackups))

    return true
  } catch (error) {
    logError(error, { context: "deleteBackup", backupId })
    return false
  }
}

// Schedule automatic backups (call this on server startup)
export async function scheduleAutomaticBackups() {
  // Create initial backup
  await createBackup()

  // Schedule daily backups if in production
  if (process.env.NODE_ENV === "production" && typeof setInterval !== "undefined") {
    // Run daily at midnight
    const now = new Date()
    const midnight = new Date(now)
    midnight.setHours(24, 0, 0, 0)

    const msUntilMidnight = midnight.getTime() - now.getTime()

    // Schedule first backup at midnight
    setTimeout(() => {
      createBackup()

      // Then schedule daily
      setInterval(createBackup, 24 * 60 * 60 * 1000)
    }, msUntilMidnight)
  }
}
