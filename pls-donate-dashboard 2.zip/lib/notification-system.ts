import redis from "./redis"

// Notification types
export type NotificationType =
  | "system"
  | "security"
  | "user"
  | "game"
  | "webhook"
  | "backup"
  | "error"
  | "performance"
  | "maintenance"
  | "donation"
  | "ban"

// Notification priority
export type NotificationPriority = "low" | "medium" | "high" | "critical"

// Notification channels
export type NotificationChannel = "app" | "email" | "discord" | "slack"

// Notification interface
export interface Notification {
  id: string
  timestamp: string
  type: NotificationType
  priority: NotificationPriority
  title: string
  message: string
  details?: Record<string, any>
  read: boolean
  username: string
  batchKey?: string
  batchCount?: number
}

// User notification settings interface
export interface NotificationSettings {
  enabled: boolean
  channels: {
    [key in NotificationChannel]: boolean
  }
  types: {
    [key in NotificationType]: boolean
  }
  minPriority: NotificationPriority
  batchingEnabled: boolean
  batchingInterval: number // in minutes
  emailAddress?: string
}

// Default notification settings
export const DEFAULT_NOTIFICATION_SETTINGS: NotificationSettings = {
  enabled: true,
  channels: {
    app: true,
    email: false,
    discord: true,
    slack: false,
  },
  types: {
    system: true,
    security: true,
    user: true,
    game: true,
    webhook: true,
    backup: true,
    error: true,
    performance: true,
    maintenance: true,
    donation: true,
    ban: true,
  },
  minPriority: "medium",
  batchingEnabled: true,
  batchingInterval: 15, // 15 minutes
}

// Notification keys
const NOTIFICATIONS_KEY = "notifications"
const NOTIFICATION_SETTINGS_KEY = "notification_settings"
const NOTIFICATION_BATCH_KEY = "notification_batches"

// Create a notification
export async function createNotification(
  type: NotificationType,
  priority: NotificationPriority,
  title: string,
  message: string,
  username: string,
  details: Record<string, any> = {},
  batchKey?: string,
): Promise<string> {
  try {
    // Check if user has notifications enabled for this type and priority
    const settings = await getUserNotificationSettings(username)

    if (!settings.enabled || !settings.types[type] || !shouldSendByPriority(priority, settings.minPriority)) {
      // Skip notification if user has disabled this type or priority
      return null
    }

    // Check if batching is enabled and a batch key is provided
    if (settings.batchingEnabled && batchKey) {
      try {
        const batchResult = await handleBatchedNotification(
          type,
          priority,
          title,
          message,
          username,
          details,
          batchKey,
          settings,
        )

        if (batchResult) {
          return batchResult
        }
      } catch (batchError) {
        console.error("Failed to handle batched notification:", batchError)
        // Continue with creating a regular notification
      }
    }

    const notificationId = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`

    const notification: Notification = {
      id: notificationId,
      timestamp: new Date().toISOString(),
      type,
      priority,
      title,
      message,
      details,
      read: false,
      username,
      batchKey,
      batchCount: 1,
    }

    // Save notification to Redis
    await redis.hset(NOTIFICATIONS_KEY, notificationId, JSON.stringify(notification))

    // Send to appropriate channels based on settings
    try {
      await sendToEnabledChannels(notification, settings)
    } catch (channelError) {
      console.error("Failed to send notification to channels:", channelError)
      // Continue anyway
    }

    return notificationId
  } catch (error) {
    console.error("Failed to create notification:", error)
    return null
  }
}

// Handle batched notifications
async function handleBatchedNotification(
  type: NotificationType,
  priority: NotificationPriority,
  title: string,
  message: string,
  username: string,
  details: Record<string, any>,
  batchKey: string,
  settings: NotificationSettings,
): Promise<string | null> {
  try {
    const batchId = `batch_${username}_${batchKey}`
    const existingBatch = await redis.hget(NOTIFICATION_BATCH_KEY, batchId)

    if (existingBatch) {
      // Update existing batch
      const batchData = JSON.parse(existingBatch)
      batchData.count += 1
      batchData.lastUpdated = new Date().toISOString()

      // Update batch in Redis
      await redis.hset(NOTIFICATION_BATCH_KEY, batchId, JSON.stringify(batchData))

      // If this is not time to send yet, just return the batch ID
      if (new Date().getTime() - new Date(batchData.created).getTime() < settings.batchingInterval * 60 * 1000) {
        return batchId
      }

      // It's time to send the batched notification
      const notificationId = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`

      const notification: Notification = {
        id: notificationId,
        timestamp: new Date().toISOString(),
        type,
        priority,
        title: `${title} (${batchData.count} events)`,
        message: `${message} - ${batchData.count} similar events occurred.`,
        details: { ...details, batchedEvents: batchData.count },
        read: false,
        username,
        batchKey,
        batchCount: batchData.count,
      }

      // Save notification to Redis
      await redis.hset(NOTIFICATIONS_KEY, notificationId, JSON.stringify(notification))

      // Send to appropriate channels
      await sendToEnabledChannels(notification, settings)

      // Delete the batch
      await redis.hdel(NOTIFICATION_BATCH_KEY, batchId)

      return notificationId
    } else {
      // Create new batch
      const batchData = {
        type,
        priority,
        title,
        message,
        count: 1,
        created: new Date().toISOString(),
        lastUpdated: new Date().toISOString(),
      }

      // Save batch to Redis
      await redis.hset(NOTIFICATION_BATCH_KEY, batchId, JSON.stringify(batchData))

      // For the first event in a batch, create a notification immediately
      return null
    }
  } catch (error) {
    console.error("Failed to handle batched notification:", error)
    return null
  }
}

// Send notification to enabled channels
async function sendToEnabledChannels(notification: Notification, settings: NotificationSettings) {
  try {
    // Publish to WebSocket for real-time updates in the app
    if (settings.channels.app) {
      try {
        await redis.publish(
          "notifications",
          JSON.stringify({
            type: "NEW_NOTIFICATION",
            notification,
          }),
        )
      } catch (error) {
        console.error("Failed to publish notification to WebSocket:", error)
      }
    }

    // Send to Discord if enabled
    if (settings.channels.discord) {
      try {
        // Import dynamically to avoid circular dependencies
        const { sendDiscordMessage } = await import("./discord-webhook")
        await sendDiscordMessage(
          notification.type as any,
          notification.title,
          notification.message,
          [
            {
              name: "Priority",
              value: notification.priority,
              inline: true,
            },
            {
              name: "Time",
              value: new Date(notification.timestamp).toLocaleString(),
              inline: true,
            },
          ],
          notification.details || {},
        )
      } catch (error) {
        console.error("Failed to send notification to Discord:", error)
      }
    }

    // Send to Slack if enabled
    if (settings.channels.slack) {
      try {
        // Import dynamically to avoid circular dependencies
        const { sendSlackMessage } = await import("./slack-webhook")
        await sendSlackMessage(
          notification.type,
          notification.priority,
          notification.title,
          notification.message,
          notification.details || {},
        )
      } catch (error) {
        console.error("Failed to send notification to Slack:", error)
      }
    }

    // Send email if enabled and it's high priority or critical
    if (
      settings.channels.email &&
      settings.emailAddress &&
      (notification.priority === "high" || notification.priority === "critical")
    ) {
      try {
        // Import dynamically to avoid circular dependencies
        const { sendEmail } = await import("./email-service")
        await sendEmail(
          settings.emailAddress,
          `[${notification.priority.toUpperCase()}] ${notification.title}`,
          notification.message,
          notification.details,
        )
      } catch (error) {
        console.error("Failed to send notification email:", error)
      }
    }
  } catch (error) {
    console.error("Failed to send notification to channels:", error)
  }
}

// Get user notifications
export async function getUserNotifications(
  username: string,
  options: {
    includeRead?: boolean
    types?: NotificationType[]
    priority?: NotificationPriority
    limit?: number
    offset?: number
  } = {},
): Promise<{ notifications: Notification[]; total: number }> {
  try {
    const { includeRead = false, types, priority, limit = 50, offset = 0 } = options

    const notifications = await redis.hgetall(NOTIFICATIONS_KEY)

    if (!notifications) {
      return { notifications: [], total: 0 }
    }

    let userNotifications = Object.values(notifications)
      .map((notification) => {
        try {
          return JSON.parse(notification) as Notification
        } catch (error) {
          console.error("Failed to parse notification:", error)
          return null
        }
      })
      .filter(Boolean) // Remove null values
      .filter((notification) => notification.username === username)
      .filter((notification) => includeRead || !notification.read)

    // Apply type filter if specified
    if (types && types.length > 0) {
      userNotifications = userNotifications.filter((notification) => types.includes(notification.type))
    }

    // Apply priority filter if specified
    if (priority) {
      userNotifications = userNotifications.filter((notification) =>
        shouldSendByPriority(notification.priority, priority),
      )
    }

    // Sort by timestamp (newest first)
    userNotifications.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

    const total = userNotifications.length

    // Apply pagination
    const paginatedNotifications = userNotifications.slice(offset, offset + limit)

    return {
      notifications: paginatedNotifications,
      total,
    }
  } catch (error) {
    console.error("Failed to get user notifications:", error)
    return { notifications: [], total: 0 }
  }
}

// Mark notification as read
export async function markNotificationAsRead(notificationId: string): Promise<boolean> {
  try {
    const notification = await redis.hget(NOTIFICATIONS_KEY, notificationId)

    if (!notification) {
      return false
    }

    const parsedNotification = JSON.parse(notification) as Notification
    parsedNotification.read = true

    await redis.hset(NOTIFICATIONS_KEY, notificationId, JSON.stringify(parsedNotification))

    return true
  } catch (error) {
    console.error("Failed to mark notification as read:", error)
    return false
  }
}

// Mark all notifications as read
export async function markAllNotificationsAsRead(username: string): Promise<boolean> {
  try {
    const notifications = await redis.hgetall(NOTIFICATIONS_KEY)

    if (!notifications) {
      return true
    }

    for (const [id, notificationJson] of Object.entries(notifications)) {
      try {
        const notification = JSON.parse(notificationJson) as Notification

        if (notification.username === username && !notification.read) {
          notification.read = true
          await redis.hset(NOTIFICATIONS_KEY, id, JSON.stringify(notification))
        }
      } catch (error) {
        console.error("Failed to parse notification:", error)
        // Continue with other notifications
      }
    }

    return true
  } catch (error) {
    console.error("Failed to mark all notifications as read:", error)
    return false
  }
}

// Delete a notification
export async function deleteNotification(notificationId: string): Promise<boolean> {
  try {
    const exists = await redis.hexists(NOTIFICATIONS_KEY, notificationId)

    if (!exists) {
      return false
    }

    await redis.hdel(NOTIFICATIONS_KEY, notificationId)
    return true
  } catch (error) {
    console.error("Failed to delete notification:", error)
    return false
  }
}

// Get user notification settings
export async function getUserNotificationSettings(username: string): Promise<NotificationSettings> {
  try {
    const settings = await redis.hget(NOTIFICATION_SETTINGS_KEY, username)

    if (!settings) {
      return DEFAULT_NOTIFICATION_SETTINGS
    }

    return JSON.parse(settings)
  } catch (error) {
    console.error("Failed to get user notification settings:", error)
    return DEFAULT_NOTIFICATION_SETTINGS
  }
}

// Update user notification settings
export async function updateUserNotificationSettings(
  username: string,
  settings: Partial<NotificationSettings>,
): Promise<boolean> {
  try {
    const currentSettings = await getUserNotificationSettings(username)

    const updatedSettings: NotificationSettings = {
      ...currentSettings,
      ...settings,
      channels: {
        ...currentSettings.channels,
        ...(settings.channels || {}),
      },
      types: {
        ...currentSettings.types,
        ...(settings.types || {}),
      },
    }

    await redis.hset(NOTIFICATION_SETTINGS_KEY, username, JSON.stringify(updatedSettings))

    return true
  } catch (error) {
    console.error("Failed to update user notification settings:", error)
    return false
  }
}

// Helper function to determine if notification should be sent based on priority
function shouldSendByPriority(notificationPriority: NotificationPriority, minPriority: NotificationPriority): boolean {
  const priorityValues = {
    low: 0,
    medium: 1,
    high: 2,
    critical: 3,
  }

  return priorityValues[notificationPriority] >= priorityValues[minPriority]
}

// Process batched notifications that are ready to be sent
export async function processBatchedNotifications(): Promise<number> {
  try {
    const batches = await redis.hgetall(NOTIFICATION_BATCH_KEY)

    if (!batches) {
      return 0
    }

    let processedCount = 0

    for (const [batchId, batchJson] of Object.entries(batches)) {
      try {
        const batch = JSON.parse(batchJson)
        const username = batchId.split("_")[1]
        const settings = await getUserNotificationSettings(username)

        // Check if batch is old enough to process
        if (new Date().getTime() - new Date(batch.created).getTime() >= settings.batchingInterval * 60 * 1000) {
          // Create notification from batch
          const notificationId = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`

          const notification: Notification = {
            id: notificationId,
            timestamp: new Date().toISOString(),
            type: batch.type,
            priority: batch.priority,
            title: `${batch.title} (${batch.count} events)`,
            message: `${batch.message} - ${batch.count} similar events occurred.`,
            details: { batchedEvents: batch.count },
            read: false,
            username,
            batchKey: batchId.split("_")[2],
            batchCount: batch.count,
          }

          // Save notification to Redis
          await redis.hset(NOTIFICATIONS_KEY, notificationId, JSON.stringify(notification))

          // Send to appropriate channels
          await sendToEnabledChannels(notification, settings)

          // Delete the batch
          await redis.hdel(NOTIFICATION_BATCH_KEY, batchId)

          processedCount++
        }
      } catch (error) {
        console.error("Failed to process batch:", error)
        // Continue with other batches
      }
    }

    return processedCount
  } catch (error) {
    console.error("Failed to process batched notifications:", error)
    return 0
  }
}
