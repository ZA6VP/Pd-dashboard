import redis from "./redis"
import { SignJWT, jwtVerify } from "jose"

// Session TTL (24 hours)
const SESSION_TTL = 60 * 60 * 24

// JWT secret from environment variable
const JWT_SECRET = process.env.JWT_SECRET

if (!JWT_SECRET) {
  throw new Error("Please define the JWT_SECRET environment variable")
}

const secret = new TextEncoder().encode(JWT_SECRET)

// Create a session
export async function createSession(data: any): Promise<string> {
  // Generate a unique session ID
  const sessionId = `session-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`

  try {
    // Try to store session data in Redis
    await redis.set(`session:${sessionId}`, JSON.stringify(data), { ex: SESSION_TTL })
  } catch (error) {
    console.error("Failed to store session in Redis:", error)
    // Continue with JWT creation even if Redis fails
  }

  // Create JWT with session ID and embedded data for fallback
  const token = await new SignJWT({
    sid: sessionId,
    data: data, // Embed the data in the JWT as fallback
  })
    .setProtectedHeader({ alg: "HS256" })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("24h")
    .sign(secret)

  return token
}

// Get session data
export async function getSessionData(token: string): Promise<any | null> {
  try {
    // Verify JWT
    const { payload } = await jwtVerify(token, secret)

    if (!payload.sid) {
      return null
    }

    try {
      // Try to get session data from Redis
      const sessionData = await redis.get(`session:${payload.sid}`)

      if (sessionData) {
        return JSON.parse(sessionData)
      }
    } catch (redisError) {
      console.error("Failed to get session data from Redis:", redisError)
      // Fall back to embedded data in JWT
    }

    // Fallback to embedded data in JWT if Redis failed or session not found
    if (payload.data) {
      return payload.data
    }

    return null
  } catch (error) {
    console.error("Failed to get session data:", error)
    return null
  }
}

// Delete session
export async function deleteSession(token: string): Promise<boolean> {
  try {
    // Verify JWT
    const { payload } = await jwtVerify(token, secret)

    if (!payload.sid) {
      return false
    }

    // Delete session from Redis
    await redis.del(`session:${payload.sid}`)

    return true
  } catch (error) {
    console.error("Failed to delete session:", error)
    return false
  }
}

// Update session data
export async function updateSessionData(token: string, data: any): Promise<boolean> {
  try {
    // Verify JWT
    const { payload } = await jwtVerify(token, secret)

    if (!payload.sid) {
      return false
    }

    // Get existing session data
    const existingData = await redis.get(`session:${payload.sid}`)

    if (!existingData) {
      return false
    }

    // Update session data
    const updatedData = { ...JSON.parse(existingData), ...data }

    // Store updated session data
    await redis.set(`session:${payload.sid}`, JSON.stringify(updatedData), { ex: SESSION_TTL })

    return true
  } catch (error) {
    console.error("Failed to update session data:", error)
    return false
  }
}
