// Admin roles
export const ADMIN_ROLES = [
  "SuperAdmin",
  "HeadAdmin",
  "SeniorAdmin",
  "Admin",
  "ModeratorPlus",
  "Moderator",
  "JuniorModerator",
  "Trainee",
  "Support",
  "Viewer",
]

// Role permissions
const ROLE_PERMISSIONS = {
  SuperAdmin: [
    "canManageAdmins",
    "canToggleMaintenance",
    "canManageSettings",
    "canManageWebhooks",
    "canViewAuditLog",
    "canManageCache",
    "canBanUsers",
    "canAccessAnalytics",
    "canViewSystemStatus",
    "canManageBackups",
  ],
  HeadAdmin: [
    "canManageAdmins",
    "canToggleMaintenance",
    "canManageSettings",
    "canManageWebhooks",
    "canViewAuditLog",
    "canManageCache",
    "canBanUsers",
    "canAccessAnalytics",
    "canViewSystemStatus",
  ],
  SeniorAdmin: [
    "canManageSettings",
    "canManageWebhooks",
    "canViewAuditLog",
    "canManageCache",
    "canBanUsers",
    "canAccessAnalytics",
    "canViewSystemStatus",
  ],
  Admin: ["canManageSettings", "canManageWebhooks", "canViewAuditLog", "canBanUsers", "canAccessAnalytics"],
  ModeratorPlus: ["canManageSettings", "canViewAuditLog", "canBanUsers", "canAccessAnalytics"],
  Moderator: ["canViewAuditLog", "canBanUsers"],
  JuniorModerator: ["canViewAuditLog"],
  Trainee: [],
  Support: ["canViewAuditLog"],
  Viewer: [],
}

// Check if a role has a permission
export function hasPermission(role: string, permission: keyof typeof ROLE_PERMISSIONS.SuperAdmin) {
  if (!role || !ROLE_PERMISSIONS[role as keyof typeof ROLE_PERMISSIONS]) {
    return false
  }

  return ROLE_PERMISSIONS[role as keyof typeof ROLE_PERMISSIONS].includes(permission)
}

// Get role color
export function getRoleColor(role: string) {
  switch (role) {
    case "SuperAdmin":
      return "text-red-500"
    case "HeadAdmin":
      return "text-purple-500"
    case "SeniorAdmin":
      return "text-indigo-500"
    case "Admin":
      return "text-blue-500"
    case "ModeratorPlus":
      return "text-teal-500"
    case "Moderator":
      return "text-green-500"
    case "JuniorModerator":
      return "text-lime-500"
    case "Trainee":
      return "text-yellow-500"
    case "Support":
      return "text-orange-500"
    case "Viewer":
      return "text-gray-500"
    default:
      return "text-gray-500"
  }
}
