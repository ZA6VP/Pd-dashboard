import redis from "./redis"
import { logError } from "./error-monitoring"

// Activity log key
const ACTIVITY_LOG_KEY = "system:activity"
const ACTIVITY_LOG_MAX_SIZE = 10000 // Maximum number of activities to keep

// Activity types
export type ActivityType =
  | "login"
  | "logout"
  | "view_page"
  | "api_request"
  | "ban_user"
  | "update_settings"
  | "create_backup"
  | "restore_backup"
  | "clear_cache"
  | "webhook_created"
  | "webhook_updated"
  | "webhook_deleted"
  | "admin_created"
  | "admin_updated"
  | "admin_deleted"
  | "maintenance_toggled"
  | "export_data"
  | "security_alert"
  | "system_error"

// Activity interface
export interface Activity {
  id: string
  timestamp: string
  type: ActivityType
  username: string
  details: Record<string, any>
  ip?: string
  userAgent?: string
}

// Log an activity
export async function logActivity(
  type: ActivityType,
  username: string,
  details: Record<string, any> = {},
  request?: Request,
): Promise<boolean> {
  try {
    const activity: Activity = {
      id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`,
      timestamp: new Date().toISOString(),
      type,
      username,
      details,
    }

    // Add request information if available
    if (request) {
      activity.ip = request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "unknown"
      activity.userAgent = request.headers.get("user-agent") || "unknown"
    }

    // Log to Redis
    await redis.lpush(ACTIVITY_LOG_KEY, JSON.stringify(activity))

    // Trim the log to keep it at a reasonable size
    await redis.ltrim(ACTIVITY_LOG_KEY, 0, ACTIVITY_LOG_MAX_SIZE - 1)

    return true
  } catch (error) {
    logError(error, { context: "logActivity", type, username })
    return false
  }
}

// Get recent activities
export async function getRecentActivities(limit = 100, type?: ActivityType, username?: string): Promise<Activity[]> {
  try {
    const activities = await redis.lrange(ACTIVITY_LOG_KEY, 0, limit - 1)

    // Parse activities
    const parsedActivities = activities.map((activity) => JSON.parse(activity) as Activity)

    // Filter by type and username if provided
    return parsedActivities.filter((activity) => {
      if (type && activity.type !== type) return false
      if (username && activity.username !== username) return false
      return true
    })
  } catch (error) {
    logError(error, { context: "getRecentActivities", limit, type, username })
    return []
  }
}

// Get activity statistics
export async function getActivityStatistics(days = 7): Promise<Record<string, number>> {
  try {
    const activities = await redis.lrange(ACTIVITY_LOG_KEY, 0, -1)

    // Parse activities
    const parsedActivities = activities.map((activity) => JSON.parse(activity) as Activity)

    // Filter activities by date
    const cutoffDate = new Date()
    cutoffDate.setDate(cutoffDate.getDate() - days)

    const recentActivities = parsedActivities.filter((activity) => new Date(activity.timestamp) >= cutoffDate)

    // Count activities by type
    const stats: Record<string, number> = {}

    for (const activity of recentActivities) {
      stats[activity.type] = (stats[activity.type] || 0) + 1
    }

    return stats
  } catch (error) {
    logError(error, { context: "getActivityStatistics", days })
    return {}
  }
}

// Clear activity log
export async function clearActivityLog(): Promise<boolean> {
  try {
    await redis.del(ACTIVITY_LOG_KEY)
    return true
  } catch (error) {
    logError(error, { context: "clearActivityLog" })
    return false
  }
}
