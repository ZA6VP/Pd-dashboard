import { type NextRequest, NextResponse } from "next/server"
import { Redis } from "@upstash/redis"

// Initialize Redis client
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL || "",
  token: process.env.UPSTASH_REDIS_REST_TOKEN || "",
})

// Rate limit configuration
type RateLimitConfig = {
  limit: number
  window: number // in seconds
}

const defaultConfig: RateLimitConfig = {
  limit: 60, // 60 requests
  window: 60, // per minute
}

const apiConfig: RateLimitConfig = {
  limit: 120,
  window: 60,
}

const authConfig: RateLimitConfig = {
  limit: 10,
  window: 60,
}

// Get config based on the request path
function getConfig(path: string): RateLimitConfig {
  if (path.startsWith("/api/auth")) {
    return authConfig
  }
  if (path.startsWith("/api/")) {
    return apiConfig
  }
  return defaultConfig
}

// Rate limiter function
export async function rateLimiter(req: NextRequest) {
  // Skip rate limiting in development
  if (process.env.NODE_ENV === "development") {
    return null
  }

  // Get client IP
  const ip = req.ip || "127.0.0.1"
  const path = req.nextUrl.pathname

  // Get rate limit config for this path
  const config = getConfig(path)

  // Create a unique key for this IP and path
  const key = `rate-limit:${ip}:${path}`

  // Get current count and timestamp
  const now = Math.floor(Date.now() / 1000)
  const windowStart = now - config.window

  try {
    // Remove old entries
    await redis.zremrangebyscore(key, 0, windowStart)

    // Get current count
    const count = await redis.zcard(key)

    // Check if limit exceeded
    if (count >= config.limit) {
      return {
        limited: true,
        remaining: 0,
        reset: windowStart + config.window,
      }
    }

    // Add current request
    await redis.zadd(key, now, `${now}-${Math.random()}`)

    // Set expiry on the key
    await redis.expire(key, config.window * 2)

    return {
      limited: false,
      remaining: config.limit - count - 1,
      reset: windowStart + config.window,
    }
  } catch (error) {
    console.error("Rate limiter error:", error)
    // If Redis fails, allow the request
    return null
  }
}

// Middleware to apply rate limiting
export async function applyRateLimit(req: NextRequest) {
  const result = await rateLimiter(req)

  if (!result) {
    return null
  }

  if (result.limited) {
    return NextResponse.json(
      { error: "Too many requests", reset: result.reset },
      {
        status: 429,
        headers: {
          "Retry-After": String(result.reset - Math.floor(Date.now() / 1000)),
          "X-RateLimit-Limit": String(getConfig(req.nextUrl.pathname).limit),
          "X-RateLimit-Remaining": "0",
          "X-RateLimit-Reset": String(result.reset),
        },
      },
    )
  }

  // Continue with the request but add rate limit headers
  const response = NextResponse.next()
  response.headers.set("X-RateLimit-Limit", String(getConfig(req.nextUrl.pathname).limit))
  response.headers.set("X-RateLimit-Remaining", String(result.remaining))
  response.headers.set("X-RateLimit-Reset", String(result.reset))

  return response
}
