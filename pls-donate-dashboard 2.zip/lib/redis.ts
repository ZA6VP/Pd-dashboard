import { Redis } from "@upstash/redis"
import { logError } from "./error-monitoring"

// Create a Redis client
let redisClient: Redis | null = null

try {
  // Check if we have the required environment variables
  if (process.env.REDIS_URL || (process.env.KV_URL && process.env.KV_REST_API_TOKEN)) {
    redisClient = new Redis({
      url: process.env.REDIS_URL || process.env.KV_URL || "",
      token: process.env.KV_REST_API_TOKEN || "",
    })
    console.log("Redis client initialized")
  } else {
    console.warn("Redis environment variables not found, using fallback storage")
  }
} catch (error) {
  console.error("Failed to initialize Redis client:", error)
}

// Create a fallback in-memory storage
const memoryStorage = new Map<string, any>()

// Create a proxy to handle Redis operations with fallbacks
const redis = new Proxy(
  {},
  {
    get: (target, prop) => {
      // If Redis is available, use it
      if (redisClient) {
        return (...args: any[]) => {
          try {
            return redisClient[prop as keyof Redis](...args)
          } catch (error) {
            console.error(`Redis operation ${String(prop)} failed:`, error)
            // Fall back to in-memory storage for some common operations
            return handleFallback(prop, ...args)
          }
        }
      }

      // Otherwise use in-memory fallback
      return (...args: any[]) => handleFallback(prop, ...args)
    },
  },
) as Redis

// Handle fallback operations for common Redis methods
function handleFallback(method: string | symbol, ...args: any[]): any {
  try {
    switch (method) {
      case "get":
        return Promise.resolve(memoryStorage.get(args[0]))
      case "set":
        memoryStorage.set(args[0], args[1])
        return Promise.resolve("OK")
      case "del":
        memoryStorage.delete(args[0])
        return Promise.resolve(1)
      case "hget":
        const hgetMap = memoryStorage.get(args[0]) || new Map()
        return Promise.resolve(hgetMap.get(args[1]))
      case "hset":
        let hsetMap = memoryStorage.get(args[0])
        if (!hsetMap) {
          hsetMap = new Map()
          memoryStorage.set(args[0], hsetMap)
        }
        hsetMap.set(args[1], args[2])
        return Promise.resolve(1)
      case "hgetall":
        const hgetallMap = memoryStorage.get(args[0]) || new Map()
        const obj: Record<string, any> = {}
        hgetallMap.forEach((value, key) => {
          obj[key] = value
        })
        return Promise.resolve(Object.keys(obj).length > 0 ? obj : null)
      case "lpush":
        let list = memoryStorage.get(args[0])
        if (!list) {
          list = []
          memoryStorage.set(args[0], list)
        }
        list.unshift(args[1])
        return Promise.resolve(list.length)
      case "lrange":
        const lrangeList = memoryStorage.get(args[0]) || []
        return Promise.resolve(lrangeList.slice(args[1], args[2] + 1))
      case "ltrim":
        const ltrimList = memoryStorage.get(args[0]) || []
        memoryStorage.set(args[0], ltrimList.slice(args[1], args[2] + 1))
        return Promise.resolve("OK")
      case "publish":
        // No-op for publish in memory mode
        return Promise.resolve(0)
      default:
        console.warn(`Unsupported Redis operation in fallback mode: ${String(method)}`)
        return Promise.resolve(null)
    }
  } catch (error) {
    console.error(`Fallback operation ${String(method)} failed:`, error)
    return Promise.resolve(null)
  }
}

// Cache key prefixes
export const cacheKey = {
  games: () => "games:all",
  game: (placeId: number) => `games:${placeId}`,
  stores: (placeId: number) => `stores:${placeId}`,
  store: (gameId: number, storeName: string) => `store:${gameId}:${storeName}`,
  bans: () => "bans:recent",
  analytics: (period: string) => `analytics:${period}`,
  users: () => "users:all",
  user: (userId: string) => `user:${userId}`,
  notifications: (userId: string) => `notifications:${userId}`,
}

// Cache TTLs in seconds
export const CACHE_TTL = {
  GAMES: 60 * 5, // 5 minutes
  GAME: 60 * 10, // 10 minutes
  STORES: 60 * 15, // 15 minutes
  STORE: 60 * 30, // 30 minutes
  BANS: 60 * 60, // 1 hour
  ANALYTICS: 60 * 60, // 1 hour
  USERS: 60 * 60 * 24, // 24 hours
  USER: 60 * 60, // 1 hour
  NOTIFICATIONS: 60 * 5, // 5 minutes
}

// Function to invalidate cache
export async function invalidateCache(key: string): Promise<void> {
  try {
    await redis.del(key)
    console.log(`Invalidated cache key: ${key}`)
  } catch (error) {
    console.error(`Failed to invalidate cache key ${key}:`, error)
    logError(error, { context: "invalidateCache", key })
  }
}

// Function to cache data with Redis
export async function withCache<T>(cacheKey: string, ttl: number, fn: () => Promise<T>): Promise<T> {
  try {
    // Try to get data from cache
    const cachedData = await redis.get(cacheKey)

    if (cachedData) {
      return JSON.parse(cachedData) as T
    }

    // If data is not in cache, fetch it
    const data = await fn()

    // Store data in cache
    await redis.set(cacheKey, JSON.stringify(data), { ex: ttl })

    return data
  } catch (error) {
    console.error(`Failed to get or set cache key ${cacheKey}:`, error)
    logError(error, { context: "withCache", cacheKey })
    // Return data without caching
    return await fn()
  }
}

export default redis
