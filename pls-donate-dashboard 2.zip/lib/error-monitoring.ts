import redis from "./redis"
import { sendErrorToDiscord, sendServerErrorToDiscord } from "./discord-webhook"

// Error log key
const ERROR_LOG_KEY = "system:errors"
const ERROR_LOG_MAX_SIZE = 1000 // Maximum number of errors to keep

// Generate a reference code for errors
export function generateErrorReference(): string {
  return Math.floor(Math.random() * 10000000000).toString()
}

// Log an error
export async function logError(error: Error | string, context: Record<string, any> = {}) {
  // Generate a reference code if not provided
  const referenceCode = context.referenceCode || generateErrorReference()

  const errorData = {
    timestamp: new Date().toISOString(),
    message: error instanceof Error ? error.message : error,
    stack: error instanceof Error ? error.stack : null,
    referenceCode,
    context,
  }

  console.error(`Error [${referenceCode}]:`, errorData.message, context)

  try {
    // Try to log to Redis
    await redis.lpush(ERROR_LOG_KEY, JSON.stringify(errorData))
    // Trim the log to keep it at a reasonable size
    await redis.ltrim(ERROR_LOG_KEY, 0, ERROR_LOG_MAX_SIZE - 1)

    // Send to Discord webhook
    await sendErrorToDiscord(error, { ...context, referenceCode })

    return true
  } catch (redisError) {
    // If Redis fails, log to console only
    console.error("Failed to log error to Redis:", redisError)

    // Still try to send to Discord even if Redis fails
    try {
      await sendErrorToDiscord(error, { ...context, referenceCode })
    } catch (discordError) {
      console.error("Failed to send error to Discord:", discordError)
    }

    return false
  }
}

// Log a server error with reference code
export async function logServerError(
  referenceCode: string,
  errorMessage: string,
  stack?: string,
  context: Record<string, any> = {},
) {
  console.error(`Server Error [${referenceCode}]:`, errorMessage)

  const errorData = {
    timestamp: new Date().toISOString(),
    message: errorMessage,
    stack,
    referenceCode,
    type: "server_error",
    context,
  }

  try {
    // Try to log to Redis
    await redis.lpush(ERROR_LOG_KEY, JSON.stringify(errorData))
    // Trim the log to keep it at a reasonable size
    await redis.ltrim(ERROR_LOG_KEY, 0, ERROR_LOG_MAX_SIZE - 1)

    // Send to Discord webhook with user-friendly explanation
    await sendServerErrorToDiscord(referenceCode, errorMessage, stack, context)

    return true
  } catch (redisError) {
    console.error("Failed to log server error to Redis:", redisError)

    // Still try to send to Discord even if Redis fails
    try {
      await sendServerErrorToDiscord(referenceCode, errorMessage, stack, context)
    } catch (discordError) {
      console.error("Failed to send server error to Discord:", discordError)
    }

    return false
  }
}

// Get recent errors
export async function getRecentErrors(limit = 100) {
  try {
    const errors = await redis.lrange(ERROR_LOG_KEY, 0, limit - 1)
    return errors.map((error) => JSON.parse(error))
  } catch (error) {
    console.error("Failed to get recent errors:", error)
    return []
  }
}

// Clear error log
export async function clearErrorLog() {
  try {
    await redis.del(ERROR_LOG_KEY)
    return true
  } catch (error) {
    console.error("Failed to clear error log:", error)
    return false
  }
}

// Global error handler for client-side
export function setupClientErrorMonitoring() {
  if (typeof window !== "undefined") {
    window.onerror = (message, source, lineno, colno, error) => {
      // Send to server API
      fetch("/api/system/error", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message,
          source,
          lineno,
          colno,
          stack: error?.stack,
          type: "client",
          referenceCode: generateErrorReference(),
        }),
      }).catch(console.error)

      // Don't prevent default error handling
      return false
    }

    window.addEventListener("unhandledrejection", (event) => {
      fetch("/api/system/error", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: event.reason?.message || "Unhandled Promise Rejection",
          stack: event.reason?.stack,
          type: "client-promise",
          referenceCode: generateErrorReference(),
        }),
      }).catch(console.error)
    })
  }
}
