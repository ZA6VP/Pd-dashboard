import mongoose, { Schema, type Document, type Model } from "mongoose"

// Game model
export interface IGame extends Document {
  placeId: number
  name: string
  ownerUserId: number
  groupId?: number
  lastUpdated: Date
  activePlayers: number
}

const GameSchema = new Schema<IGame>({
  placeId: { type: Number, required: true, unique: true },
  name: { type: String, required: true },
  ownerUserId: { type: Number, required: true },
  groupId: { type: Number },
  lastUpdated: { type: Date, default: Date.now },
  activePlayers: { type: Number, default: 0 },
})

// Store model
export interface IStore extends Document {
  gameId: number
  storeName: string
  data: any
  updatedAt: Date
}

const StoreSchema = new Schema<IStore>({
  gameId: { type: Number, required: true },
  storeName: { type: String, required: true },
  data: { type: Schema.Types.Mixed, required: true },
  updatedAt: { type: Date, default: Date.now },
})

// Ban model
export interface IBan extends Document {
  gameId: number
  userId: number
  reason: string
  createdAt: Date
  expiresAt: Date
}

const BanSchema = new Schema<IBan>({
  gameId: { type: Number, required: true },
  userId: { type: Number, required: true },
  reason: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, required: true },
})

// Audit log model
export interface IAuditLog extends Document {
  action: string
  username: string
  details: any
  timestamp: Date
}

const AuditLogSchema = new Schema<IAuditLog>({
  action: { type: String, required: true },
  username: { type: String, required: true },
  details: { type: Schema.Types.Mixed },
  timestamp: { type: Date, default: Date.now },
})

// Initialize models
let Game: Model<IGame>
let Store: Model<IStore>
let Ban: Model<IBan>
let AuditLog: Model<IAuditLog>

// Handle model initialization for Next.js hot reloading
if (mongoose.models.Game) {
  Game = mongoose.model<IGame>("Game")
  Store = mongoose.model<IStore>("Store")
  Ban = mongoose.model<IBan>("Ban")
  AuditLog = mongoose.model<IAuditLog>("AuditLog")
} else {
  Game = mongoose.model<IGame>("Game", GameSchema)
  Store = mongoose.model<IStore>("Store", StoreSchema)
  Ban = mongoose.model<IBan>("Ban", BanSchema)
  AuditLog = mongoose.model<IAuditLog>("AuditLog", AuditLogSchema)
}

export { Game, Store, Ban, AuditLog }
