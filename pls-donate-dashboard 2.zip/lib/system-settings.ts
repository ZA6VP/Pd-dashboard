import redis from "./redis"

// System settings keys
const SETTINGS_KEYS = {
  MAINTENANCE_MODE: "system:maintenance:enabled",
  MAINTENANCE_MESSAGE: "system:maintenance:message",
  LAST_MAINTENANCE_TOGGLE: "system:maintenance:last_toggle",
  TOGGLED_BY: "system:maintenance:toggled_by",
}

// Default maintenance message
const DEFAULT_MAINTENANCE_MESSAGE =
  "PD Dashboard Is Currently Unavailable. If You're A Huataun Or Zauataun Staff Contact Votiue, ZA6VP and q_6nnn For Help Discord: zzazem (ZA6VP), hexacoder (Votiue), katia814 (q_6nn)"

// Check if maintenance mode is enabled
export async function isMaintenanceMode(): Promise<boolean> {
  try {
    const enabled = await redis.get(SETTINGS_KEYS.MAINTENANCE_MODE)
    return enabled === "true"
  } catch (error) {
    console.error("Failed to check maintenance mode:", error)
    return false
  }
}

// Get maintenance message
export async function getMaintenanceMessage(): Promise<string> {
  try {
    const message = await redis.get(SETTINGS_KEYS.MAINTENANCE_MESSAGE)
    return message || DEFAULT_MAINTENANCE_MESSAGE
  } catch (error) {
    console.error("Failed to get maintenance message:", error)
    return DEFAULT_MAINTENANCE_MESSAGE
  }
}

// Toggle maintenance mode
export async function toggleMaintenanceMode(enabled: boolean, username: string, message?: string): Promise<boolean> {
  try {
    // Set maintenance mode
    await redis.set(SETTINGS_KEYS.MAINTENANCE_MODE, enabled.toString())

    // Set maintenance message if provided
    if (message) {
      await redis.set(SETTINGS_KEYS.MAINTENANCE_MESSAGE, message)
    }

    // Record who toggled maintenance mode and when
    await redis.set(SETTINGS_KEYS.LAST_MAINTENANCE_TOGGLE, new Date().toISOString())
    await redis.set(SETTINGS_KEYS.TOGGLED_BY, username)

    // Log the action
    await redis.lpush(
      "system:logs",
      JSON.stringify({
        action: enabled ? "maintenance_enabled" : "maintenance_disabled",
        username,
        timestamp: new Date().toISOString(),
        message: message || (enabled ? "Maintenance mode enabled" : "Maintenance mode disabled"),
      }),
    )

    return true
  } catch (error) {
    console.error("Failed to toggle maintenance mode:", error)
    return false
  }
}

// Get maintenance mode status
export async function getMaintenanceStatus(): Promise<{
  enabled: boolean
  message: string
  lastToggled?: string
  toggledBy?: string
}> {
  try {
    const [enabled, message, lastToggled, toggledBy] = await Promise.all([
      redis.get(SETTINGS_KEYS.MAINTENANCE_MODE),
      redis.get(SETTINGS_KEYS.MAINTENANCE_MESSAGE),
      redis.get(SETTINGS_KEYS.LAST_MAINTENANCE_TOGGLE),
      redis.get(SETTINGS_KEYS.TOGGLED_BY),
    ])

    return {
      enabled: enabled === "true",
      message: message || DEFAULT_MAINTENANCE_MESSAGE,
      lastToggled: lastToggled || undefined,
      toggledBy: toggledBy || undefined,
    }
  } catch (error) {
    console.error("Failed to get maintenance status:", error)
    return {
      enabled: false,
      message: DEFAULT_MAINTENANCE_MESSAGE,
    }
  }
}
