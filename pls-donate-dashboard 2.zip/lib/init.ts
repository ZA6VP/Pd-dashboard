import { initializeAdminUsers } from "./auth"
import { initializeSystemStatus, runSystemStatusCheck } from "./system-status"
import { scheduleAutomaticBackups } from "./backup-system"
import { logError, logServerError } from "./error-monitoring"
import { recordMetric } from "./performance-monitor"
import { updateSecuritySettings } from "./security-system"
import { initDiscordWebhook } from "./discord-webhook"
import { initSlackWebhook } from "./slack-webhook"
import { initEmailService } from "./email-service"

// System initialization function
export async function initializeSystem() {
  console.log("Initializing system...")

  // Record start time
  const startTime = performance.now()

  // Initialize Discord webhook first so we can report errors
  try {
    initDiscordWebhook()
    console.log("Discord webhook initialized")
  } catch (error) {
    console.error("Failed to initialize Discord webhook:", error)
    // Continue with initialization
  }

  try {
    // Initialize each component with error handling
    const initComponents = [
      { name: "Admin users", fn: initializeAdminUsers },
      { name: "System status", fn: initializeSystemStatus },
      { name: "System status check", fn: runSystemStatusCheck },
      { name: "Automatic backups", fn: scheduleAutomaticBackups },
      { name: "Security settings", fn: () => updateSecuritySettings({}, "system") },
      { name: "Slack webhook", fn: initSlackWebhook },
      { name: "Email service", fn: initEmailService },
    ]

    for (const component of initComponents) {
      try {
        await component.fn()
        console.log(`${component.name} initialized`)
      } catch (error) {
        console.error(`Failed to initialize ${component.name}:`, error)
        // Log the error but continue with initialization
        try {
          await logError(error, { context: `init_${component.name.toLowerCase().replace(/\s+/g, "_")}` })
        } catch (logError) {
          console.error(`Failed to log ${component.name} initialization error:`, logError)
        }
      }
    }

    // Record initialization time
    const endTime = performance.now()
    try {
      await recordMetric("system_initialization_time", endTime - startTime)
    } catch (error) {
      console.error("Failed to record initialization metric:", error)
    }

    console.log("System initialization complete")
    return true
  } catch (error) {
    console.error("System initialization failed:", error)

    // Try to log the error
    try {
      await logServerError(
        "INIT_FAILURE",
        "System initialization failed",
        error instanceof Error ? error.stack : undefined,
        { context: "systemInitialization" },
      )
    } catch (logError) {
      console.error("Failed to log initialization error:", logError)
    }

    // Return true anyway to allow the application to start
    return true
  }
}

// Export for manual initialization
export default initializeSystem
