import redis from "./redis"
import { sendStatsChangeToDiscord } from "./discord-webhook"

// Analytics keys
const ANALYTICS_KEYS = {
  DAILY_ACTIVE_USERS: (date: string) => `analytics:dau:${date}`,
  DONATIONS_TOTAL: (date: string) => `analytics:donations:total:${date}`,
  DONATIONS_COUNT: (date: string) => `analytics:donations:count:${date}`,
  API_REQUESTS: (date: string) => `analytics:api:requests:${date}`,
  API_ERRORS: (date: string) => `analytics:api:errors:${date}`,
  GAME_PLAYERS: (gameId: number, date: string) => `analytics:game:${gameId}:players:${date}`,
  GAME_DONATIONS: (gameId: number, date: string) => `analytics:game:${gameId}:donations:${date}`,
}

// Get current date in YYYY-MM-DD format
function getDateString(date = new Date()): string {
  return date.toISOString().split("T")[0]
}

// Track active user
export async function trackActiveUser(userId: string | number): Promise<void> {
  const date = getDateString()
  const key = ANALYTICS_KEYS.DAILY_ACTIVE_USERS(date)

  // Get current count before adding
  const currentCount = await redis.scard(key)

  await redis.sadd(key, userId)

  // Get new count after adding
  const newCount = await redis.scard(key)

  // If count changed, send to Discord
  if (newCount !== currentCount) {
    await sendStatsChangeToDiscord("Daily Active Users", currentCount, newCount)
  }
}

// Track donation
export async function trackDonation(
  gameId: number,
  amount: number,
  donorId?: string | number,
  recipientId?: string | number,
): Promise<void> {
  const date = getDateString()

  // Get current total before incrementing
  const currentTotal = (await redis.get(ANALYTICS_KEYS.DONATIONS_TOTAL(date))) || "0"
  const currentCount = (await redis.get(ANALYTICS_KEYS.DONATIONS_COUNT(date))) || "0"
  const currentGameDonations = (await redis.get(ANALYTICS_KEYS.GAME_DONATIONS(gameId, date))) || "0"

  // Increment total donations for the day
  await redis.incrby(ANALYTICS_KEYS.DONATIONS_TOTAL(date), amount)

  // Increment donation count for the day
  await redis.incr(ANALYTICS_KEYS.DONATIONS_COUNT(date))

  // Increment game-specific donations
  await redis.incrby(ANALYTICS_KEYS.GAME_DONATIONS(gameId, date), amount)

  // Get new values after incrementing
  const newTotal = await redis.get(ANALYTICS_KEYS.DONATIONS_TOTAL(date))
  const newCount = await redis.get(ANALYTICS_KEYS.DONATIONS_COUNT(date))
  const newGameDonations = await redis.get(ANALYTICS_KEYS.GAME_DONATIONS(gameId, date))

  // Send stats changes to Discord
  await sendStatsChangeToDiscord("Total Donations", currentTotal, newTotal)
  await sendStatsChangeToDiscord("Donation Count", currentCount, newCount)
  await sendStatsChangeToDiscord(`Game ${gameId} Donations`, currentGameDonations, newGameDonations, gameId)

  // If donor and recipient IDs are provided, we could track them as well
  if (donorId) {
    await redis.zincrby(`analytics:donors:${date}`, amount, donorId)
  }

  if (recipientId) {
    await redis.zincrby(`analytics:recipients:${date}`, amount, recipientId)
  }
}

// Track API request
export async function trackApiRequest(path: string, statusCode: number): Promise<void> {
  const date = getDateString()

  // Get current counts before incrementing
  const currentRequests = (await redis.get(ANALYTICS_KEYS.API_REQUESTS(date))) || "0"
  const currentErrors = statusCode >= 400 ? (await redis.get(ANALYTICS_KEYS.API_ERRORS(date))) || "0" : null

  // Increment total API requests
  await redis.incr(ANALYTICS_KEYS.API_REQUESTS(date))

  // Track API path
  await redis.zincrby(`analytics:api:paths:${date}`, 1, path)

  // Track errors
  if (statusCode >= 400) {
    await redis.incr(ANALYTICS_KEYS.API_ERRORS(date))
    await redis.zincrby(`analytics:api:errors:${date}`, 1, `${path}:${statusCode}`)
  }

  // Get new counts after incrementing
  const newRequests = await redis.get(ANALYTICS_KEYS.API_REQUESTS(date))

  // Send stats changes to Discord
  await sendStatsChangeToDiscord("API Requests", currentRequests, newRequests)

  if (statusCode >= 400) {
    const newErrors = await redis.get(ANALYTICS_KEYS.API_ERRORS(date))
    await sendStatsChangeToDiscord("API Errors", currentErrors, newErrors)
  }
}

// Track game players
export async function trackGamePlayers(gameId: number, playerCount: number): Promise<void> {
  const date = getDateString()

  // Get current player count
  const currentPlayerCount = (await redis.get(ANALYTICS_KEYS.GAME_PLAYERS(gameId, date))) || "0"

  // Set current player count
  await redis.set(ANALYTICS_KEYS.GAME_PLAYERS(gameId, date), playerCount)

  // Add data point to time series
  const timestamp = Math.floor(Date.now() / 1000)
  await redis.zadd(`analytics:game:${gameId}:players:timeseries:${date}`, timestamp, playerCount)

  // Send stats change to Discord
  await sendStatsChangeToDiscord(`Game ${gameId} Players`, currentPlayerCount, playerCount, gameId)
}

// Get daily active users
export async function getDailyActiveUsers(date: string = getDateString()): Promise<number> {
  return await redis.scard(ANALYTICS_KEYS.DAILY_ACTIVE_USERS(date))
}

// Get total donations for a day
export async function getDailyDonations(date: string = getDateString()): Promise<number> {
  const total = await redis.get(ANALYTICS_KEYS.DONATIONS_TOTAL(date))
  return total ? Number(total) : 0
}

// Get donation count for a day
export async function getDailyDonationCount(date: string = getDateString()): Promise<number> {
  const count = await redis.get(ANALYTICS_KEYS.DONATIONS_COUNT(date))
  return count ? Number(count) : 0
}

// Get top donors for a day
export async function getTopDonors(date: string = getDateString(), limit = 10): Promise<any[]> {
  const donors = await redis.zrevrange(`analytics:donors:${date}`, 0, limit - 1, "WITHSCORES")

  // Format results
  const result = []
  for (let i = 0; i < donors.length; i += 2) {
    result.push({
      userId: donors[i],
      amount: Number(donors[i + 1]),
    })
  }

  return result
}

// Get top recipients for a day
export async function getTopRecipients(date: string = getDateString(), limit = 10): Promise<any[]> {
  const recipients = await redis.zrevrange(`analytics:recipients:${date}`, 0, limit - 1, "WITHSCORES")

  // Format results
  const result = []
  for (let i = 0; i < recipients.length; i += 2) {
    result.push({
      userId: recipients[i],
      amount: Number(recipients[i + 1]),
    })
  }

  return result
}

// Get game player count
export async function getGamePlayerCount(gameId: number, date: string = getDateString()): Promise<number> {
  const count = await redis.get(ANALYTICS_KEYS.GAME_PLAYERS(gameId, date))
  return count ? Number(count) : 0
}

// Get game player history
export async function getGamePlayerHistory(
  gameId: number,
  date: string = getDateString(),
  interval = 3600, // 1 hour in seconds
): Promise<any[]> {
  const data = await redis.zrange(`analytics:game:${gameId}:players:timeseries:${date}`, 0, -1, "WITHSCORES")

  // Format results
  const result = []
  for (let i = 0; i < data.length; i += 2) {
    result.push({
      timestamp: Number(data[i]),
      playerCount: Number(data[i + 1]),
    })
  }

  return result
}
