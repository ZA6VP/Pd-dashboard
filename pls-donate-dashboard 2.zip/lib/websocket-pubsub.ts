import redis from "./redis"

// Event types for the WebSocket messages
export type WebSocketEvent =
  | { type: "GAME_UPDATE"; data: any }
  | { type: "STORE_UPDATE"; data: any }
  | { type: "USER_BAN"; data: any }
  | { type: "NOTIFICATION"; data: any }
  | { type: "AUDIT_LOG"; data: any }

// Redis channel for WebSocket events
const WEBSOCKET_CHANNEL = "websocket:events"

// Publish a WebSocket event to all connected clients
export async function publishEvent(event: WebSocketEvent): Promise<void> {
  try {
    await redis.publish(WEBSOCKET_CHANNEL, JSON.stringify(event))
  } catch (error) {
    console.error("Failed to publish WebSocket event:", error)
  }
}

// Subscribe to WebSocket events (called once during server initialization)
export async function subscribeToEvents(callback: (event: WebSocketEvent) => void): Promise<void> {
  try {
    const subscription = redis.subscribe(WEBSOCKET_CHANNEL, (message) => {
      try {
        const event = JSON.parse(message) as WebSocketEvent
        callback(event)
      } catch (error) {
        console.error("Failed to parse WebSocket event:", error)
      }
    })

    console.log("Subscribed to WebSocket events channel")
    return subscription
  } catch (error) {
    console.error("Failed to subscribe to WebSocket events:", error)
  }
}
