import redis from "./redis"
import { logError } from "./error-monitoring"

// Performance metrics key
const PERFORMANCE_METRICS_KEY = "system:performance"
const PERFORMANCE_METRICS_MAX_SIZE = 1000 // Maximum number of metrics to keep

// Metric types
export type MetricType =
  | "api_response_time"
  | "page_load_time"
  | "database_query_time"
  | "cache_hit_ratio"
  | "memory_usage"
  | "cpu_usage"
  | "active_connections"
  | "webhook_processing_time"
  | "background_job_time"

// Metric interface
export interface PerformanceMetric {
  id: string
  timestamp: string
  type: MetricType
  value: number
  details?: Record<string, any>
}

// Record a performance metric
export async function recordMetric(
  type: MetricType,
  value: number,
  details: Record<string, any> = {},
): Promise<boolean> {
  try {
    const metric: PerformanceMetric = {
      id: `metric_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`,
      timestamp: new Date().toISOString(),
      type,
      value,
      details,
    }

    // Log to Redis
    await redis.lpush(PERFORMANCE_METRICS_KEY, JSON.stringify(metric))

    // Trim the log to keep it at a reasonable size
    await redis.ltrim(PERFORMANCE_METRICS_KEY, 0, PERFORMANCE_METRICS_MAX_SIZE - 1)

    return true
  } catch (error) {
    logError(error, { context: "recordMetric", type, value })
    return false
  }
}

// Get recent metrics
export async function getRecentMetrics(
  type: MetricType,
  limit = 100,
  timeRange?: { start: Date; end: Date },
): Promise<PerformanceMetric[]> {
  try {
    const metrics = await redis.lrange(PERFORMANCE_METRICS_KEY, 0, -1)

    // Parse metrics
    const parsedMetrics = metrics
      .map((metric) => JSON.parse(metric) as PerformanceMetric)
      .filter((metric) => metric.type === type)

    // Filter by time range if provided
    let filteredMetrics = parsedMetrics
    if (timeRange) {
      filteredMetrics = parsedMetrics.filter((metric) => {
        const timestamp = new Date(metric.timestamp)
        return timestamp >= timeRange.start && timestamp <= timeRange.end
      })
    }

    // Return limited number of metrics
    return filteredMetrics.slice(0, limit)
  } catch (error) {
    logError(error, { context: "getRecentMetrics", type, limit })
    return []
  }
}

// Calculate average metric value
export async function getAverageMetric(
  type: MetricType,
  timeRange?: { start: Date; end: Date },
): Promise<number | null> {
  try {
    const metrics = await getRecentMetrics(type, 1000, timeRange)

    if (metrics.length === 0) {
      return null
    }

    const sum = metrics.reduce((acc, metric) => acc + metric.value, 0)
    return sum / metrics.length
  } catch (error) {
    logError(error, { context: "getAverageMetric", type })
    return null
  }
}

// Get performance summary
export async function getPerformanceSummary(): Promise<
  Record<MetricType, { avg: number | null; max: number | null; min: number | null }>
> {
  try {
    const metricTypes: MetricType[] = [
      "api_response_time",
      "page_load_time",
      "database_query_time",
      "cache_hit_ratio",
      "memory_usage",
      "cpu_usage",
      "active_connections",
      "webhook_processing_time",
      "background_job_time",
    ]

    const summary: Record<MetricType, { avg: number | null; max: number | null; min: number | null }> = {} as any

    for (const type of metricTypes) {
      const metrics = await getRecentMetrics(type, 1000)

      if (metrics.length === 0) {
        summary[type] = { avg: null, max: null, min: null }
        continue
      }

      const values = metrics.map((metric) => metric.value)
      const sum = values.reduce((acc, val) => acc + val, 0)
      const avg = sum / values.length
      const max = Math.max(...values)
      const min = Math.min(...values)

      summary[type] = { avg, max, min }
    }

    return summary
  } catch (error) {
    logError(error, { context: "getPerformanceSummary" })
    return {} as any
  }
}

// Clear performance metrics
export async function clearPerformanceMetrics(): Promise<boolean> {
  try {
    await redis.del(PERFORMANCE_METRICS_KEY)
    return true
  } catch (error) {
    logError(error, { context: "clearPerformanceMetrics" })
    return false
  }
}

// Measure execution time of a function
export async function measureExecutionTime<T>(
  type: MetricType,
  fn: () => Promise<T>,
  details: Record<string, any> = {},
): Promise<T> {
  const startTime = performance.now()

  try {
    const result = await fn()

    const endTime = performance.now()
    const executionTime = endTime - startTime

    // Record the metric
    await recordMetric(type, executionTime, details)

    return result
  } catch (error) {
    const endTime = performance.now()
    const executionTime = endTime - startTime

    // Record the metric even if there was an error
    await recordMetric(type, executionTime, { ...details, error: error.message })

    throw error
  }
}
