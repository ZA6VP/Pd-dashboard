import redis from "./redis"
import type { WebhookConfig, WebhookPayload } from "./webhooks"

// Redis queue name
const WEBHOOK_QUEUE = "webhooks:queue"
const WEBHOOK_PROCESSING = "webhooks:processing"
const WEBHOOK_FAILED = "webhooks:failed"

// Add webhook to queue
export async function queueWebhook(config: WebhookConfig, event: string, data: any): Promise<string> {
  try {
    const payload: WebhookPayload = {
      event,
      data,
      timestamp: new Date().toISOString(),
    }

    const webhookJob = {
      id: `webhook-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      config,
      payload,
      attempts: 0,
      createdAt: new Date().toISOString(),
    }

    // Add to queue
    await redis.lpush(WEBHOOK_QUEUE, JSON.stringify(webhookJob))

    return webhookJob.id
  } catch (error) {
    console.error("Failed to queue webhook:", error)
    throw error
  }
}

// Process webhooks from queue (to be called by a background worker or cron job)
export async function processWebhookQueue(maxJobs = 10): Promise<void> {
  try {
    // Process up to maxJobs at a time
    for (let i = 0; i < maxJobs; i++) {
      // Move job from queue to processing list
      const job = await redis.rpoplpush(WEBHOOK_QUEUE, WEBHOOK_PROCESSING)

      if (!job) {
        // No more jobs in queue
        break
      }

      try {
        const webhookJob = JSON.parse(job)

        // Format payload based on provider
        let formattedPayload: any

        switch (webhookJob.config.provider) {
          case "discord":
            formattedPayload = formatDiscordPayload(webhookJob.payload)
            break
          case "slack":
            formattedPayload = formatSlackPayload(webhookJob.payload)
            break
          default:
            formattedPayload = webhookJob.payload
        }

        // Send the webhook
        const response = await fetch(webhookJob.config.url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formattedPayload),
        })

        if (!response.ok) {
          throw new Error(`Webhook failed with status ${response.status}`)
        }

        // Success - remove from processing list
        await redis.lrem(WEBHOOK_PROCESSING, 0, job)

        // Update last triggered timestamp for the webhook
        await redis.hset("webhooks:metadata", webhookJob.config.id, new Date().toISOString())
      } catch (error) {
        // Handle failed job
        const webhookJob = JSON.parse(job)
        webhookJob.attempts += 1
        webhookJob.lastError = error.message

        if (webhookJob.attempts < 3) {
          // Retry later - add back to queue
          await redis.lpush(WEBHOOK_QUEUE, JSON.stringify(webhookJob))
        } else {
          // Too many attempts - move to failed list
          await redis.lpush(WEBHOOK_FAILED, JSON.stringify(webhookJob))
        }

        // Remove from processing list
        await redis.lrem(WEBHOOK_PROCESSING, 0, job)
      }
    }
  } catch (error) {
    console.error("Error processing webhook queue:", error)
  }
}

// Format payload for Discord
function formatDiscordPayload(payload: WebhookPayload) {
  let color = 0x3b82f6 // Blue
  let title = "PLS DONATE Dashboard Notification"

  // Set color and title based on event
  switch (payload.event) {
    case "game_update":
      title = "Game Update"
      break
    case "user_ban":
      title = "User Banned"
      color = 0xef4444 // Red
      break
    case "donation":
      title = "New Donation"
      color = 0x10b981 // Green
      break
  }

  // Create fields based on data
  const fields = Object.entries(payload.data).map(([name, value]) => ({
    name,
    value: String(value),
    inline: true,
  }))

  return {
    embeds: [
      {
        title,
        color,
        fields,
        timestamp: payload.timestamp,
        footer: {
          text: "PLS DONATE Dashboard",
        },
      },
    ],
  }
}

// Format payload for Slack
function formatSlackPayload(payload: WebhookPayload) {
  let color = "#3b82f6" // Blue

  // Set color based on event
  switch (payload.event) {
    case "user_ban":
      color = "#ef4444" // Red
      break
    case "donation":
      color = "#10b981" // Green
      break
  }

  // Create fields based on data
  const fields = Object.entries(payload.data).map(([name, value]) => ({
    title: name,
    value: String(value),
    short: true,
  }))

  return {
    attachments: [
      {
        color,
        pretext: `PLS DONATE Dashboard: ${payload.event}`,
        fields,
        ts: Math.floor(new Date(payload.timestamp).getTime() / 1000),
      },
    ],
  }
}
