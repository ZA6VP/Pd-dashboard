import redis from "./redis"
import { logError } from "./error-monitoring"
import { createNotification } from "./notification-system"
import { logActivity } from "./activity-logger"

// Security event types
export type SecurityEventType =
  | "login_attempt"
  | "login_success"
  | "login_failure"
  | "password_change"
  | "role_change"
  | "user_created"
  | "user_deleted"
  | "api_key_created"
  | "api_key_deleted"
  | "suspicious_activity"
  | "rate_limit_exceeded"
  | "permission_denied"
  | "ip_blocked"
  | "ip_allowed"

// Security event interface
export interface SecurityEvent {
  id: string
  timestamp: string
  type: SecurityEventType
  username: string
  ip?: string
  userAgent?: string
  details: Record<string, any>
  severity: "info" | "warning" | "critical"
}

// IP block interface
export interface IPBlock {
  ip: string
  reason: string
  timestamp: string
  expiresAt?: string
  createdBy: string
}

// Security keys
const SECURITY_EVENTS_KEY = "security:events"
const BLOCKED_IPS_KEY = "security:blocked_ips"
const ALLOWED_IPS_KEY = "security:allowed_ips"
const SECURITY_SETTINGS_KEY = "security:settings"

// Default security settings
export const DEFAULT_SECURITY_SETTINGS = {
  maxLoginAttempts: 5,
  loginLockoutDuration: 15 * 60, // 15 minutes in seconds
  passwordMinLength: 8,
  passwordRequireUppercase: true,
  passwordRequireNumbers: true,
  passwordRequireSpecialChars: true,
  sessionTimeout: 24 * 60 * 60, // 24 hours in seconds
  ipWhitelistEnabled: false,
  ipWhitelist: [],
  ipBlacklistEnabled: true,
  ipBlacklist: [],
  twoFactorAuthEnabled: false,
  apiRateLimiting: true,
  apiRateLimit: 100, // requests per minute
  notifyOnSuspiciousActivity: true,
}

// Log a security event
export async function logSecurityEvent(
  type: SecurityEventType,
  username: string,
  details: Record<string, any> = {},
  severity: "info" | "warning" | "critical" = "info",
  request?: Request,
): Promise<string> {
  try {
    const eventId = `sec_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`

    const event: SecurityEvent = {
      id: eventId,
      timestamp: new Date().toISOString(),
      type,
      username,
      details,
      severity,
    }

    // Add request information if available
    if (request) {
      event.ip = request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "unknown"
      event.userAgent = request.headers.get("user-agent") || "unknown"
    }

    // Save event to Redis
    await redis.lpush(SECURITY_EVENTS_KEY, JSON.stringify(event))

    // Trim the log to keep it at a reasonable size
    await redis.ltrim(SECURITY_EVENTS_KEY, 0, 9999)

    // Create notification for critical and warning events
    if (severity === "critical" || severity === "warning") {
      const notificationType = "security"
      const priority = severity === "critical" ? "critical" : "high"
      const title = `Security Alert: ${formatSecurityEventType(type)}`
      const message = `Security event detected: ${formatSecurityEventType(type)} for user ${username}`

      // Notify all admins
      const admins = await getAdminUsernames()

      for (const admin of admins) {
        await createNotification(notificationType, priority, title, message, admin, {
          eventId,
          type,
          username,
          timestamp: event.timestamp,
          ip: event.ip,
          details,
        })
      }

      // Log activity
      await logActivity("security_alert", username, {
        eventId,
        type,
        severity,
        ip: event.ip,
      })
    }

    return eventId
  } catch (error) {
    logError(error, { context: "logSecurityEvent", type, username })
    return null
  }
}

// Get recent security events
export async function getRecentSecurityEvents(
  limit = 100,
  type?: SecurityEventType,
  username?: string,
  severity?: "info" | "warning" | "critical",
): Promise<SecurityEvent[]> {
  try {
    const events = await redis.lrange(SECURITY_EVENTS_KEY, 0, limit - 1)

    // Parse events
    const parsedEvents = events.map((event) => JSON.parse(event) as SecurityEvent)

    // Filter events
    return parsedEvents.filter((event) => {
      if (type && event.type !== type) return false
      if (username && event.username !== username) return false
      if (severity && event.severity !== severity) return false
      return true
    })
  } catch (error) {
    logError(error, { context: "getRecentSecurityEvents", limit, type, username, severity })
    return []
  }
}

// Block an IP address
export async function blockIP(ip: string, reason: string, createdBy: string, expiresIn?: number): Promise<boolean> {
  try {
    const block: IPBlock = {
      ip,
      reason,
      timestamp: new Date().toISOString(),
      createdBy,
    }

    if (expiresIn) {
      const expiresAt = new Date()
      expiresAt.setSeconds(expiresAt.getSeconds() + expiresIn)
      block.expiresAt = expiresAt.toISOString()
    }

    // Save block to Redis
    await redis.hset(BLOCKED_IPS_KEY, ip, JSON.stringify(block))

    // Log security event
    await logSecurityEvent("ip_blocked", createdBy, {
      ip,
      reason,
      expiresAt: block.expiresAt,
    })

    return true
  } catch (error) {
    logError(error, { context: "blockIP", ip, reason, createdBy })
    return false
  }
}

// Unblock an IP address
export async function unblockIP(ip: string, unblockBy: string): Promise<boolean> {
  try {
    const exists = await redis.hexists(BLOCKED_IPS_KEY, ip)

    if (!exists) {
      return false
    }

    await redis.hdel(BLOCKED_IPS_KEY, ip)

    // Log security event
    await logSecurityEvent("ip_allowed", unblockBy, { ip })

    return true
  } catch (error) {
    logError(error, { context: "unblockIP", ip, unblockBy })
    return false
  }
}

// Check if an IP is blocked
export async function isIPBlocked(ip: string): Promise<boolean> {
  try {
    const block = await redis.hget(BLOCKED_IPS_KEY, ip)

    if (!block) {
      return false
    }

    const parsedBlock = JSON.parse(block) as IPBlock

    // Check if block has expired
    if (parsedBlock.expiresAt) {
      const expiresAt = new Date(parsedBlock.expiresAt)

      if (expiresAt < new Date()) {
        // Block has expired, remove it
        await redis.hdel(BLOCKED_IPS_KEY, ip)
        return false
      }
    }

    return true
  } catch (error) {
    logError(error, { context: "isIPBlocked", ip })
    return false
  }
}

// Get all blocked IPs
export async function getBlockedIPs(): Promise<IPBlock[]> {
  try {
    const blocks = await redis.hgetall(BLOCKED_IPS_KEY)

    if (!blocks) {
      return []
    }

    return Object.values(blocks).map((block) => JSON.parse(block) as IPBlock)
  } catch (error) {
    logError(error, { context: "getBlockedIPs" })
    return []
  }
}

// Allow an IP address (whitelist)
export async function allowIP(ip: string, createdBy: string): Promise<boolean> {
  try {
    // Check if IP is already allowed
    const exists = await redis.hexists(ALLOWED_IPS_KEY, ip)

    if (exists) {
      return true
    }

    // Save to Redis
    await redis.hset(
      ALLOWED_IPS_KEY,
      ip,
      JSON.stringify({
        ip,
        timestamp: new Date().toISOString(),
        createdBy,
      }),
    )

    // Log security event
    await logSecurityEvent("ip_allowed", createdBy, { ip })

    return true
  } catch (error) {
    logError(error, { context: "allowIP", ip, createdBy })
    return false
  }
}

// Remove an IP from whitelist
export async function disallowIP(ip: string, disallowBy: string): Promise<boolean> {
  try {
    const exists = await redis.hexists(ALLOWED_IPS_KEY, ip)

    if (!exists) {
      return false
    }

    await redis.hdel(ALLOWED_IPS_KEY, ip)

    // Log security event
    await logSecurityEvent("ip_blocked", disallowBy, { ip })

    return true
  } catch (error) {
    logError(error, { context: "disallowIP", ip, disallowBy })
    return false
  }
}

// Check if an IP is allowed (whitelisted)
export async function isIPAllowed(ip: string): Promise<boolean> {
  try {
    // Get security settings
    const settings = await getSecuritySettings()

    // If IP whitelist is not enabled, all IPs are allowed
    if (!settings.ipWhitelistEnabled) {
      return true
    }

    // Check if IP is in whitelist
    const allowed = await redis.hexists(ALLOWED_IPS_KEY, ip)

    return allowed === 1
  } catch (error) {
    logError(error, { context: "isIPAllowed", ip })
    return true // Default to allowing in case of error
  }
}

// Get all allowed IPs
export async function getAllowedIPs(): Promise<string[]> {
  try {
    const allowed = await redis.hkeys(ALLOWED_IPS_KEY)
    return allowed
  } catch (error) {
    logError(error, { context: "getAllowedIPs" })
    return []
  }
}

// Get security settings
export async function getSecuritySettings(): Promise<typeof DEFAULT_SECURITY_SETTINGS> {
  try {
    const settings = await redis.get(SECURITY_SETTINGS_KEY)

    if (!settings) {
      return DEFAULT_SECURITY_SETTINGS
    }

    return JSON.parse(settings)
  } catch (error) {
    logError(error, { context: "getSecuritySettings" })
    return DEFAULT_SECURITY_SETTINGS
  }
}

// Update security settings
export async function updateSecuritySettings(
  settings: Partial<typeof DEFAULT_SECURITY_SETTINGS>,
  username: string,
): Promise<boolean> {
  try {
    const currentSettings = await getSecuritySettings()

    const updatedSettings = {
      ...currentSettings,
      ...settings,
    }

    await redis.set(SECURITY_SETTINGS_KEY, JSON.stringify(updatedSettings))

    // Log security event
    await logSecurityEvent("security_settings_updated", username, {
      changes: Object.keys(settings),
    })

    return true
  } catch (error) {
    logError(error, { context: "updateSecuritySettings", username })
    return false
  }
}

// Helper function to get all admin usernames
async function getAdminUsernames(): Promise<string[]> {
  try {
    const users = await redis.hgetall("admin:users")

    if (!users) {
      return []
    }

    return Object.keys(users)
  } catch (error) {
    logError(error, { context: "getAdminUsernames" })
    return []
  }
}

// Helper function to format security event type for display
function formatSecurityEventType(type: SecurityEventType): string {
  return type
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ")
}
