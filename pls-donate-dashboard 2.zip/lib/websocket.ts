"use client"

import { useState } from "react"

// WebSocket URL - replace with your actual WebSocket server URL in production
const WS_URL =
  process.env.NODE_ENV === "production"
    ? `wss://${process.env.VERCEL_URL || window.location.host}/api/ws`
    : `ws://${window.location.host}/api/ws`

// Event types for the WebSocket messages
export type WebSocketEvent =
  | { type: "GAME_UPDATE"; data: any }
  | { type: "STORE_UPDATE"; data: any }
  | { type: "USER_BAN"; data: any }
  | { type: "NOTIFICATION"; data: any }
  | { type: "AUDIT_LOG"; data: any }

// WebSocket connection status
export type ConnectionStatus = "connecting" | "connected" | "disconnected"

// Custom hook for using WebSocket
export function useWebSocket() {
  const [socket, setSocket] = useState<WebSocket | null>(null)
  const [status, setStatus] = useState<ConnectionStatus>("disconnected")
  const [events, setEvents] = useState<WebSocketEvent[]>([])
  const [lastEvent, setLastEvent] = useState<WebSocketEvent | null>(null)

  // Connect to WebSocket
  const connect = () => {
    if (socket) return

    try {
      const ws = new WebSocket(WS_URL)
      setSocket(ws)
      setStatus("connecting")

      ws.onopen = () => {
        setStatus("connected")
        console.log("WebSocket connected")
      }

      ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data) as WebSocketEvent
          setEvents((prev) => [...prev, message])
          setLastEvent(message)
        } catch (error) {
          console.error("Failed to parse WebSocket message:", error)
        }
      }

      ws.onclose = () => {
        setStatus("disconnected")
        setSocket(null)
        console.log("WebSocket disconnected, reconnecting in 5s...")
        setTimeout(connect, 5000)
      }

      ws.onerror = (error) => {
        console.error("WebSocket error:", error)
        ws.close()
      }

      return () => {
        ws.close()
      }
    } catch (error) {
      console.error("Failed to connect to WebSocket:", error)
      setStatus("disconnected")
      setTimeout(connect, 5000)
    }
  }

  // Send message to WebSocket
  const send = (message: any) => {
    if (socket && status === "connected") {
      socket.send(JSON.stringify(message))
    }
  }

  // Reconnect to WebSocket
  const reconnect = () => {
    if (socket) {
      socket.close()
    }
    connect()
  }

  return {
    status,
    events,
    lastEvent,
    connect,
    send,
    reconnect,
  }
}
