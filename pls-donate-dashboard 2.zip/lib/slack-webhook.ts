import { logError } from "./error-monitoring"
import type { NotificationType, NotificationPriority } from "./notification-system"

// Slack webhook configuration
interface SlackWebhookConfig {
  url: string
  username?: string
  iconUrl?: string
  enabled: boolean
}

// Message colors
const MESSAGE_COLORS = {
  system: "#57F287", // Green
  security: "#FEE75C", // Yellow
  user: "#9B59B6", // Purple
  game: "#1ABC9C", // Teal
  webhook: "#3498DB", // Blue
  backup: "#2ECC71", // Emerald
  error: "#ED4245", // Red
  performance: "#EB459E", // Pink
  maintenance: "#5865F2", // Blurple
  donation: "#2ECC71", // Emerald
  ban: "#E74C3C", // Crimson
  low: "#3498DB", // Blue
  medium: "#FEE75C", // Yellow
  high: "#E74C3C", // Crimson
  critical: "#ED4245", // Red
}

// Slack webhook configuration
let webhookConfig: SlackWebhookConfig = {
  url: "",
  username: "PLS DONATE Dashboard",
  iconUrl: "https://cdn.discordapp.com/avatars/123456789/dashboard.png",
  enabled: false,
}

// Initialize webhook from environment variable
export function initSlackWebhook() {
  const webhookUrl = process.env.SLACK_WEBHOOK_URL

  if (webhookUrl) {
    webhookConfig = {
      ...webhookConfig,
      url: webhookUrl,
      enabled: true,
    }
    console.log("Slack webhook initialized")
    return true
  }

  console.log("Slack webhook not configured")
  return false
}

// Update webhook configuration
export function updateSlackWebhook(config: Partial<SlackWebhookConfig>): SlackWebhookConfig {
  webhookConfig = {
    ...webhookConfig,
    ...config,
  }

  return webhookConfig
}

// Get webhook configuration
export function getSlackWebhook(): SlackWebhookConfig {
  return { ...webhookConfig }
}

// Send message to Slack webhook
export async function sendSlackMessage(
  type: NotificationType,
  priority: NotificationPriority,
  title: string,
  text: string,
  fields: Record<string, any> = {},
): Promise<boolean> {
  if (!webhookConfig.enabled || !webhookConfig.url) {
    return false
  }

  try {
    // Create blocks for the message
    const blocks = [
      {
        type: "header",
        text: {
          type: "plain_text",
          text: title,
          emoji: true,
        },
      },
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text: text,
        },
      },
      {
        type: "divider",
      },
      {
        type: "section",
        fields: [
          {
            type: "mrkdwn",
            text: `*Type:*\n${type.replace("_", " ")}`,
          },
          {
            type: "mrkdwn",
            text: `*Priority:*\n${priority}`,
          },
          {
            type: "mrkdwn",
            text: `*Time:*\n${new Date().toLocaleString()}`,
          },
        ],
      },
    ]

    // Add fields as context blocks
    if (Object.keys(fields).length > 0) {
      const contextElements = []

      for (const [key, value] of Object.entries(fields)) {
        if (typeof value === "object") {
          contextElements.push({
            type: "mrkdwn",
            text: `*${key}:*\n\`\`\`${JSON.stringify(value, null, 2).substring(0, 300)}\`\`\``,
          })
        } else {
          contextElements.push({
            type: "mrkdwn",
            text: `*${key}:* ${String(value).substring(0, 300)}`,
          })
        }

        // Slack has a limit of 10 elements per context block
        if (contextElements.length === 10) {
          blocks.push({
            type: "context",
            elements: [...contextElements],
          })
          contextElements.length = 0
        }
      }

      // Add remaining context elements
      if (contextElements.length > 0) {
        blocks.push({
          type: "context",
          elements: [...contextElements],
        })
      }
    }

    const payload = {
      username: webhookConfig.username,
      icon_url: webhookConfig.iconUrl,
      blocks,
    }

    const response = await fetch(webhookConfig.url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    if (!response.ok) {
      throw new Error(`Slack webhook failed with status ${response.status}`)
    }

    return true
  } catch (error) {
    logError(error, { context: "sendSlackMessage", type, title })
    return false
  }
}
