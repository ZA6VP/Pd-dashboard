"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { AlertCircle, CheckCircle, AlertTriangle, RefreshCw, Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import type { Service, ServiceStatus } from "@/lib/system-status"

export function SystemStatusPanel() {
  const [services, setServices] = useState<Service[]>([])
  const [overallStatus, setOverallStatus] = useState<ServiceStatus>("unknown")
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Load system status on component mount
  useEffect(() => {
    fetchSystemStatus()
  }, [])

  // Fetch system status from API
  const fetchSystemStatus = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/system/status")

      if (!response.ok) {
        throw new Error("Failed to fetch system status")
      }

      const data = await response.json()
      setServices(data.services)
      setOverallStatus(data.overallStatus)
    } catch (error) {
      setError("Failed to load system status")
      console.error(error)
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }

  // Refresh system status
  const refreshStatus = async () => {
    setIsRefreshing(true)
    await fetchSystemStatus()
  }

  // Run system check
  const runSystemCheck = async () => {
    setIsRefreshing(true)
    setError(null)

    try {
      const response = await fetch("/api/system/check", {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Failed to run system check")
      }

      await fetchSystemStatus()
    } catch (error) {
      setError("Failed to run system check")
      console.error(error)
      setIsRefreshing(false)
    }
  }

  // Get status icon and color
  const getStatusInfo = (status: ServiceStatus) => {
    switch (status) {
      case "operational":
        return { icon: <CheckCircle className="h-5 w-5 text-green-500" />, color: "text-green-500", bg: "bg-green-50" }
      case "degraded":
        return {
          icon: <AlertTriangle className="h-5 w-5 text-yellow-500" />,
          color: "text-yellow-500",
          bg: "bg-yellow-50",
        }
      case "outage":
        return { icon: <AlertCircle className="h-5 w-5 text-red-500" />, color: "text-red-500", bg: "bg-red-50" }
      case "maintenance":
        return { icon: <RefreshCw className="h-5 w-5 text-blue-500" />, color: "text-blue-500", bg: "bg-blue-50" }
      default:
        return { icon: <AlertCircle className="h-5 w-5 text-gray-500" />, color: "text-gray-500", bg: "bg-gray-50" }
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
          <p className="text-gray-500">Loading system status...</p>
        </div>
      </div>
    )
  }

  const overallStatusInfo = getStatusInfo(overallStatus)

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive" className="animate-slide-down">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">System Status</h3>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={refreshStatus} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 mr-1 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Button size="sm" onClick={runSystemCheck} disabled={isRefreshing}>
            {isRefreshing ? (
              <>
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                Checking...
              </>
            ) : (
              "Run System Check"
            )}
          </Button>
        </div>
      </div>

      <Card className={`${overallStatusInfo.bg} border-${overallStatusInfo.color.replace("text-", "")}-200`}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              {overallStatusInfo.icon}
              <h3 className={`text-lg font-medium ml-2 ${overallStatusInfo.color}`}>
                Overall Status: {overallStatus.charAt(0).toUpperCase() + overallStatus.slice(1)}
              </h3>
            </div>
            <p className="text-sm text-gray-500">Last updated: {new Date().toLocaleTimeString()}</p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {services.map((service) => {
          const statusInfo = getStatusInfo(service.status)

          return (
            <Card key={service.id} className={`${statusInfo.bg} border-${statusInfo.color.replace("text-", "")}-200`}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center">
                      {statusInfo.icon}
                      <h4 className="text-md font-medium ml-2">{service.name}</h4>
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{service.description}</p>
                  </div>
                  <div className={`px-2 py-1 rounded-full text-xs font-medium ${statusInfo.color} ${statusInfo.bg}`}>
                    {service.status}
                  </div>
                </div>
                {service.details && (
                  <p className="text-sm mt-2 text-gray-600">
                    <span className="font-medium">Details:</span> {service.details}
                  </p>
                )}
                <p className="text-xs text-gray-500 mt-2">
                  Last checked: {new Date(service.lastChecked).toLocaleString()}
                </p>
                {service.lastIncident && (
                  <p className="text-xs text-gray-500">
                    Last incident: {new Date(service.lastIncident).toLocaleString()}
                  </p>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
