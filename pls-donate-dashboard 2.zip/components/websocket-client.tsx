"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useWebSocket } from "@/lib/websocket"

interface WebSocketClientProps {
  onEvent?: (event: any) => void
  autoConnect?: boolean
  children?: React.ReactNode
}

export function WebSocketClient({ onEvent, autoConnect = true, children }: WebSocketClientProps) {
  const { status, connect, lastEvent } = useWebSocket()
  const [isConnected, setIsConnected] = useState(false)

  // Connect to WebSocket on component mount if autoConnect is true
  useEffect(() => {
    if (autoConnect) {
      connect()
    }
  }, [autoConnect, connect])

  // Update connection status when WebSocket status changes
  useEffect(() => {
    setIsConnected(status === "connected")
  }, [status])

  // Call onEvent callback when a new event is received
  useEffect(() => {
    if (lastEvent && onEvent) {
      onEvent(lastEvent)
    }
  }, [lastEvent, onEvent])

  return children ? <>{children}</> : null
}
