"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import {
  LayoutDashboard,
  Settings,
  MessageSquare,
  Bell,
  FileCode,
  Users,
  LogOut,
  ChevronDown,
  Menu,
  BarChart2,
  Award,
  Webhook,
  Clock,
  Moon,
  Sun,
  Shield,
  Database,
  Activity,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { useTheme } from "next-themes"
import { Badge } from "@/components/ui/badge"
import { WebSocketClient } from "@/components/websocket-client"
import { hasPermission } from "@/lib/admin-roles"

interface SidebarProps {
  user: {
    username: string
    role: string
  }
}

export function Sidebar({ user }: SidebarProps) {
  const pathname = usePathname()
  const router = useRouter()
  const { theme, setTheme } = useTheme()
  const [isOpen, setIsOpen] = useState(true)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [notifications, setNotifications] = useState(0)

  // Handle WebSocket events
  const handleWebSocketEvent = (event: any) => {
    if (event.type === "NOTIFICATION") {
      setNotifications((prev) => prev + 1)
    }
  }

  const mainNavItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: LayoutDashboard,
    },
    {
      title: "Analytics",
      href: "/dashboard/analytics",
      icon: BarChart2,
      badge: "Live",
      badgeColor: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
      requiredPermission: "canAccessAnalytics",
    },
    {
      title: "Leaderboards",
      href: "/dashboard/leaderboards",
      icon: Award,
    },
    {
      title: "Configuration",
      href: "/dashboard/configuration",
      icon: Settings,
      children: [
        { title: "Themes", href: "/dashboard/configuration/themes" },
        { title: "AB Tests", href: "/dashboard/configuration/ab-tests" },
      ],
      requiredPermission: "canManageSettings",
    },
    {
      title: "Webhooks",
      href: "/dashboard/webhooks",
      icon: Webhook,
      requiredPermission: "canManageWebhooks",
    },
    {
      title: "Audit Log",
      href: "/dashboard/audit-log",
      icon: Clock,
      requiredPermission: "canViewAuditLog",
    },
    {
      title: "Cache Management",
      href: "/dashboard/cache",
      icon: Database,
      requiredPermission: "canManageCache",
    },
    {
      title: "System Status",
      href: "/dashboard/system",
      icon: Activity,
      requiredPermission: "canViewSystemStatus",
    },
    {
      title: "Shoutbox / Chat",
      href: "/dashboard/chat",
      icon: MessageSquare,
    },
    {
      title: "Notifications",
      href: "/dashboard/notifications",
      icon: Bell,
      badge: notifications > 0 ? String(notifications) : undefined,
      badgeColor: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200",
    },
    {
      title: "Scripts",
      href: "/dashboard/scripts",
      icon: FileCode,
      children: [
        { title: "Review", href: "/dashboard/scripts/review" },
        { title: "Reputation", href: "/dashboard/scripts/reputation" },
      ],
    },
    {
      title: "People",
      href: "/dashboard/people",
      icon: Users,
      children: [
        { title: "Find", href: "/dashboard/people/find" },
        { title: "Blacklist", href: "/dashboard/people/blacklist" },
      ],
      requiredPermission: "canBanUsers",
    },
    {
      title: "Admin",
      href: "/dashboard/admin",
      icon: Shield,
      requiredPermission: ["canManageAdmins", "canToggleMaintenance"],
      requireAny: true,
    },
  ]

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" })
    router.push("/login")
    router.refresh()
  }

  // Toggle theme
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  // Filter nav items based on user permissions
  const filteredNavItems = mainNavItems.filter((item) => {
    if (!item.requiredPermission) return true

    if (Array.isArray(item.requiredPermission) && item.requireAny) {
      // If any of the permissions is granted, show the item
      return item.requiredPermission.some((permission) => hasPermission(user.role, permission as any))
    } else if (Array.isArray(item.requiredPermission)) {
      // If all permissions are required, check each one
      return item.requiredPermission.every((permission) => hasPermission(user.role, permission as any))
    }

    // Single permission check
    return hasPermission(user.role, item.requiredPermission as any)
  })

  return (
    <>
      {/* WebSocket client */}
      <WebSocketClient onEvent={handleWebSocketEvent} />

      {/* Mobile menu button */}
      <Button
        variant="outline"
        size="icon"
        className="fixed top-4 left-4 z-50 md:hidden hover:bg-gray-100 dark:hover:bg-gray-800 transition-all duration-200"
        onClick={() => setMobileOpen(!mobileOpen)}
      >
        <Menu className="h-5 w-5" />
      </Button>

      {/* Sidebar */}
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 bg-white dark:bg-gray-900 shadow-lg transform transition-transform duration-300 ease-in-out md:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full",
          mobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0",
        )}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="px-4 py-6 border-b dark:border-gray-800 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
            <h1 className="text-xl font-bold">PLS DONATE Dashboard</h1>
            <div className="mt-2 text-sm text-blue-100">
              <p>{user.username}</p>
              <p
                className={cn(
                  user.role === "SuperAdmin" && "text-red-300",
                  user.role === "HeadAdmin" && "text-purple-300",
                  user.role === "SeniorAdmin" && "text-indigo-300",
                  user.role === "Admin" && "text-blue-300",
                  user.role === "ModeratorPlus" && "text-teal-300",
                  user.role === "Moderator" && "text-green-300",
                )}
              >
                {user.role}
              </p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-2 py-4 overflow-y-auto">
            <ul className="space-y-1">
              {filteredNavItems.map((item) => (
                <li
                  key={item.href}
                  className="animate-fade-in"
                  style={{ animationDelay: `${filteredNavItems.indexOf(item) * 50}ms` }}
                >
                  {item.children ? (
                    <Collapsible>
                      <CollapsibleTrigger asChild>
                        <button className="flex items-center w-full px-3 py-2 text-sm font-medium rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200">
                          <item.icon className="w-5 h-5 mr-3 text-gray-500 dark:text-gray-400" />
                          <span>{item.title}</span>
                          {item.badge && <Badge className={cn("ml-auto mr-2", item.badgeColor)}>{item.badge}</Badge>}
                          <ChevronDown className="w-4 h-4 ml-auto transition-transform duration-200" />
                        </button>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <ul className="mt-1 pl-8 space-y-1">
                          {item.children.map((child) => (
                            <li key={child.href} className="animate-fade-in">
                              <Link
                                href={child.href}
                                className={cn(
                                  "block px-3 py-2 text-sm rounded-md transition-colors duration-200",
                                  pathname === child.href
                                    ? "bg-blue-50 text-blue-700 font-medium dark:bg-blue-900/30 dark:text-blue-200"
                                    : "hover:bg-gray-50 dark:hover:bg-gray-800",
                                )}
                              >
                                {child.title}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </CollapsibleContent>
                    </Collapsible>
                  ) : (
                    <Link
                      href={item.href}
                      className={cn(
                        "flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors duration-200",
                        pathname === item.href
                          ? "bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-200"
                          : "hover:bg-gray-50 dark:hover:bg-gray-800",
                      )}
                    >
                      <item.icon
                        className={cn(
                          "w-5 h-5 mr-3",
                          pathname === item.href
                            ? "text-blue-700 dark:text-blue-200"
                            : "text-gray-500 dark:text-gray-400",
                        )}
                      />
                      <span>{item.title}</span>
                      {item.badge && <Badge className={cn("ml-auto", item.badgeColor)}>{item.badge}</Badge>}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </nav>

          {/* Footer */}
          <div className="px-4 py-4 border-t dark:border-gray-800">
            <div className="flex items-center justify-between mb-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
              >
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              <div className="text-xs text-gray-500 dark:text-gray-400">
                <span className="flex items-center">
                  <span className="w-2 h-2 bg-green-500 rounded-full mr-1"></span>
                  Connected
                </span>
              </div>
            </div>
            <Button
              variant="outline"
              className="w-full flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
              onClick={handleLogout}
            >
              <LogOut className="w-4 h-4 mr-2" />
              Log out
            </Button>
          </div>
        </div>
      </div>
    </>
  )
}
