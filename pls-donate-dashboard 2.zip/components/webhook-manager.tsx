"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { AlertCircle, Check, Loader2, Plus, Trash2, AlertTriangle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import type { WebhookConfig, WebhookProvider } from "@/lib/webhooks"

export function WebhookManager() {
  const [webhooks, setWebhooks] = useState<WebhookConfig[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreating, setIsCreating] = useState(false)
  const [isTesting, setIsTesting] = useState<string | null>(null)
  const [testResult, setTestResult] = useState<{ success: boolean; message?: string } | null>(null)
  const [error, setError] = useState<string | null>(null)

  // New webhook form state
  const [newWebhook, setNewWebhook] = useState<Partial<WebhookConfig>>({
    name: "",
    provider: "discord",
    url: "",
    events: ["game_update", "user_ban", "donation"],
    enabled: true,
  })

  // Available events
  const availableEvents = [
    { id: "game_update", label: "Game Updates" },
    { id: "store_update", label: "Store Updates" },
    { id: "user_ban", label: "User Bans" },
    { id: "donation", label: "Donations" },
    { id: "audit_log", label: "Audit Logs" },
  ]

  // Load webhooks on component mount
  useEffect(() => {
    fetchWebhooks()
  }, [])

  // Fetch webhooks from API
  const fetchWebhooks = async () => {
    setIsLoading(true)
    setError(null)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Mock data
      setWebhooks([
        {
          id: "1",
          name: "Discord Alerts",
          provider: "discord",
          url: "https://discord.com/api/webhooks/example",
          events: ["game_update", "user_ban", "donation"],
          enabled: true,
          createdAt: new Date("2023-01-15"),
          lastTriggered: new Date("2023-05-20"),
        },
        {
          id: "2",
          name: "Slack Notifications",
          provider: "slack",
          url: "https://hooks.slack.com/services/example",
          events: ["user_ban", "donation"],
          enabled: false,
          createdAt: new Date("2023-03-10"),
        },
      ])
    } catch (err) {
      setError("Failed to load webhooks")
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  // Create new webhook
  const createWebhook = async () => {
    if (!newWebhook.name || !newWebhook.url || !newWebhook.events?.length) {
      setError("Please fill in all required fields")
      return
    }

    setIsCreating(true)
    setError(null)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Add new webhook to list
      const webhook: WebhookConfig = {
        id: Date.now().toString(),
        name: newWebhook.name,
        provider: newWebhook.provider as WebhookProvider,
        url: newWebhook.url,
        events: newWebhook.events || [],
        enabled: newWebhook.enabled || false,
        createdAt: new Date(),
      }

      setWebhooks((prev) => [...prev, webhook])

      // Reset form
      setNewWebhook({
        name: "",
        provider: "discord",
        url: "",
        events: ["game_update", "user_ban", "donation"],
        enabled: true,
      })
    } catch (err) {
      setError("Failed to create webhook")
      console.error(err)
    } finally {
      setIsCreating(false)
    }
  }

  // Toggle webhook enabled state
  const toggleWebhook = async (id: string, enabled: boolean) => {
    setWebhooks((prev) => prev.map((webhook) => (webhook.id === id ? { ...webhook, enabled } : webhook)))

    // In a real app, you would update the webhook in the database
  }

  // Delete webhook
  const deleteWebhook = async (id: string) => {
    setWebhooks((prev) => prev.filter((webhook) => webhook.id !== id))

    // In a real app, you would delete the webhook from the database
  }

  // Test webhook
  const testWebhook = async (id: string) => {
    setIsTesting(id)
    setTestResult(null)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      // Simulate success (80%) or failure (20%)
      const success = Math.random() > 0.2

      setTestResult({
        success,
        message: success ? "Webhook test successful!" : "Webhook test failed. Check the URL and try again.",
      })
    } catch (err) {
      setTestResult({
        success: false,
        message: "Test failed due to an error",
      })
    } finally {
      setTimeout(() => {
        setIsTesting(null)
        setTimeout(() => setTestResult(null), 3000)
      }, 1000)
    }
  }

  // Handle event checkbox change
  const handleEventChange = (event: string, checked: boolean) => {
    setNewWebhook((prev) => ({
      ...prev,
      events: checked ? [...(prev.events || []), event] : (prev.events || []).filter((e) => e !== event),
    }))
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
          <p className="text-gray-500">Loading webhooks...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive" className="animate-slide-down">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="existing">
        <TabsList className="mb-4">
          <TabsTrigger value="existing">Existing Webhooks</TabsTrigger>
          <TabsTrigger value="new">Create New</TabsTrigger>
        </TabsList>

        <TabsContent value="existing" className="animate-fade-in">
          {webhooks.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-gray-500 mb-4">No webhooks configured yet</p>
                <Button onClick={() => document.querySelector('[data-value="new"]')?.click()}>
                  <Plus className="w-4 h-4 mr-1" />
                  Create Your First Webhook
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {webhooks.map((webhook) => (
                <Card key={webhook.id} className="hover-lift overflow-hidden">
                  <CardContent className="p-0">
                    <div className="flex flex-col md:flex-row md:items-center">
                      <div className="p-4 md:p-6 flex-1">
                        <div className="flex items-center mb-2">
                          <h3 className="font-medium text-lg">{webhook.name}</h3>
                          <div className="ml-2 px-2 py-0.5 text-xs rounded-full bg-gray-100 dark:bg-gray-800">
                            {webhook.provider}
                          </div>
                          {webhook.enabled ? (
                            <div className="ml-2 px-2 py-0.5 text-xs rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                              Active
                            </div>
                          ) : (
                            <div className="ml-2 px-2 py-0.5 text-xs rounded-full bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200">
                              Disabled
                            </div>
                          )}
                        </div>

                        <p className="text-sm text-gray-500 mb-2 truncate">{webhook.url}</p>

                        <div className="flex flex-wrap gap-1 mb-2">
                          {webhook.events.map((event) => (
                            <span
                              key={event}
                              className="px-2 py-0.5 text-xs rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
                            >
                              {event}
                            </span>
                          ))}
                        </div>

                        <div className="text-xs text-gray-500">
                          Created: {new Date(webhook.createdAt).toLocaleDateString()}
                          {webhook.lastTriggered && (
                            <span className="ml-4">
                              Last triggered: {new Date(webhook.lastTriggered).toLocaleString()}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 p-4 md:p-6 bg-gray-50 dark:bg-gray-800/50">
                        <div className="flex items-center space-x-2">
                          <Switch
                            id={`webhook-${webhook.id}`}
                            checked={webhook.enabled}
                            onCheckedChange={(checked) => toggleWebhook(webhook.id, checked)}
                          />
                          <Label htmlFor={`webhook-${webhook.id}`} className="sr-only">
                            {webhook.enabled ? "Enabled" : "Disabled"}
                          </Label>
                        </div>

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => testWebhook(webhook.id)}
                          disabled={isTesting === webhook.id}
                        >
                          {isTesting === webhook.id ? <Loader2 className="h-4 w-4 animate-spin" /> : "Test"}
                        </Button>

                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-500 hover:text-red-700"
                          onClick={() => deleteWebhook(webhook.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>

                        {testResult && isTesting === webhook.id && (
                          <div className={`text-sm ${testResult.success ? "text-green-500" : "text-red-500"}`}>
                            {testResult.success ? <Check className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="new" className="animate-fade-in">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="webhook-name">Webhook Name</Label>
                <Input
                  id="webhook-name"
                  value={newWebhook.name}
                  onChange={(e) => setNewWebhook({ ...newWebhook, name: e.target.value })}
                  placeholder="e.g., Discord Notifications"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="webhook-provider">Provider</Label>
                <Select
                  value={newWebhook.provider}
                  onValueChange={(value) => setNewWebhook({ ...newWebhook, provider: value as WebhookProvider })}
                >
                  <SelectTrigger id="webhook-provider">
                    <SelectValue placeholder="Select provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="discord">Discord</SelectItem>
                    <SelectItem value="slack">Slack</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="webhook-url">Webhook URL</Label>
                <Input
                  id="webhook-url"
                  value={newWebhook.url}
                  onChange={(e) => setNewWebhook({ ...newWebhook, url: e.target.value })}
                  placeholder="https://"
                />
              </div>

              <div className="space-y-2">
                <Label>Events</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-1">
                  {availableEvents.map((event) => (
                    <div key={event.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`event-${event.id}`}
                        checked={(newWebhook.events || []).includes(event.id)}
                        onCheckedChange={(checked) => handleEventChange(event.id, !!checked)}
                      />
                      <Label htmlFor={`event-${event.id}`}>{event.label}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="webhook-enabled"
                  checked={newWebhook.enabled}
                  onCheckedChange={(checked) => setNewWebhook({ ...newWebhook, enabled: checked })}
                />
                <Label htmlFor="webhook-enabled">Enable webhook immediately</Label>
              </div>

              <div className="flex justify-end">
                <Button onClick={createWebhook} disabled={isCreating}>
                  {isCreating ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-1" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4 mr-1" />
                      Create Webhook
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
