"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, RefreshCw, Loader2, TrendingUp, TrendingDown, Clock } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Line, LineChart, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import type { PerformanceMetric, MetricType } from "@/lib/performance-monitor"

export function PerformanceDashboard() {
  const [metrics, setMetrics] = useState<Record<MetricType, PerformanceMetric[]>>({} as any)
  const [summary, setSummary] = useState<
    Record<MetricType, { avg: number | null; max: number | null; min: number | null }>
  >({} as any)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Load performance metrics on component mount
  useEffect(() => {
    fetchPerformanceData()

    // Set up auto-refresh every 30 seconds
    const interval = setInterval(() => {
      fetchPerformanceData()
    }, 30000)

    return () => clearInterval(interval)
  }, [])

  // Fetch performance data from API
  const fetchPerformanceData = async () => {
    setIsRefreshing(true)
    setError(null)

    try {
      const response = await fetch("/api/system/performance")

      if (!response.ok) {
        throw new Error("Failed to fetch performance data")
      }

      const data = await response.json()
      setMetrics(data.metrics)
      setSummary(data.summary)
    } catch (error) {
      setError("Failed to load performance data")
      console.error(error)
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }

  // Format date for chart
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString)
      return `${date.getHours()}:${date.getMinutes().toString().padStart(2, "0")}`
    } catch (error) {
      return ""
    }
  }

  // Format metric name for display
  const formatMetricName = (type: MetricType) => {
    return type
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  // Format metric value based on type
  const formatMetricValue = (type: MetricType, value: number) => {
    switch (type) {
      case "api_response_time":
      case "page_load_time":
      case "database_query_time":
      case "webhook_processing_time":
      case "background_job_time":
        return `${value.toFixed(2)} ms`
      case "cache_hit_ratio":
        return `${(value * 100).toFixed(2)}%`
      case "memory_usage":
        return formatBytes(value)
      case "cpu_usage":
        return `${value.toFixed(2)}%`
      case "active_connections":
        return value.toString()
      default:
        return value.toString()
    }
  }

  // Helper function to format bytes
  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes"

    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB", "TB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))

    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  // Prepare chart data
  const prepareChartData = (metricType: MetricType) => {
    if (!metrics[metricType]) return []

    return metrics[metricType].map((metric) => ({
      time: formatDate(metric.timestamp),
      value: metric.value,
      timestamp: metric.timestamp,
    }))
  }

  // Get trend indicator
  const getTrendIndicator = (metricType: MetricType) => {
    if (!metrics[metricType] || metrics[metricType].length < 2) return null

    const sortedMetrics = [...metrics[metricType]].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime(),
    )

    const first = sortedMetrics[0].value
    const last = sortedMetrics[sortedMetrics.length - 1].value

    const percentChange = ((last - first) / first) * 100

    // Determine if trend is good or bad based on metric type
    let isGood: boolean

    switch (metricType) {
      case "cache_hit_ratio":
        isGood = percentChange > 0
        break
      case "api_response_time":
      case "page_load_time":
      case "database_query_time":
      case "webhook_processing_time":
      case "background_job_time":
      case "memory_usage":
      case "cpu_usage":
        isGood = percentChange < 0
        break
      default:
        isGood = percentChange > 0
    }

    return {
      percentChange: Math.abs(percentChange).toFixed(2),
      isGood,
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
          <p className="text-gray-500">Loading performance data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive" className="animate-slide-down">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Performance Dashboard</h3>
        <div className="flex items-center gap-2">
          <p className="text-sm text-gray-500">
            <Clock className="inline-block h-4 w-4 mr-1" />
            Auto-refreshes every 30 seconds
          </p>
          <Button variant="outline" size="sm" onClick={fetchPerformanceData} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 mr-1 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Object.keys(summary).map((metricType) => {
          const type = metricType as MetricType
          const data = summary[type]
          const trend = getTrendIndicator(type)

          return (
            <Card key={type} className="overflow-hidden">
              <CardHeader className="pb-2">
                <CardTitle className="text-md font-medium">{formatMetricName(type)}</CardTitle>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-2xl font-bold">
                      {data.avg !== null ? formatMetricValue(type, data.avg) : "N/A"}
                    </p>
                    <p className="text-sm text-gray-500">
                      Min: {data.min !== null ? formatMetricValue(type, data.min) : "N/A"} | Max:{" "}
                      {data.max !== null ? formatMetricValue(type, data.max) : "N/A"}
                    </p>
                  </div>

                  {trend && (
                    <div className={`flex items-center ${trend.isGood ? "text-green-500" : "text-red-500"}`}>
                      {trend.isGood ? (
                        <TrendingUp className="h-5 w-5 mr-1" />
                      ) : (
                        <TrendingDown className="h-5 w-5 mr-1" />
                      )}
                      <span className="font-medium">{trend.percentChange}%</span>
                    </div>
                  )}
                </div>

                <div className="h-32 mt-4">
                  <ChartContainer
                    config={{
                      value: {
                        label: formatMetricName(type),
                        color: "hsl(var(--chart-1))",
                      },
                    }}
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={prepareChartData(type)}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Line
                          type="monotone"
                          dataKey="value"
                          stroke="var(--color-value)"
                          name={formatMetricName(type)}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
