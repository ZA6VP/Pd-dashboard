"use client"

import { useState } from "react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Moon, Sun, Laptop } from "lucide-react"

export function ThemeSettings() {
  const { theme, setTheme } = useTheme()
  const [accentColor, setAccentColor] = useState("blue")

  const accentColors = [
    { name: "Blue", value: "blue" },
    { name: "Green", value: "green" },
    { name: "Red", value: "red" },
    { name: "Purple", value: "purple" },
    { name: "Orange", value: "orange" },
  ]

  return (
    <Tabs defaultValue="mode">
      <TabsList className="mb-4">
        <TabsTrigger value="mode">Mode</TabsTrigger>
        <TabsTrigger value="accent">Accent Color</TabsTrigger>
      </TabsList>

      <TabsContent value="mode">
        <div className="grid grid-cols-3 gap-4">
          <div className="flex flex-col items-center gap-2">
            <Button
              variant={theme === "light" ? "default" : "outline"}
              size="lg"
              className="w-full h-24 flex flex-col gap-2"
              onClick={() => setTheme("light")}
            >
              <Sun className="h-6 w-6" />
              <span>Light</span>
            </Button>
          </div>
          <div className="flex flex-col items-center gap-2">
            <Button
              variant={theme === "dark" ? "default" : "outline"}
              size="lg"
              className="w-full h-24 flex flex-col gap-2"
              onClick={() => setTheme("dark")}
            >
              <Moon className="h-6 w-6" />
              <span>Dark</span>
            </Button>
          </div>
          <div className="flex flex-col items-center gap-2">
            <Button
              variant={theme === "system" ? "default" : "outline"}
              size="lg"
              className="w-full h-24 flex flex-col gap-2"
              onClick={() => setTheme("system")}
            >
              <Laptop className="h-6 w-6" />
              <span>System</span>
            </Button>
          </div>
        </div>
      </TabsContent>

      <TabsContent value="accent">
        <div className="space-y-4">
          <div>
            <Label>Accent Color</Label>
            <RadioGroup
              value={accentColor}
              onValueChange={setAccentColor}
              className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-2"
            >
              {accentColors.map((color) => (
                <div key={color.value} className="flex items-center space-x-2">
                  <RadioGroupItem value={color.value} id={`color-${color.value}`} />
                  <Label htmlFor={`color-${color.value}`} className="flex items-center">
                    <div className="w-4 h-4 rounded-full mr-2" style={{ backgroundColor: color.value }}></div>
                    {color.name}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <div className="flex justify-end">
            <Button>Save Changes</Button>
          </div>
        </div>
      </TabsContent>
    </Tabs>
  )
}
