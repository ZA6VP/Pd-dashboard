"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { AlertCircle, RefreshCw, Loader2, Search, Trash2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface ErrorLog {
  timestamp: string
  message: string
  stack?: string
  context?: Record<string, any>
}

export function ErrorLogViewer() {
  const [errors, setErrors] = useState<ErrorLog[]>([])
  const [filteredErrors, setFilteredErrors] = useState<ErrorLog[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedError, setSelectedError] = useState<ErrorLog | null>(null)
  const [clearDialogOpen, setClearDialogOpen] = useState(false)
  const [isClearing, setIsClearing] = useState(false)

  // Load error logs on component mount
  useEffect(() => {
    fetchErrorLogs()
  }, [])

  // Filter errors when search query changes
  useEffect(() => {
    if (!searchQuery) {
      setFilteredErrors(errors)
      return
    }

    const query = searchQuery.toLowerCase()
    const filtered = errors.filter(
      (err) =>
        err.message.toLowerCase().includes(query) ||
        (err.stack && err.stack.toLowerCase().includes(query)) ||
        (err.context && JSON.stringify(err.context).toLowerCase().includes(query)),
    )

    setFilteredErrors(filtered)
  }, [searchQuery, errors])

  // Fetch error logs from API
  const fetchErrorLogs = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/system/errors")

      if (!response.ok) {
        throw new Error("Failed to fetch error logs")
      }

      const data = await response.json()
      setErrors(data)
      setFilteredErrors(data)
    } catch (error) {
      setError("Failed to load error logs")
      console.error(error)
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }

  // Refresh error logs
  const refreshLogs = async () => {
    setIsRefreshing(true)
    await fetchErrorLogs()
  }

  // Clear error logs
  const clearLogs = async () => {
    setIsClearing(true)
    setError(null)

    try {
      const response = await fetch("/api/system/errors", {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Failed to clear error logs")
      }

      setErrors([])
      setFilteredErrors([])
      setClearDialogOpen(false)
    } catch (error) {
      setError("Failed to clear error logs")
      console.error(error)
    } finally {
      setIsClearing(false)
    }
  }

  // Format date
  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleString()
    } catch (error) {
      return dateString
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
          <p className="text-gray-500">Loading error logs...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive" className="animate-slide-down">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Error Logs</h3>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={refreshLogs} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 mr-1 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>

          <Dialog open={clearDialogOpen} onOpenChange={setClearDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <Trash2 className="h-4 w-4 mr-1" />
                Clear Logs
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Clear Error Logs</DialogTitle>
                <DialogDescription>
                  Are you sure you want to clear all error logs? This action cannot be undone.
                </DialogDescription>
              </DialogHeader>

              <DialogFooter>
                <Button variant="outline" onClick={() => setClearDialogOpen(false)}>
                  Cancel
                </Button>
                <Button variant="destructive" onClick={clearLogs} disabled={isClearing}>
                  {isClearing ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-1" />
                      Clearing...
                    </>
                  ) : (
                    "Clear Logs"
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
        <Input
          placeholder="Search error logs..."
          className="pl-10"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {filteredErrors.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          {errors.length === 0 ? "No error logs found" : "No errors match your search"}
        </div>
      ) : (
        <div className="border rounded-md overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 dark:bg-gray-800">
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Timestamp
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Error Message
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Context
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {filteredErrors.map((err, index) => (
                <tr
                  key={index}
                  className="hover:bg-gray-50 dark:hover:bg-gray-800/50 cursor-pointer"
                  onClick={() => setSelectedError(err)}
                >
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {formatDate(err.timestamp)}
                  </td>
                  <td className="px-4 py-3 text-sm">
                    <div className="font-medium text-red-600 truncate max-w-xs">{err.message}</div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {err.context ? Object.keys(err.context).join(", ") : "None"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Error details dialog */}
      {selectedError && (
        <Dialog open={!!selectedError} onOpenChange={(open) => !open && setSelectedError(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Error Details</DialogTitle>
              <DialogDescription>{formatDate(selectedError.timestamp)}</DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div>
                <h4 className="text-sm font-medium mb-1">Error Message</h4>
                <div className="p-3 bg-red-50 text-red-800 rounded-md">{selectedError.message}</div>
              </div>

              {selectedError.stack && (
                <div>
                  <h4 className="text-sm font-medium mb-1">Stack Trace</h4>
                  <pre className="p-3 bg-gray-50 text-gray-800 rounded-md overflow-auto text-xs">
                    {selectedError.stack}
                  </pre>
                </div>
              )}

              {selectedError.context && Object.keys(selectedError.context).length > 0 && (
                <div>
                  <h4 className="text-sm font-medium mb-1">Context</h4>
                  <pre className="p-3 bg-gray-50 text-gray-800 rounded-md overflow-auto text-xs">
                    {JSON.stringify(selectedError.context, null, 2)}
                  </pre>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button onClick={() => setSelectedError(null)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
