"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger } from "@/components/ui/select"
import { Loader2, Search, RefreshCw, TrendingUp, Medal } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { formatNumber } from "@/lib/utils"

interface LeaderboardEntry {
  id: string | number
  rank: number
  name: string
  amount: number
  change?: number
  avatar?: string
}

interface GameStats {
  id: string | number
  rank: number
  name: string
  totalDonations: number
  activePlayers: number
  averageDonation: number
}

type LeaderboardType = "donors" | "recipients" | "games"

interface LeaderboardTableProps {
  type: LeaderboardType
}

export function LeaderboardTable({ type }: LeaderboardTableProps) {
  const [data, setData] = useState<LeaderboardEntry[] | GameStats[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [filter, setFilter] = useState("")
  const [timeRange, setTimeRange] = useState("all")

  // Load data on component mount
  useEffect(() => {
    fetchData()
  }, [type, timeRange])

  // Fetch data from API
  const fetchData = async () => {
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Sample data based on type
      if (type === "donors") {
        setData([
          {
            id: 1,
            rank: 1,
            name: "SuperDonor123",
            amount: 50000,
            change: 2,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 2,
            rank: 2,
            name: "RobloxGiver99",
            amount: 35000,
            change: -1,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 3,
            rank: 3,
            name: "GenerousPlayer",
            amount: 28000,
            change: 1,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 3,
            rank: 3,
            name: "GenerousPlayer",
            amount: 28000,
            change: 1,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 4,
            rank: 4,
            name: "KindSoul42",
            amount: 22000,
            change: 0,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 5,
            rank: 5,
            name: "GiftGiver2023",
            amount: 18500,
            change: 3,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 6,
            rank: 6,
            name: "CharityChamp",
            amount: 15000,
            change: -2,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 7,
            rank: 7,
            name: "DonationKing",
            amount: 12800,
            change: 0,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 8,
            rank: 8,
            name: "RobuxRoyal",
            amount: 10500,
            change: 5,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 9,
            rank: 9,
            name: "GivingHeart",
            amount: 9200,
            change: -3,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 10,
            rank: 10,
            name: "BountifulUser",
            amount: 8000,
            change: 1,
            avatar: "/placeholder.svg?height=40&width=40",
          },
        ])
      } else if (type === "recipients") {
        setData([
          {
            id: 1,
            rank: 1,
            name: "LuckyReceiver",
            amount: 75000,
            change: 0,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 2,
            rank: 2,
            name: "FortunateOne",
            amount: 62000,
            change: 0,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 3,
            rank: 3,
            name: "GratefulGamer",
            amount: 48000,
            change: 2,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 4,
            rank: 4,
            name: "ThankfulPlayer",
            amount: 41000,
            change: -1,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 5,
            rank: 5,
            name: "BlessedUser",
            amount: 36500,
            change: 1,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 6,
            rank: 6,
            name: "AppreciativeGuy",
            amount: 29000,
            change: 3,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 7,
            rank: 7,
            name: "RichNowLol",
            amount: 25800,
            change: -2,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 8,
            rank: 8,
            name: "WealthyWinner",
            amount: 22500,
            change: 0,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 9,
            rank: 9,
            name: "FortunateSoul",
            amount: 19200,
            change: 4,
            avatar: "/placeholder.svg?height=40&width=40",
          },
          {
            id: 10,
            rank: 10,
            name: "LuckyDuck",
            amount: 17000,
            change: -3,
            avatar: "/placeholder.svg?height=40&width=40",
          },
        ])
      } else {
        setData([
          {
            id: 1,
            rank: 1,
            name: "PLS DONATE G!",
            totalDonations: 1250000,
            activePlayers: 1250,
            averageDonation: 1000,
          },
          {
            id: 2,
            rank: 2,
            name: "PLS DONATE ZAP!",
            totalDonations: 980000,
            activePlayers: 875,
            averageDonation: 1120,
          },
          {
            id: 3,
            rank: 3,
            name: "Donation Simulator",
            totalDonations: 750000,
            activePlayers: 620,
            averageDonation: 1210,
          },
          { id: 4, rank: 4, name: "Charity Tycoon", totalDonations: 580000, activePlayers: 450, averageDonation: 1290 },
          { id: 5, rank: 5, name: "Giving Plaza", totalDonations: 420000, activePlayers: 380, averageDonation: 1105 },
        ])
      }
    } catch (error) {
      console.error("Error fetching leaderboard data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Filter data by search term
  const filteredData = data.filter((entry) => {
    if (!filter) return true

    const searchTerm = filter.toLowerCase()
    return entry.name.toLowerCase().includes(searchTerm)
  })

  // Render change indicator
  const renderChange = (change: number) => {
    if (change === 0) return null

    if (change > 0) {
      return (
        <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
          <TrendingUp className="h-3 w-3 mr-1" />
          {change}
        </Badge>
      )
    }

    return (
      <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
        <TrendingUp className="h-3 w-3 mr-1 transform rotate-180" />
        {Math.abs(change)}
      </Badge>
    )
  }

  // Render rank medal
  const renderRank = (rank: number) => {
    if (rank === 1) {
      return <Medal className="h-5 w-5 text-yellow-500" />
    }
    if (rank === 2) {
      return <Medal className="h-5 w-5 text-gray-400" />
    }
    if (rank === 3) {
      return <Medal className="h-5 w-5 text-amber-700" />
    }
    return <span className="font-medium">{rank}</span>
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
          <Input
            placeholder={`Search ${type}...`}
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="pl-8"
          />
        </div>

        <div className="flex gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[140px]">
              <span className="truncate">
                {timeRange === "all"
                  ? "All Time"
                  : timeRange === "month"
                    ? "This Month"
                    : timeRange === "week"
                      ? "This Week"
                      : "Today"}
              </span>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="day">Today</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" size="icon" onClick={fetchData} title="Refresh">
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="border rounded-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 dark:bg-gray-800">
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-16">
                  Rank
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Name
                </th>
                {type === "games" ? (
                  <>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Total Donations
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Active Players
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Avg. Donation
                    </th>
                  </>
                ) : (
                  <>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Amount
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider w-24">
                      Change
                    </th>
                  </>
                )}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {isLoading ? (
                <tr>
                  <td colSpan={type === "games" ? 5 : 4} className="px-4 py-8 text-center">
                    <div className="flex justify-center">
                      <Loader2 className="h-6 w-6 animate-spin" />
                    </div>
                  </td>
                </tr>
              ) : filteredData.length > 0 ? (
                filteredData.map((entry, index) => (
                  <tr key={entry.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 animate-fade-in">
                    <td className="px-4 py-3 whitespace-nowrap text-center">{renderRank(entry.rank)}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="flex items-center">
                        {"avatar" in entry && (
                          <img
                            src={entry.avatar || "/placeholder.svg"}
                            alt={entry.name}
                            className="h-8 w-8 rounded-full mr-3"
                          />
                        )}
                        <span className="font-medium">{entry.name}</span>
                      </div>
                    </td>
                    {type === "games" ? (
                      <>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className="font-medium">R$ {formatNumber((entry as GameStats).totalDonations)}</span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          {formatNumber((entry as GameStats).activePlayers)}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          R$ {formatNumber((entry as GameStats).averageDonation)}
                        </td>
                      </>
                    ) : (
                      <>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className="font-medium">R$ {formatNumber((entry as LeaderboardEntry).amount)}</span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          {(entry as LeaderboardEntry).change !== undefined &&
                            renderChange((entry as LeaderboardEntry).change!)}
                        </td>
                      </>
                    )}
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={type === "games" ? 5 : 4}
                    className="px-4 py-8 text-center text-gray-500 dark:text-gray-400"
                  >
                    No results found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
