"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { AlertCircle, RefreshCw, Loader2, Download, Trash2, RotateCcw } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import type { Backup } from "@/lib/backup-system"

export function BackupManager() {
  const [backups, setBackups] = useState<Backup[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [isCreating, setIsCreating] = useState(false)
  const [isRestoring, setIsRestoring] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [selectedBackup, setSelectedBackup] = useState<string | null>(null)
  const [restoreDialogOpen, setRestoreDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)

  // Load backups on component mount
  useEffect(() => {
    fetchBackups()
  }, [])

  // Fetch backups from API
  const fetchBackups = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/system/backups")

      if (!response.ok) {
        throw new Error("Failed to fetch backups")
      }

      const data = await response.json()
      setBackups(data)
    } catch (error) {
      setError("Failed to load backups")
      console.error(error)
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }

  // Refresh backups
  const refreshBackups = async () => {
    setIsRefreshing(true)
    await fetchBackups()
  }

  // Create backup
  const createBackup = async () => {
    setIsCreating(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/system/backups", {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Failed to create backup")
      }

      const data = await response.json()
      setSuccess(`Backup created successfully: ${data.id}`)
      await fetchBackups()
    } catch (error) {
      setError("Failed to create backup")
      console.error(error)
    } finally {
      setIsCreating(false)
    }
  }

  // Restore backup
  const restoreBackup = async () => {
    if (!selectedBackup) return

    setIsRestoring(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch(`/api/system/backups/${selectedBackup}/restore`, {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Failed to restore backup")
      }

      setSuccess(`Backup ${selectedBackup} restored successfully`)
      setRestoreDialogOpen(false)
    } catch (error) {
      setError("Failed to restore backup")
      console.error(error)
    } finally {
      setIsRestoring(false)
      setSelectedBackup(null)
    }
  }

  // Delete backup
  const deleteBackup = async () => {
    if (!selectedBackup) return

    setIsDeleting(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch(`/api/system/backups/${selectedBackup}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Failed to delete backup")
      }

      setSuccess(`Backup ${selectedBackup} deleted successfully`)
      setDeleteDialogOpen(false)
      await fetchBackups()
    } catch (error) {
      setError("Failed to delete backup")
      console.error(error)
    } finally {
      setIsDeleting(false)
      setSelectedBackup(null)
    }
  }

  // Format date
  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleString()
    } catch (error) {
      return dateString
    }
  }

  // Format size
  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`
  }

  // Clear success message after 5 seconds
  useEffect(() => {
    if (success) {
      const timer = setTimeout(() => {
        setSuccess(null)
      }, 5000)

      return () => clearTimeout(timer)
    }
  }, [success])

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
          <p className="text-gray-500">Loading backups...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive" className="animate-slide-down">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-50 text-green-800 border-green-200 animate-slide-down">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Database Backups</h3>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={refreshBackups} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 mr-1 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Button size="sm" onClick={createBackup} disabled={isCreating}>
            {isCreating ? (
              <>
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                Creating...
              </>
            ) : (
              "Create Backup"
            )}
          </Button>
        </div>
      </div>

      {backups.length === 0 ? (
        <div className="text-center py-8 text-gray-500">No backups found</div>
      ) : (
        <div className="border rounded-md overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 dark:bg-gray-800">
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  ID
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Created
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Size
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Keys
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {backups.map((backup) => (
                <tr key={backup.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                  <td className="px-4 py-3 whitespace-nowrap text-sm font-medium">{backup.id}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {formatDate(backup.timestamp)}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {formatSize(backup.size)}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {backup.keys}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-medium ${
                        backup.status === "completed"
                          ? "bg-green-100 text-green-800"
                          : backup.status === "in_progress"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-red-100 text-red-800"
                      }`}
                    >
                      {backup.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end gap-2">
                      <Dialog
                        open={restoreDialogOpen && selectedBackup === backup.id}
                        onOpenChange={(open) => {
                          setRestoreDialogOpen(open)
                          if (!open) setSelectedBackup(null)
                        }}
                      >
                        <DialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-blue-500 hover:text-blue-700 hover:bg-blue-100"
                            onClick={() => setSelectedBackup(backup.id)}
                            disabled={backup.status !== "completed"}
                          >
                            <RotateCcw className="h-4 w-4" />
                            <span className="sr-only">Restore</span>
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Restore Backup</DialogTitle>
                            <DialogDescription>
                              Are you sure you want to restore backup {backup.id}? This will overwrite current data.
                            </DialogDescription>
                          </DialogHeader>

                          <DialogFooter>
                            <Button variant="outline" onClick={() => setRestoreDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button onClick={restoreBackup} disabled={isRestoring}>
                              {isRestoring ? (
                                <>
                                  <Loader2 className="h-4 w-4 animate-spin mr-1" />
                                  Restoring...
                                </>
                              ) : (
                                "Restore Backup"
                              )}
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>

                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-indigo-500 hover:text-indigo-700 hover:bg-indigo-100"
                        disabled={backup.status !== "completed"}
                      >
                        <Download className="h-4 w-4" />
                        <span className="sr-only">Download</span>
                      </Button>

                      <Dialog
                        open={deleteDialogOpen && selectedBackup === backup.id}
                        onOpenChange={(open) => {
                          setDeleteDialogOpen(open)
                          if (!open) setSelectedBackup(null)
                        }}
                      >
                        <DialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-red-500 hover:text-red-700 hover:bg-red-100"
                            onClick={() => setSelectedBackup(backup.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Delete Backup</DialogTitle>
                            <DialogDescription>
                              Are you sure you want to delete backup {backup.id}? This action cannot be undone.
                            </DialogDescription>
                          </DialogHeader>

                          <DialogFooter>
                            <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
                              Cancel
                            </Button>
                            <Button variant="destructive" onClick={deleteBackup} disabled={isDeleting}>
                              {isDeleting ? (
                                <>
                                  <Loader2 className="h-4 w-4 animate-spin mr-1" />
                                  Deleting...
                                </>
                              ) : (
                                "Delete Backup"
                              )}
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
