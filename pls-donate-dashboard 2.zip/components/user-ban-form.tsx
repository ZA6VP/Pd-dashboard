"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { AlertCircle, Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function UserBanForm() {
  const [userId, setUserId] = useState("")
  const [gameId, setGameId] = useState("")
  const [reason, setReason] = useState("")
  const [duration, setDuration] = useState("7")
  const [isLoading, setIsLoading] = useState(false)
  const [success, setSuccess] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [games, setGames] = useState<Array<{ placeId: number; name: string }>>([])
  const [recentBans, setRecentBans] = useState<any[]>([])
  const [isLoadingGames, setIsLoadingGames] = useState(true)

  useEffect(() => {
    // Fetch games for the dropdown
    const fetchGames = async () => {
      try {
        const response = await fetch("/api/games")
        if (response.ok) {
          const data = await response.json()
          setGames(
            data.map((game: any) => ({
              placeId: game.placeId,
              name: game.name,
            })),
          )
        }
      } catch (error) {
        console.error("Error fetching games:", error)
      } finally {
        setIsLoadingGames(false)
      }
    }

    // Fetch recent bans
    const fetchRecentBans = async () => {
      try {
        const response = await fetch("/api/ban/recent")
        if (response.ok) {
          const data = await response.json()
          setRecentBans(data)
        }
      } catch (error) {
        console.error("Error fetching recent bans:", error)
      }
    }

    fetchGames()
    fetchRecentBans()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!userId || !gameId || !reason) {
      setError("All fields are required")
      return
    }

    setIsLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/ban", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          placeId: Number.parseInt(gameId),
          userId: Number.parseInt(userId),
          reason,
          duration: Number.parseInt(duration),
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to ban user")
      }

      setSuccess(`User ${userId} has been banned from game ${gameId}`)

      // Reset form
      setUserId("")
      setReason("")

      // Refresh recent bans
      const bansResponse = await fetch("/api/ban/recent")
      if (bansResponse.ok) {
        const bansData = await bansResponse.json()
        setRecentBans(bansData)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div>
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="bg-green-50 text-green-800 border-green-200">
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-2">
          <Label htmlFor="userId">User ID</Label>
          <Input
            id="userId"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            placeholder="Enter Roblox User ID"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="gameId">Game</Label>
          <Select value={gameId} onValueChange={setGameId}>
            <SelectTrigger>
              <SelectValue placeholder={isLoadingGames ? "Loading games..." : "Select a game"} />
            </SelectTrigger>
            <SelectContent>
              {games.map((game) => (
                <SelectItem key={game.placeId} value={game.placeId.toString()}>
                  {game.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="reason">Reason</Label>
          <Textarea
            id="reason"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Enter reason for ban"
            rows={3}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="duration">Duration (days)</Label>
          <Select value={duration} onValueChange={setDuration}>
            <SelectTrigger>
              <SelectValue placeholder="Select duration" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 day</SelectItem>
              <SelectItem value="3">3 days</SelectItem>
              <SelectItem value="7">7 days</SelectItem>
              <SelectItem value="14">14 days</SelectItem>
              <SelectItem value="30">30 days</SelectItem>
              <SelectItem value="365">1 year</SelectItem>
              <SelectItem value="36500">Permanent</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button type="submit" disabled={isLoading}>
          {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
          Ban User
        </Button>
      </form>

      <div className="mt-8">
        <h3 className="text-lg font-medium mb-4">Recent Bans</h3>
        <Card>
          <CardContent className="p-0">
            <table className="w-full">
              <thead>
                <tr className="border-b bg-gray-50">
                  <th className="px-4 py-2 text-left font-medium text-gray-500">User ID</th>
                  <th className="px-4 py-2 text-left font-medium text-gray-500">Game</th>
                  <th className="px-4 py-2 text-left font-medium text-gray-500">Reason</th>
                  <th className="px-4 py-2 text-left font-medium text-gray-500">Expires</th>
                </tr>
              </thead>
              <tbody>
                {recentBans.length > 0 ? (
                  recentBans.map((ban) => (
                    <tr key={`${ban.gameId}-${ban.userId}`} className="border-b last:border-0">
                      <td className="px-4 py-2">{ban.userId}</td>
                      <td className="px-4 py-2">{ban.gameName || ban.gameId}</td>
                      <td className="px-4 py-2">{ban.reason}</td>
                      <td className="px-4 py-2">{new Date(ban.expiresAt).toLocaleDateString()}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="px-4 py-4 text-center text-gray-500">
                      No recent bans
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
