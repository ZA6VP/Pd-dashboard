"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger } from "@/components/ui/select"
import { Loader2, Search, RefreshCw, Filter, Download } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import type { IAuditLog } from "@/lib/models"

export function AuditLogViewer() {
  const [logs, setLogs] = useState<IAuditLog[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [filter, setFilter] = useState("")
  const [actionFilter, setActionFilter] = useState<string>("all")
  const [userFilter, setUserFilter] = useState<string>("all")
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)

  // Sample data for demonstration
  const sampleLogs: IAuditLog[] = [
    {
      _id: "1",
      action: "user_login",
      username: "ZA6VP",
      details: { ip: "192.168.1.1", userAgent: "Chrome/90.0" },
      timestamp: new Date("2023-05-20T10:30:00Z"),
    },
    {
      _id: "2",
      action: "game_update",
      username: "system",
      details: { placeId: 123456789, timestamp: 1621506600 },
      timestamp: new Date("2023-05-20T10:15:00Z"),
    },
    {
      _id: "3",
      action: "user_ban",
      username: "Votiue",
      details: { placeId: 123456789, userId: 54321, reason: "Exploiting", duration: 7 },
      timestamp: new Date("2023-05-19T15:45:00Z"),
    },
    {
      _id: "4",
      action: "store_update",
      username: "system",
      details: { placeId: 987654321, storeName: "GlobalDonations" },
      timestamp: new Date("2023-05-19T14:20:00Z"),
    },
    {
      _id: "5",
      action: "config_change",
      username: "ZA6VP",
      details: { setting: "theme", value: "dark" },
      timestamp: new Date("2023-05-18T09:10:00Z"),
    },
    {
      _id: "6",
      action: "webhook_created",
      username: "ZA6VP",
      details: { name: "Discord Alerts", provider: "discord" },
      timestamp: new Date("2023-05-17T16:30:00Z"),
    },
    {
      _id: "7",
      action: "user_login",
      username: "q_6nnn",
      details: { ip: "192.168.1.2", userAgent: "Firefox/89.0" },
      timestamp: new Date("2023-05-17T11:05:00Z"),
    },
    {
      _id: "8",
      action: "user_ban",
      username: "ZA6VP",
      details: { placeId: 987654321, userId: 98765, reason: "Inappropriate behavior", duration: 3 },
      timestamp: new Date("2023-05-16T13:25:00Z"),
    },
    {
      _id: "9",
      action: "game_update",
      username: "system",
      details: { placeId: 123456789, timestamp: 1621160400 },
      timestamp: new Date("2023-05-16T08:40:00Z"),
    },
    {
      _id: "10",
      action: "store_update",
      username: "system",
      details: { placeId: 123456789, storeName: "PlayerStats" },
      timestamp: new Date("2023-05-15T19:15:00Z"),
    },
  ]

  // Load logs on component mount
  useEffect(() => {
    fetchLogs()
  }, [page, actionFilter, userFilter])

  // Fetch logs from API
  const fetchLogs = async (refresh = false) => {
    if (refresh) {
      setPage(1)
      setLogs([])
    }

    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Filter logs based on action and user filters
      let filteredLogs = [...sampleLogs]

      if (actionFilter !== "all") {
        filteredLogs = filteredLogs.filter((log) => log.action === actionFilter)
      }

      if (userFilter !== "all") {
        filteredLogs = filteredLogs.filter((log) => log.username === userFilter)
      }

      // Paginate logs
      const pageSize = 5
      const startIndex = (page - 1) * pageSize
      const endIndex = startIndex + pageSize
      const paginatedLogs = filteredLogs.slice(startIndex, endIndex)

      // Update state
      if (refresh) {
        setLogs(paginatedLogs)
      } else {
        setLogs((prev) => [...prev, ...paginatedLogs])
      }

      setHasMore(endIndex < filteredLogs.length)
    } catch (error) {
      console.error("Error fetching logs:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Get unique actions and users for filters
  const actions = ["all", ...new Set(sampleLogs.map((log) => log.action))]
  const users = ["all", ...new Set(sampleLogs.map((log) => log.username))]

  // Filter logs by search term
  const filteredLogs = logs.filter((log) => {
    if (!filter) return true

    const searchTerm = filter.toLowerCase()
    return (
      log.action.toLowerCase().includes(searchTerm) ||
      log.username.toLowerCase().includes(searchTerm) ||
      JSON.stringify(log.details).toLowerCase().includes(searchTerm)
    )
  })

  // Format action name for display
  const formatAction = (action: string) => {
    return action
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  // Get badge color based on action
  const getActionColor = (action: string) => {
    switch (action) {
      case "user_login":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200"
      case "user_ban":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
      case "game_update":
      case "store_update":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
      case "config_change":
      case "webhook_created":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200"
    }
  }

  // Export logs as CSV
  const exportLogs = () => {
    const headers = ["Action", "User", "Details", "Timestamp"]
    const csvContent = [
      headers.join(","),
      ...filteredLogs.map((log) =>
        [log.action, log.username, JSON.stringify(log.details), new Date(log.timestamp).toISOString()].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `audit-log-${new Date().toISOString().split("T")[0]}.csv`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search logs..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="pl-8"
          />
        </div>

        <div className="flex gap-2">
          <Select value={actionFilter} onValueChange={setActionFilter}>
            <SelectTrigger className="w-[140px]">
              <div className="flex items-center">
                <Filter className="w-4 h-4 mr-1" />
                <span className="truncate">{actionFilter === "all" ? "All Actions" : formatAction(actionFilter)}</span>
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Actions</SelectItem>
              {actions
                .filter((a) => a !== "all")
                .map((action) => (
                  <SelectItem key={action} value={action}>
                    {formatAction(action)}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>

          <Select value={userFilter} onValueChange={setUserFilter}>
            <SelectTrigger className="w-[140px]">
              <span className="truncate">{userFilter === "all" ? "All Users" : userFilter}</span>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Users</SelectItem>
              {users
                .filter((u) => u !== "all")
                .map((user) => (
                  <SelectItem key={user} value={user}>
                    {user}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>

          <Button variant="outline" size="icon" onClick={() => fetchLogs(true)} title="Refresh">
            <RefreshCw className="h-4 w-4" />
          </Button>

          <Button variant="outline" size="icon" onClick={exportLogs} title="Export as CSV">
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="border rounded-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 dark:bg-gray-800">
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Action
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  User
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Details
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Timestamp
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {filteredLogs.length > 0 ? (
                filteredLogs.map((log) => (
                  <tr key={log._id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 animate-fade-in">
                    <td className="px-4 py-3 whitespace-nowrap">
                      <Badge className={`${getActionColor(log.action)}`}>{formatAction(log.action)}</Badge>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="font-medium">{log.username}</span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="text-sm text-gray-500 dark:text-gray-400 max-w-md truncate">
                        {Object.entries(log.details).map(([key, value]) => (
                          <span key={key} className="mr-2">
                            <span className="font-medium">{key}:</span> {String(value)}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-4 py-8 text-center text-gray-500 dark:text-gray-400">
                    {isLoading ? (
                      <div className="flex justify-center">
                        <Loader2 className="h-6 w-6 animate-spin" />
                      </div>
                    ) : (
                      "No logs found"
                    )}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {hasMore && (
        <div className="flex justify-center mt-4">
          <Button variant="outline" onClick={() => setPage((prev) => prev + 1)} disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-1" />
                Loading...
              </>
            ) : (
              "Load More"
            )}
          </Button>
        </div>
      )}
    </div>
  )
}
