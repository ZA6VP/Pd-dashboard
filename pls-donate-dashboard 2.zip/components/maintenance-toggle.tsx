"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { AlertCircle, Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function MaintenanceToggle() {
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  // Maintenance state
  const [maintenanceEnabled, setMaintenanceEnabled] = useState(false)
  const [maintenanceMessage, setMaintenanceMessage] = useState("")
  const [lastToggled, setLastToggled] = useState<string | null>(null)
  const [toggledBy, setToggledBy] = useState<string | null>(null)

  // Load maintenance status on component mount
  useEffect(() => {
    fetchMaintenanceStatus()
  }, [])

  // Fetch maintenance status from API
  const fetchMaintenanceStatus = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/system/maintenance")

      if (!response.ok) {
        throw new Error("Failed to fetch maintenance status")
      }

      const data = await response.json()

      setMaintenanceEnabled(data.enabled)
      setMaintenanceMessage(data.message)
      setLastToggled(data.lastToggled)
      setToggledBy(data.toggledBy)
    } catch (error) {
      setError("Failed to load maintenance status")
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  // Toggle maintenance mode
  const toggleMaintenance = async () => {
    setIsSubmitting(true)
    setError(null)

    try {
      const response = await fetch("/api/system/maintenance", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          enabled: !maintenanceEnabled,
          message: maintenanceMessage,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to toggle maintenance mode")
      }

      // Update state
      setMaintenanceEnabled(!maintenanceEnabled)

      // Show success message
      setSuccess(`Maintenance mode ${!maintenanceEnabled ? "enabled" : "disabled"} successfully`)

      // Refresh status
      fetchMaintenanceStatus()
    } catch (error) {
      setError(error.message || "Failed to toggle maintenance mode")
    } finally {
      setIsSubmitting(false)
    }
  }

  // Clear success message after 5 seconds
  useEffect(() => {
    if (success) {
      const timer = setTimeout(() => {
        setSuccess(null)
      }, 5000)

      return () => clearTimeout(timer)
    }
  }, [success])

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
          <p className="text-gray-500">Loading maintenance status...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive" className="animate-slide-down">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-50 text-green-800 border-green-200 animate-slide-down">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-medium">Maintenance Mode</h3>
              <p className="text-sm text-gray-500">When enabled, only SuperAdmins can access the dashboard</p>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="maintenance-toggle"
                checked={maintenanceEnabled}
                onCheckedChange={() => toggleMaintenance()}
                disabled={isSubmitting}
              />
              <Label htmlFor="maintenance-toggle">{maintenanceEnabled ? "Enabled" : "Disabled"}</Label>
            </div>
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="maintenance-message">Maintenance Message</Label>
              <Textarea
                id="maintenance-message"
                value={maintenanceMessage}
                onChange={(e) => setMaintenanceMessage(e.target.value)}
                placeholder="Enter message to display during maintenance"
                rows={4}
              />
              <p className="text-xs text-gray-500">
                This message will be displayed to users when they try to access the dashboard during maintenance.
              </p>
            </div>

            <Button
              onClick={toggleMaintenance}
              disabled={isSubmitting}
              variant={maintenanceEnabled ? "destructive" : "default"}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-1" />
                  {maintenanceEnabled ? "Disabling..." : "Enabling..."}
                </>
              ) : maintenanceEnabled ? (
                "Disable Maintenance Mode"
              ) : (
                "Enable Maintenance Mode"
              )}
            </Button>
          </div>

          {lastToggled && (
            <div className="mt-6 pt-6 border-t text-sm text-gray-500">
              <p>Last toggled: {new Date(lastToggled).toLocaleString()}</p>
              {toggledBy && <p>Toggled by: {toggledBy}</p>}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
