"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger } from "@/components/ui/select"
import { Loader2, TrendingUp, TrendingDown, Users, DollarSign, Activity } from "lucide-react"
import { formatNumber } from "@/lib/utils"

// Import Chart.js components
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js"
import { Line, Bar, Doughnut } from "react-chartjs-2"

// Register Chart.js components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend, ArcElement)

type AnalyticsType = "overview" | "donations" | "players" | "performance"

interface AnalyticsDashboardProps {
  type: AnalyticsType
}

export function AnalyticsDashboard({ type }: AnalyticsDashboardProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [timeRange, setTimeRange] = useState("7d")
  const [gameFilter, setGameFilter] = useState("all")
  const [data, setData] = useState<any>(null)

  // Sample game options
  const gameOptions = [
    { id: "all", name: "All Games" },
    { id: "123456789", name: "PLS DONATE G!" },
    { id: "987654321", name: "PLS DONATE ZAP!" },
  ]

  // Load data on component mount
  useEffect(() => {
    fetchData()
  }, [type, timeRange, gameFilter])

  // Fetch data from API
  const fetchData = async () => {
    setIsLoading(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Generate sample data based on type
      let sampleData: any = {}

      // Common date labels
      const dateLabels = generateDateLabels(timeRange)

      if (type === "overview") {
        sampleData = {
          totalDonations: 2250000,
          totalPlayers: 25000,
          activePlayers: 2125,
          averageDonation: 900,
          donationTrend: 12.5,
          playerTrend: 8.3,
          donationsChart: {
            labels: dateLabels,
            datasets: [
              {
                label: "Donations (R$)",
                data: generateRandomData(dateLabels.length, 10000, 50000),
                borderColor: "rgb(59, 130, 246)",
                backgroundColor: "rgba(59, 130, 246, 0.5)",
                tension: 0.3,
              },
            ],
          },
          playersChart: {
            labels: dateLabels,
            datasets: [
              {
                label: "Active Players",
                data: generateRandomData(dateLabels.length, 1500, 2500),
                borderColor: "rgb(16, 185, 129)",
                backgroundColor: "rgba(16, 185, 129, 0.5)",
                tension: 0.3,
              },
            ],
          },
          gameDistribution: {
            labels: ["PLS DONATE G!", "PLS DONATE ZAP!", "Other Games"],
            datasets: [
              {
                data: [55, 35, 10],
                backgroundColor: ["rgba(59, 130, 246, 0.7)", "rgba(16, 185, 129, 0.7)", "rgba(249, 115, 22, 0.7)"],
                borderColor: ["rgb(59, 130, 246)", "rgb(16, 185, 129)", "rgb(249, 115, 22)"],
                borderWidth: 1,
              },
            ],
          },
        }
      } else if (type === "donations") {
        sampleData = {
          totalDonations: 2250000,
          averageDonation: 900,
          largestDonation: 50000,
          donationTrend: 12.5,
          donationsChart: {
            labels: dateLabels,
            datasets: [
              {
                label: "Donations (R$)",
                data: generateRandomData(dateLabels.length, 10000, 50000),
                borderColor: "rgb(59, 130, 246)",
                backgroundColor: "rgba(59, 130, 246, 0.5)",
                tension: 0.3,
              },
            ],
          },
          donationSizeDistribution: {
            labels: ["Small (<R$100)", "Medium (R$100-500)", "Large (R$500-1000)", "Huge (>R$1000)"],
            datasets: [
              {
                data: [45, 30, 15, 10],
                backgroundColor: [
                  "rgba(59, 130, 246, 0.7)",
                  "rgba(16, 185, 129, 0.7)",
                  "rgba(249, 115, 22, 0.7)",
                  "rgba(239, 68, 68, 0.7)",
                ],
                borderColor: ["rgb(59, 130, 246)", "rgb(16, 185, 129)", "rgb(249, 115, 22)", "rgb(239, 68, 68)"],
                borderWidth: 1,
              },
            ],
          },
          hourlyDistribution: {
            labels: Array.from({ length: 24 }, (_, i) => `${i}:00`),
            datasets: [
              {
                label: "Donations by Hour",
                data: generateRandomData(24, 5000, 25000),
                backgroundColor: "rgba(59, 130, 246, 0.7)",
                borderColor: "rgb(59, 130, 246)",
                borderWidth: 1,
              },
            ],
          },
        }
      } else if (type === "players") {
        sampleData = {
          totalPlayers: 25000,
          activePlayers: 2125,
          newPlayers: 350,
          playerTrend: 8.3,
          retentionRate: 68,
          playersChart: {
            labels: dateLabels,
            datasets: [
              {
                label: "Active Players",
                data: generateRandomData(dateLabels.length, 1500, 2500),
                borderColor: "rgb(16, 185, 129)",
                backgroundColor: "rgba(16, 185, 129, 0.5)",
                tension: 0.3,
              },
              {
                label: "New Players",
                data: generateRandomData(dateLabels.length, 200, 500),
                borderColor: "rgb(249, 115, 22)",
                backgroundColor: "rgba(249, 115, 22, 0.5)",
                tension: 0.3,
              },
            ],
          },
          playerRetention: {
            labels: ["1 Day", "3 Days", "7 Days", "14 Days", "30 Days"],
            datasets: [
              {
                label: "Retention Rate (%)",
                data: [90, 75, 68, 55, 40],
                backgroundColor: "rgba(59, 130, 246, 0.7)",
                borderColor: "rgb(59, 130, 246)",
                borderWidth: 1,
              },
            ],
          },
          playerActivity: {
            labels: Array.from({ length: 24 }, (_, i) => `${i}:00`),
            datasets: [
              {
                label: "Players by Hour",
                data: generateRandomData(24, 500, 2500),
                backgroundColor: "rgba(16, 185, 129, 0.7)",
                borderColor: "rgb(16, 185, 129)",
                borderWidth: 1,
              },
            ],
          },
        }
      } else if (type === "performance") {
        sampleData = {
          averageServerUptime: 99.8,
          averageResponseTime: 120,
          errorRate: 0.2,
          performanceTrend: -5.2,
          responseTimeChart: {
            labels: dateLabels,
            datasets: [
              {
                label: "Response Time (ms)",
                data: generateRandomData(dateLabels.length, 100, 150),
                borderColor: "rgb(59, 130, 246)",
                backgroundColor: "rgba(59, 130, 246, 0.5)",
                tension: 0.3,
              },
            ],
          },
          errorRateChart: {
            labels: dateLabels,
            datasets: [
              {
                label: "Error Rate (%)",
                data: generateRandomData(dateLabels.length, 0.1, 0.5, 1),
                borderColor: "rgb(239, 68, 68)",
                backgroundColor: "rgba(239, 68, 68, 0.5)",
                tension: 0.3,
              },
            ],
          },
          serverLoad: {
            labels: Array.from({ length: 24 }, (_, i) => `${i}:00`),
            datasets: [
              {
                label: "Server Load (%)",
                data: generateRandomData(24, 20, 80),
                backgroundColor: "rgba(249, 115, 22, 0.7)",
                borderColor: "rgb(249, 115, 22)",
                borderWidth: 1,
              },
            ],
          },
        }
      }

      setData(sampleData)
    } catch (error) {
      console.error("Error fetching analytics data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Generate date labels based on time range
  const generateDateLabels = (range: string) => {
    const labels = []
    const today = new Date()
    let days = 7

    switch (range) {
      case "24h":
        return Array.from({ length: 24 }, (_, i) => {
          const d = new Date()
          d.setHours(d.getHours() - 23 + i)
          return `${d.getHours()}:00`
        })
      case "7d":
        days = 7
        break
      case "30d":
        days = 30
        break
      case "90d":
        days = 90
        break
    }

    for (let i = days - 1; i >= 0; i--) {
      const d = new Date()
      d.setDate(d.getDate() - i)
      labels.push(d.toLocaleDateString("en-US", { month: "short", day: "numeric" }))
    }

    return labels
  }

  // Generate random data for charts
  const generateRandomData = (length: number, min: number, max: number, decimals = 0) => {
    return Array.from({ length }, () => {
      const value = min + Math.random() * (max - min)
      return decimals === 0 ? Math.round(value) : Number(value.toFixed(decimals))
    })
  }

  // Chart options
  const lineChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "top" as const,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  }

  const barChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "top" as const,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  }

  const doughnutChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: "right" as const,
      },
    },
  }

  if (isLoading || !data) {
    return (
      <div className="flex justify-center py-12">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
          <p className="text-gray-500">Loading analytics data...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="flex gap-2">
          <Select value={gameFilter} onValueChange={setGameFilter}>
            <SelectTrigger className="w-[180px]">
              <span className="truncate">{gameOptions.find((g) => g.id === gameFilter)?.name || "All Games"}</span>
            </SelectTrigger>
            <SelectContent>
              {gameOptions.map((game) => (
                <SelectItem key={game.id} value={game.id}>
                  {game.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[140px]">
              <span className="truncate">
                {timeRange === "24h"
                  ? "Last 24 Hours"
                  : timeRange === "7d"
                    ? "Last 7 Days"
                    : timeRange === "30d"
                      ? "Last 30 Days"
                      : "Last 90 Days"}
              </span>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">Last 24 Hours</SelectItem>
              <SelectItem value="7d">Last 7 Days</SelectItem>
              <SelectItem value="30d">Last 30 Days</SelectItem>
              <SelectItem value="90d">Last 90 Days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {type === "overview" && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Donations</p>
                    <h3 className="text-2xl font-bold mt-1">R$ {formatNumber(data.totalDonations)}</h3>
                  </div>
                  <div className="bg-blue-100 p-2 rounded-full text-blue-600 dark:bg-blue-900 dark:text-blue-200">
                    <DollarSign className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm">
                  {data.donationTrend > 0 ? (
                    <>
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-green-500">{data.donationTrend}% increase</span>
                    </>
                  ) : (
                    <>
                      <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                      <span className="text-red-500">{Math.abs(data.donationTrend)}% decrease</span>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Players</p>
                    <h3 className="text-2xl font-bold mt-1">{formatNumber(data.totalPlayers)}</h3>
                  </div>
                  <div className="bg-green-100 p-2 rounded-full text-green-600 dark:bg-green-900 dark:text-green-200">
                    <Users className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm">
                  {data.playerTrend > 0 ? (
                    <>
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-green-500">{data.playerTrend}% increase</span>
                    </>
                  ) : (
                    <>
                      <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                      <span className="text-red-500">{Math.abs(data.playerTrend)}% decrease</span>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Active Players</p>
                    <h3 className="text-2xl font-bold mt-1">{formatNumber(data.activePlayers)}</h3>
                  </div>
                  <div className="bg-orange-100 p-2 rounded-full text-orange-600 dark:bg-orange-900 dark:text-orange-200">
                    <Activity className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-sm text-gray-500">
                  {Math.round((data.activePlayers / data.totalPlayers) * 100)}% of total players
                </div>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Avg. Donation</p>
                    <h3 className="text-2xl font-bold mt-1">R$ {formatNumber(data.averageDonation)}</h3>
                  </div>
                  <div className="bg-purple-100 p-2 rounded-full text-purple-600 dark:bg-purple-900 dark:text-purple-200">
                    <DollarSign className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-sm text-gray-500">Per active player</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Donations Over Time</CardTitle>
                <CardDescription>Total donations received per day</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <Line options={lineChartOptions} data={data.donationsChart} />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Active Players</CardTitle>
                <CardDescription>Number of active players per day</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <Line options={lineChartOptions} data={data.playersChart} />
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Donation Distribution by Game</CardTitle>
                <CardDescription>Percentage of donations received by each game</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <div className="h-80 w-full max-w-md">
                  <Doughnut options={doughnutChartOptions} data={data.gameDistribution} />
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {type === "donations" && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Donations</p>
                    <h3 className="text-2xl font-bold mt-1">R$ {formatNumber(data.totalDonations)}</h3>
                  </div>
                  <div className="bg-blue-100 p-2 rounded-full text-blue-600 dark:bg-blue-900 dark:text-blue-200">
                    <DollarSign className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm">
                  {data.donationTrend > 0 ? (
                    <>
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-green-500">{data.donationTrend}% increase</span>
                    </>
                  ) : (
                    <>
                      <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                      <span className="text-red-500">{Math.abs(data.donationTrend)}% decrease</span>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Average Donation</p>
                    <h3 className="text-2xl font-bold mt-1">R$ {formatNumber(data.averageDonation)}</h3>
                  </div>
                  <div className="bg-green-100 p-2 rounded-full text-green-600 dark:bg-green-900 dark:text-green-200">
                    <DollarSign className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-sm text-gray-500">Per transaction</div>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Largest Donation</p>
                    <h3 className="text-2xl font-bold mt-1">R$ {formatNumber(data.largestDonation)}</h3>
                  </div>
                  <div className="bg-purple-100 p-2 rounded-full text-purple-600 dark:bg-purple-900 dark:text-purple-200">
                    <DollarSign className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-sm text-gray-500">Single transaction</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Donations Over Time</CardTitle>
                <CardDescription>Total donations received per day</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <Line options={lineChartOptions} data={data.donationsChart} />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Donation Size Distribution</CardTitle>
                <CardDescription>Breakdown of donations by amount</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <div className="h-80 w-full max-w-md">
                  <Doughnut options={doughnutChartOptions} data={data.donationSizeDistribution} />
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Donations by Hour</CardTitle>
                <CardDescription>Distribution of donations throughout the day</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <Bar options={barChartOptions} data={data.hourlyDistribution} />
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {type === "players" && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Players</p>
                    <h3 className="text-2xl font-bold mt-1">{formatNumber(data.totalPlayers)}</h3>
                  </div>
                  <div className="bg-blue-100 p-2 rounded-full text-blue-600 dark:bg-blue-900 dark:text-blue-200">
                    <Users className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm">
                  {data.playerTrend > 0 ? (
                    <>
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-green-500">{data.playerTrend}% increase</span>
                    </>
                  ) : (
                    <>
                      <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                      <span className="text-red-500">{Math.abs(data.playerTrend)}% decrease</span>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Active Players</p>
                    <h3 className="text-2xl font-bold mt-1">{formatNumber(data.activePlayers)}</h3>
                  </div>
                  <div className="bg-green-100 p-2 rounded-full text-green-600 dark:bg-green-900 dark:text-green-200">
                    <Activity className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-sm text-gray-500">
                  {Math.round((data.activePlayers / data.totalPlayers) * 100)}% of total players
                </div>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">New Players</p>
                    <h3 className="text-2xl font-bold mt-1">{formatNumber(data.newPlayers)}</h3>
                  </div>
                  <div className="bg-orange-100 p-2 rounded-full text-orange-600 dark:bg-orange-900 dark:text-orange-200">
                    <Users className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-sm text-gray-500">
                  In the last{" "}
                  {timeRange === "24h"
                    ? "24 hours"
                    : timeRange === "7d"
                      ? "7 days"
                      : timeRange === "30d"
                        ? "30 days"
                        : "90 days"}
                </div>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Retention Rate</p>
                    <h3 className="text-2xl font-bold mt-1">{data.retentionRate}%</h3>
                  </div>
                  <div className="bg-purple-100 p-2 rounded-full text-purple-600 dark:bg-purple-900 dark:text-purple-200">
                    <Users className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-sm text-gray-500">7-day retention</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Player Activity</CardTitle>
                <CardDescription>Active and new players over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <Line options={lineChartOptions} data={data.playersChart} />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Player Retention</CardTitle>
                <CardDescription>Percentage of players who return after their first visit</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <Bar options={barChartOptions} data={data.playerRetention} />
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Player Activity by Hour</CardTitle>
                <CardDescription>Distribution of player activity throughout the day</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <Bar options={barChartOptions} data={data.playerActivity} />
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {type === "performance" && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Server Uptime</p>
                    <h3 className="text-2xl font-bold mt-1">{data.averageServerUptime}%</h3>
                  </div>
                  <div className="bg-blue-100 p-2 rounded-full text-blue-600 dark:bg-blue-900 dark:text-blue-200">
                    <Activity className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-sm text-gray-500">Last 30 days</div>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Response Time</p>
                    <h3 className="text-2xl font-bold mt-1">{data.averageResponseTime} ms</h3>
                  </div>
                  <div className="bg-green-100 p-2 rounded-full text-green-600 dark:bg-green-900 dark:text-green-200">
                    <Activity className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 flex items-center text-sm">
                  {data.performanceTrend < 0 ? (
                    <>
                      <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      <span className="text-green-500">{Math.abs(data.performanceTrend)}% faster</span>
                    </>
                  ) : (
                    <>
                      <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                      <span className="text-red-500">{data.performanceTrend}% slower</span>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="hover-lift">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Error Rate</p>
                    <h3 className="text-2xl font-bold mt-1">{data.errorRate}%</h3>
                  </div>
                  <div className="bg-red-100 p-2 rounded-full text-red-600 dark:bg-red-900 dark:text-red-200">
                    <Activity className="h-5 w-5" />
                  </div>
                </div>
                <div className="mt-2 text-sm text-gray-500">API requests</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Response Time</CardTitle>
                <CardDescription>Average API response time in milliseconds</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <Line options={lineChartOptions} data={data.responseTimeChart} />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Error Rate</CardTitle>
                <CardDescription>Percentage of failed API requests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <Line options={lineChartOptions} data={data.errorRateChart} />
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Server Load</CardTitle>
                <CardDescription>Server load percentage throughout the day</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-80">
                  <Bar options={barChartOptions} data={data.serverLoad} />
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  )
}
