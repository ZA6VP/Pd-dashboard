"use client"

import { useState, useEffect } from "react"

interface LoadingScreenProps {
  message?: string
}

export function LoadingScreen({ message = "Loading" }: LoadingScreenProps) {
  const [dots, setDots] = useState("")

  // Animate the dots
  useEffect(() => {
    const interval = setInterval(() => {
      setDots((prev) => {
        if (prev.length >= 3) return ""
        return prev + "."
      })
    }, 500)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-blue-900 to-indigo-900 z-50">
      <div className="relative w-32 h-32 mb-8">
        <div className="absolute inset-0 rounded-full bg-white opacity-20 animate-ping"></div>
        <div className="absolute inset-2 rounded-full bg-white opacity-30 animate-pulse"></div>
        <div
          className="absolute inset-4 rounded-full bg-white opacity-40 animate-pulse"
          style={{ animationDelay: "200ms" }}
        ></div>
        <div
          className="absolute inset-6 rounded-full bg-white opacity-50 animate-pulse"
          style={{ animationDelay: "400ms" }}
        ></div>
        <div
          className="absolute inset-8 rounded-full bg-white opacity-60 animate-pulse"
          style={{ animationDelay: "600ms" }}
        ></div>
        <div
          className="absolute inset-10 rounded-full bg-white opacity-70 animate-pulse"
          style={{ animationDelay: "800ms" }}
        ></div>
      </div>

      <h2 className="text-2xl font-bold text-white mb-2">
        {message}
        {dots}
      </h2>
      <p className="text-blue-200 text-center max-w-md px-4">
        Preparing your dashboard experience. This may take a few moments.
      </p>
    </div>
  )
}
