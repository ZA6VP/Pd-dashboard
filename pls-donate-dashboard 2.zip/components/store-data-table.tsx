"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, ChevronDown, ChevronUp, RefreshCw } from "lucide-react"

interface StoreDataTableProps {
  storeId: string
  placeId: number
  initialData?: any
}

export function StoreDataTable({ storeId, placeId, initialData }: StoreDataTableProps) {
  const [data, setData] = useState<any>(initialData || {})
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})
  const [filter, setFilter] = useState("")
  const [isLoading, setIsLoading] = useState(!initialData)

  useEffect(() => {
    if (!initialData) {
      fetchStoreData()
    }
  }, [storeId, placeId, initialData])

  const fetchStoreData = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/games/${placeId}/stores/${storeId}`)
      if (response.ok) {
        const storeData = await response.json()
        setData(storeData)
      } else {
        console.error("Failed to fetch store data")
      }
    } catch (error) {
      console.error("Error fetching store data:", error)
    } finally {
      setIsLoading(false)
    }
  }

  // Convert the data to a flat structure for display
  const flattenObject = (obj: any, prefix = "") => {
    return Object.keys(obj).reduce(
      (acc, key) => {
        const pre = prefix.length ? `${prefix}.` : ""
        if (typeof obj[key] === "object" && obj[key] !== null && !Array.isArray(obj[key])) {
          Object.assign(acc, flattenObject(obj[key], `${pre}${key}`))
        } else {
          acc[`${pre}${key}`] = obj[key]
        }
        return acc
      },
      {} as Record<string, any>,
    )
  }

  const flatData = flattenObject(data)

  // Filter the data based on the search input
  const filteredData = Object.entries(flatData).filter(([key]) => key.toLowerCase().includes(filter.toLowerCase()))

  // Toggle expanded state for arrays and objects
  const toggleExpanded = (key: string) => {
    setExpanded((prev) => ({
      ...prev,
      [key]: !prev[key],
    }))
  }

  // Render a value based on its type
  const renderValue = (key: string, value: any) => {
    if (value === null) return <span className="text-gray-400">null</span>

    if (Array.isArray(value)) {
      return (
        <div>
          <Button variant="ghost" size="sm" className="h-6 px-1" onClick={() => toggleExpanded(key)}>
            {expanded[key] ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            Array ({value.length})
          </Button>

          {expanded[key] && (
            <div className="pl-4 mt-1 border-l-2 border-gray-200">
              {value.map((item, index) => (
                <div key={index} className="py-1">
                  <span className="text-gray-500">{index}: </span>
                  {typeof item === "object" && item !== null ? JSON.stringify(item) : String(item)}
                </div>
              ))}
            </div>
          )}
        </div>
      )
    }

    if (typeof value === "object") {
      return (
        <div>
          <Button variant="ghost" size="sm" className="h-6 px-1" onClick={() => toggleExpanded(key)}>
            {expanded[key] ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            Object ({Object.keys(value).length})
          </Button>

          {expanded[key] && (
            <div className="pl-4 mt-1 border-l-2 border-gray-200">
              {Object.entries(value).map(([k, v]) => (
                <div key={k} className="py-1">
                  <span className="text-gray-500">{k}: </span>
                  {typeof v === "object" && v !== null ? JSON.stringify(v) : String(v)}
                </div>
              ))}
            </div>
          )}
        </div>
      )
    }

    return String(value)
  }

  if (isLoading) {
    return <div className="text-center py-8">Loading store data...</div>
  }

  if (Object.keys(data).length === 0) {
    return <div className="text-gray-500">No data available for this store</div>
  }

  return (
    <div>
      <div className="flex mb-4 gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Filter keys..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="pl-8"
          />
        </div>
        <Button variant="outline" size="icon" onClick={fetchStoreData} title="Refresh data">
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      <div className="border rounded-md">
        <table className="w-full">
          <thead>
            <tr className="border-b bg-gray-50">
              <th className="px-4 py-2 text-left font-medium text-gray-500">Key</th>
              <th className="px-4 py-2 text-left font-medium text-gray-500">Value</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.length > 0 ? (
              filteredData.map(([key, value]) => (
                <tr key={key} className="border-b last:border-0">
                  <td className="px-4 py-2 font-medium">{key}</td>
                  <td className="px-4 py-2">{renderValue(key, value)}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={2} className="px-4 py-4 text-center text-gray-500">
                  No results found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
