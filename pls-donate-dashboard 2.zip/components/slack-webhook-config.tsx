"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, Save, Loader2, Send } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface SlackWebhookConfig {
  url: string
  username: string
  iconUrl: string
  enabled: boolean
}

export function SlackWebhookConfig() {
  const [config, setConfig] = useState<SlackWebhookConfig>({
    url: "",
    username: "",
    iconUrl: "",
    enabled: false,
  })
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [isTesting, setIsTesting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  // Load configuration on component mount
  useEffect(() => {
    fetchConfig()
  }, [])

  // Fetch configuration from API
  const fetchConfig = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/webhooks/slack/config")

      if (!response.ok) {
        throw new Error("Failed to fetch Slack webhook configuration")
      }

      const data = await response.json()
      setConfig(data)
    } catch (error) {
      setError("Failed to load Slack webhook configuration")
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  // Save configuration
  const saveConfig = async () => {
    setIsSaving(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/webhooks/slack/config", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(config),
      })

      if (!response.ok) {
        throw new Error("Failed to save Slack webhook configuration")
      }

      setSuccess("Slack webhook configuration saved successfully")

      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccess(null)
      }, 3000)
    } catch (error) {
      setError("Failed to save Slack webhook configuration")
      console.error(error)
    } finally {
      setIsSaving(false)
    }
  }

  // Test webhook
  const testWebhook = async () => {
    setIsTesting(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/webhooks/slack/test", {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Failed to send test notification")
      }

      setSuccess("Test notification sent successfully")

      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccess(null)
      }, 3000)
    } catch (error) {
      setError("Failed to send test notification")
      console.error(error)
    } finally {
      setIsTesting(false)
    }
  }

  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setConfig((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Handle toggle change
  const handleToggleChange = (checked: boolean) => {
    setConfig((prev) => ({
      ...prev,
      enabled: checked,
    }))
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
          <p className="text-gray-500">Loading Slack webhook configuration...</p>
        </div>
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Slack Webhook Configuration</CardTitle>
        <CardDescription>Configure Slack notifications for important events</CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive" className="animate-slide-down">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="bg-green-50 text-green-800 border-green-200 animate-slide-down">
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        <div className="flex items-center justify-between">
          <Label htmlFor="enabled" className="font-medium">
            Enable Slack Notifications
          </Label>
          <Switch id="enabled" checked={config.enabled} onCheckedChange={handleToggleChange} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="url" className="font-medium">
            Webhook URL
          </Label>
          <Input
            id="url"
            name="url"
            value={config.url}
            onChange={handleInputChange}
            placeholder="https://hooks.slack.com/services/..."
            disabled={!config.enabled}
          />
          <p className="text-sm text-gray-500">Create a webhook URL in your Slack workspace settings</p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="username" className="font-medium">
            Bot Username
          </Label>
          <Input
            id="username"
            name="username"
            value={config.username}
            onChange={handleInputChange}
            placeholder="PLS DONATE Dashboard"
            disabled={!config.enabled}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="iconUrl" className="font-medium">
            Bot Icon URL
          </Label>
          <Input
            id="iconUrl"
            name="iconUrl"
            value={config.iconUrl}
            onChange={handleInputChange}
            placeholder="https://example.com/icon.png"
            disabled={!config.enabled}
          />
        </div>
      </CardContent>

      <CardFooter className="flex justify-between">
        <Button onClick={saveConfig} disabled={isSaving || !config.enabled}>
          {isSaving ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Save Configuration
            </>
          )}
        </Button>

        <Button variant="outline" onClick={testWebhook} disabled={isTesting || !config.enabled || !config.url}>
          {isTesting ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Testing...
            </>
          ) : (
            <>
              <Send className="h-4 w-4 mr-2" />
              Test Webhook
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
