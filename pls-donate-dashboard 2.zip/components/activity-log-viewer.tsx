"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertCircle, RefreshCw, Loader2, Search, User, Calendar } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import type { Activity, ActivityType } from "@/lib/activity-logger"

export function ActivityLogViewer() {
  const [activities, setActivities] = useState<Activity[]>([])
  const [filteredActivities, setFilteredActivities] = useState<Activity[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState<ActivityType | "all">("all")
  const [selectedUser, setSelectedUser] = useState<string | "all">("all")
  const [users, setUsers] = useState<string[]>([])
  const [activityTypes, setActivityTypes] = useState<ActivityType[]>([])

  // Load activity logs on component mount
  useEffect(() => {
    fetchActivityLogs()
  }, [])

  // Filter activities when search query, type, or user changes
  useEffect(() => {
    filterActivities()
  }, [searchQuery, selectedType, selectedUser, activities])

  // Filter activities based on search query, type, and user
  const filterActivities = () => {
    let filtered = [...activities]

    // Filter by type
    if (selectedType !== "all") {
      filtered = filtered.filter((activity) => activity.type === selectedType)
    }

    // Filter by user
    if (selectedUser !== "all") {
      filtered = filtered.filter((activity) => activity.username === selectedUser)
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (activity) =>
          activity.username.toLowerCase().includes(query) ||
          activity.type.toLowerCase().includes(query) ||
          JSON.stringify(activity.details).toLowerCase().includes(query),
      )
    }

    setFilteredActivities(filtered)
  }

  // Fetch activity logs from API
  const fetchActivityLogs = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/system/activity")

      if (!response.ok) {
        throw new Error("Failed to fetch activity logs")
      }

      const data = await response.json()
      setActivities(data)

      // Extract unique users and activity types
      const uniqueUsers = [...new Set(data.map((activity: Activity) => activity.username))]
      const uniqueTypes = [...new Set(data.map((activity: Activity) => activity.type))]

      setUsers(uniqueUsers)
      setActivityTypes(uniqueTypes as ActivityType[])
    } catch (error) {
      setError("Failed to load activity logs")
      console.error(error)
    } finally {
      setIsLoading(false)
      setIsRefreshing(false)
    }
  }

  // Refresh activity logs
  const refreshLogs = async () => {
    setIsRefreshing(true)
    await fetchActivityLogs()
  }

  // Format date
  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleString()
    } catch (error) {
      return dateString
    }
  }

  // Format activity type for display
  const formatActivityType = (type: ActivityType) => {
    return type
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
          <p className="text-gray-500">Loading activity logs...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive" className="animate-slide-down">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h3 className="text-lg font-medium">User Activity Logs</h3>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={refreshLogs} disabled={isRefreshing}>
            <RefreshCw className={`h-4 w-4 mr-1 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
          <Input
            placeholder="Search activity logs..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex gap-2">
          <Select value={selectedType} onValueChange={(value) => setSelectedType(value as ActivityType | "all")}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              {activityTypes.map((type) => (
                <SelectItem key={type} value={type}>
                  {formatActivityType(type)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedUser} onValueChange={setSelectedUser}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by user" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Users</SelectItem>
              {users.map((user) => (
                <SelectItem key={user} value={user}>
                  {user}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {filteredActivities.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          {activities.length === 0 ? "No activity logs found" : "No activities match your search"}
        </div>
      ) : (
        <div className="border rounded-md overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 dark:bg-gray-800">
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Timestamp
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  User
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Activity
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Details
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {filteredActivities.map((activity) => (
                <tr key={activity.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                      {formatDate(activity.timestamp)}
                    </div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm">
                    <div className="flex items-center">
                      <User className="h-4 w-4 mr-2 text-gray-400" />
                      <span className="font-medium">{activity.username}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm">
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {formatActivityType(activity.type)}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-500 dark:text-gray-400 max-w-xs truncate">
                    {Object.entries(activity.details).map(([key, value]) => (
                      <span key={key} className="mr-2">
                        <span className="font-medium">{key}:</span> {JSON.stringify(value)}
                      </span>
                    ))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
