"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, Bell, Check, Trash2 } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"

// Notification types
type NotificationType =
  | "system"
  | "security"
  | "user"
  | "game"
  | "webhook"
  | "backup"
  | "error"
  | "performance"
  | "maintenance"
  | "donation"
  | "ban"

// Notification priority
type NotificationPriority = "low" | "medium" | "high" | "critical"

// Notification interface
interface Notification {
  id: string
  timestamp: string
  type: NotificationType
  priority: NotificationPriority
  title: string
  message: string
  details?: Record<string, any>
  read: boolean
  username: string
  batchKey?: string
  batchCount?: number
}

export default function NotificationDashboard() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("all")

  // Fetch notifications
  const fetchNotifications = async () => {
    try {
      setLoading(true)
      setError(null)

      const includeRead = activeTab === "all"
      const response = await fetch(`/api/notifications?includeRead=${includeRead}`)

      if (!response.ok) {
        throw new Error("Failed to fetch notifications")
      }

      const data = await response.json()
      setNotifications(data.notifications || [])
    } catch (error) {
      console.error("Error fetching notifications:", error)
      setError("Failed to load notifications. Please try again later.")
    } finally {
      setLoading(false)
    }
  }

  // Mark notification as read
  const markAsRead = async (id: string) => {
    try {
      const response = await fetch(`/api/notifications/${id}/read`, {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Failed to mark notification as read")
      }

      // Update local state
      setNotifications((prev) =>
        prev.map((notification) => (notification.id === id ? { ...notification, read: true } : notification)),
      )
    } catch (error) {
      console.error("Error marking notification as read:", error)
    }
  }

  // Delete notification
  const deleteNotification = async (id: string) => {
    try {
      const response = await fetch(`/api/notifications/${id}`, {
        method: "DELETE",
      })

      if (!response.ok) {
        throw new Error("Failed to delete notification")
      }

      // Update local state
      setNotifications((prev) => prev.filter((notification) => notification.id !== id))
    } catch (error) {
      console.error("Error deleting notification:", error)
    }
  }

  // Mark all as read
  const markAllAsRead = async () => {
    try {
      const response = await fetch("/api/notifications/read-all", {
        method: "POST",
      })

      if (!response.ok) {
        throw new Error("Failed to mark all notifications as read")
      }

      // Update local state
      setNotifications((prev) => prev.map((notification) => ({ ...notification, read: true })))
    } catch (error) {
      console.error("Error marking all notifications as read:", error)
    }
  }

  // Get priority color
  const getPriorityColor = (priority: NotificationPriority) => {
    switch (priority) {
      case "low":
        return "bg-blue-100 text-blue-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "high":
        return "bg-orange-100 text-orange-800"
      case "critical":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Get type color
  const getTypeColor = (type: NotificationType) => {
    switch (type) {
      case "system":
        return "bg-purple-100 text-purple-800"
      case "security":
        return "bg-red-100 text-red-800"
      case "user":
        return "bg-blue-100 text-blue-800"
      case "game":
        return "bg-green-100 text-green-800"
      case "webhook":
        return "bg-indigo-100 text-indigo-800"
      case "backup":
        return "bg-teal-100 text-teal-800"
      case "error":
        return "bg-red-100 text-red-800"
      case "performance":
        return "bg-orange-100 text-orange-800"
      case "maintenance":
        return "bg-gray-100 text-gray-800"
      case "donation":
        return "bg-green-100 text-green-800"
      case "ban":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  // Format date
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString)
      return date.toLocaleString()
    } catch (error) {
      return dateString
    }
  }

  // Filter notifications based on active tab
  const filteredNotifications = notifications.filter((notification) => {
    if (activeTab === "all") {
      return true
    } else if (activeTab === "unread") {
      return !notification.read
    } else if (activeTab === "high") {
      return notification.priority === "high" || notification.priority === "critical"
    }
    return true
  })

  // Effect to fetch notifications on mount and tab change
  useEffect(() => {
    fetchNotifications()
  }, [activeTab])

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bell className="mr-2 h-5 w-5" />
          Notifications
        </CardTitle>
        <CardDescription>View and manage your notifications</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
          <div className="flex items-center justify-between">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="unread">Unread</TabsTrigger>
              <TabsTrigger value="high">High Priority</TabsTrigger>
            </TabsList>
            <Button variant="outline" size="sm" onClick={markAllAsRead}>
              <Check className="mr-2 h-4 w-4" />
              Mark All Read
            </Button>
          </div>

          <TabsContent value="all" className="mt-4">
            {renderNotificationList()}
          </TabsContent>
          <TabsContent value="unread" className="mt-4">
            {renderNotificationList()}
          </TabsContent>
          <TabsContent value="high" className="mt-4">
            {renderNotificationList()}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )

  // Helper function to render notification list
  function renderNotificationList() {
    if (loading) {
      return (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="rounded-lg border p-4">
              <div className="flex items-center justify-between">
                <Skeleton className="h-6 w-48" />
                <div className="flex space-x-2">
                  <Skeleton className="h-6 w-16" />
                  <Skeleton className="h-6 w-16" />
                </div>
              </div>
              <Skeleton className="mt-2 h-4 w-full" />
              <Skeleton className="mt-1 h-4 w-3/4" />
            </div>
          ))}
        </div>
      )
    }

    if (error) {
      return (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )
    }

    if (filteredNotifications.length === 0) {
      return (
        <div className="rounded-lg border border-dashed p-8 text-center">
          <Bell className="mx-auto h-8 w-8 text-gray-400" />
          <p className="mt-2 text-sm text-gray-500">No notifications found</p>
        </div>
      )
    }

    return (
      <div className="space-y-4">
        {filteredNotifications.map((notification) => (
          <div
            key={notification.id}
            className={`rounded-lg border p-4 ${notification.read ? "bg-gray-50" : "bg-white"}`}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-medium">{notification.title}</h3>
              <div className="flex space-x-2">
                <Badge className={getTypeColor(notification.type)}>{notification.type}</Badge>
                <Badge className={getPriorityColor(notification.priority)}>{notification.priority}</Badge>
              </div>
            </div>
            <p className="mt-2 text-sm text-gray-600">{notification.message}</p>
            <div className="mt-2 flex items-center justify-between text-xs text-gray-500">
              <span>{formatDate(notification.timestamp)}</span>
              <div className="flex space-x-2">
                {!notification.read && (
                  <Button variant="ghost" size="sm" onClick={() => markAsRead(notification.id)}>
                    <Check className="mr-1 h-3 w-3" />
                    Mark Read
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={() => deleteNotification(notification.id)}>
                  <Trash2 className="mr-1 h-3 w-3" />
                  Delete
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    )
  }
}
