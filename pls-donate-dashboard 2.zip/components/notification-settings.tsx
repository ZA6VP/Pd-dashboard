"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, Bell, Save, Loader2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import type { NotificationSettings, NotificationType, NotificationPriority } from "@/lib/notification-system"

export function NotificationSettingsComponent({ username }: { username: string }) {
  const [settings, setSettings] = useState<NotificationSettings | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  // Load notification settings on component mount
  useEffect(() => {
    fetchNotificationSettings()
  }, [])

  // Fetch notification settings from API
  const fetchNotificationSettings = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch(`/api/users/${username}/notifications/settings`)

      if (!response.ok) {
        throw new Error("Failed to fetch notification settings")
      }

      const data = await response.json()
      setSettings(data)
    } catch (error) {
      setError("Failed to load notification settings")
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  // Save notification settings
  const saveSettings = async () => {
    if (!settings) return

    setIsSaving(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch(`/api/users/${username}/notifications/settings`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(settings),
      })

      if (!response.ok) {
        throw new Error("Failed to save notification settings")
      }

      setSuccess("Notification settings saved successfully")

      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccess(null)
      }, 3000)
    } catch (error) {
      setError("Failed to save notification settings")
      console.error(error)
    } finally {
      setIsSaving(false)
    }
  }

  // Handle toggle change
  const handleToggleChange = (key: keyof NotificationSettings, value: boolean) => {
    if (!settings) return

    setSettings({
      ...settings,
      [key]: value,
    })
  }

  // Handle notification type toggle change
  const handleTypeToggleChange = (type: NotificationType, value: boolean) => {
    if (!settings) return

    setSettings({
      ...settings,
      types: {
        ...settings.types,
        [type]: value,
      },
    })
  }

  // Handle priority change
  const handlePriorityChange = (value: NotificationPriority) => {
    if (!settings) return

    setSettings({
      ...settings,
      minPriority: value,
    })
  }

  // Format notification type for display
  const formatNotificationType = (type: NotificationType) => {
    return type
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
          <p className="text-gray-500">Loading notification settings...</p>
        </div>
      </div>
    )
  }

  if (!settings) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>Failed to load notification settings</AlertDescription>
      </Alert>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bell className="h-5 w-5 mr-2" />
          Notification Settings
        </CardTitle>
        <CardDescription>Customize how you receive notifications</CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {error && (
          <Alert variant="destructive" className="animate-slide-down">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="bg-green-50 text-green-800 border-green-200 animate-slide-down">
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="notifications-enabled" className="font-medium">
              Enable Notifications
            </Label>
            <Switch
              id="notifications-enabled"
              checked={settings.enabled}
              onCheckedChange={(value) => handleToggleChange("enabled", value)}
            />
          </div>

          <div className="space-y-2">
            <Label className="font-medium">Minimum Priority</Label>
            <Select
              value={settings.minPriority}
              onValueChange={(value) => handlePriorityChange(value as NotificationPriority)}
              disabled={!settings.enabled}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select minimum priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-gray-500">You will only receive notifications with this priority or higher</p>
          </div>

          <div className="space-y-2">
            <Label className="font-medium">Notification Methods</Label>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="email-notifications" className="text-sm">
                  Email Notifications
                </Label>
                <Switch
                  id="email-notifications"
                  checked={settings.emailNotifications}
                  onCheckedChange={(value) => handleToggleChange("emailNotifications", value)}
                  disabled={!settings.enabled}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="push-notifications" className="text-sm">
                  Push Notifications
                </Label>
                <Switch
                  id="push-notifications"
                  checked={settings.pushNotifications}
                  onCheckedChange={(value) => handleToggleChange("pushNotifications", value)}
                  disabled={!settings.enabled}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="desktop-notifications" className="text-sm">
                  Desktop Notifications
                </Label>
                <Switch
                  id="desktop-notifications"
                  checked={settings.desktopNotifications}
                  onCheckedChange={(value) => handleToggleChange("desktopNotifications", value)}
                  disabled={!settings.enabled}
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="font-medium">Notification Types</Label>
            <div className="space-y-2">
              {Object.entries(settings.types).map(([type, enabled]) => (
                <div key={type} className="flex items-center justify-between">
                  <Label htmlFor={`type-${type}`} className="text-sm">
                    {formatNotificationType(type as NotificationType)}
                  </Label>
                  <Switch
                    id={`type-${type}`}
                    checked={enabled}
                    onCheckedChange={(value) => handleTypeToggleChange(type as NotificationType, value)}
                    disabled={!settings.enabled}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>

      <CardFooter>
        <Button onClick={saveSettings} disabled={isSaving}>
          {isSaving ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Save Settings
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
