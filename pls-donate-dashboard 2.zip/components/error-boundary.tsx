"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle } from "lucide-react"

interface ErrorBoundaryProps {
  children: React.ReactNode
  fallback?: React.ReactNode
}

export function ErrorBoundary({ children, fallback }: ErrorBoundaryProps) {
  const [hasError, setHasError] = useState(false)
  const [error, setError] = useState<Error | null>(null)
  const [errorInfo, setErrorInfo] = useState<React.ErrorInfo | null>(null)

  useEffect(() => {
    // Add global error handler for uncaught errors
    const errorHandler = (event: ErrorEvent) => {
      console.error("Uncaught error:", event.error)
      setHasError(true)
      setError(event.error)

      // Report error to API
      reportErrorToAPI(event.error, {
        type: "uncaught",
        location: window.location.href,
        userAgent: navigator.userAgent,
      }).catch(console.error)

      // Prevent default handling
      event.preventDefault()
    }

    // Add global handler for unhandled promise rejections
    const rejectionHandler = (event: PromiseRejectionEvent) => {
      console.error("Unhandled promise rejection:", event.reason)
      setHasError(true)
      setError(event.reason instanceof Error ? event.reason : new Error(String(event.reason)))

      // Report error to API
      reportErrorToAPI(event.reason, {
        type: "unhandledRejection",
        location: window.location.href,
        userAgent: navigator.userAgent,
      }).catch(console.error)

      // Prevent default handling
      event.preventDefault()
    }

    window.addEventListener("error", errorHandler)
    window.addEventListener("unhandledrejection", rejectionHandler)

    return () => {
      window.removeEventListener("error", errorHandler)
      window.removeEventListener("unhandledrejection", rejectionHandler)
    }
  }, [])

  // Function to report errors to our API
  const reportErrorToAPI = async (error: any, context: Record<string, any> = {}) => {
    try {
      const errorData = {
        message: error instanceof Error ? error.message : String(error),
        stack: error instanceof Error ? error.stack : null,
        ...context,
        timestamp: new Date().toISOString(),
        referenceCode: generateErrorReference(),
      }

      await fetch("/api/system/error", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(errorData),
      })
    } catch (reportError) {
      console.error("Failed to report error:", reportError)
    }
  }

  // Generate a reference code for the error
  const generateErrorReference = () => {
    return Math.floor(Math.random() * 10000000000).toString()
  }

  // Reset the error state
  const resetError = () => {
    setHasError(false)
    setError(null)
    setErrorInfo(null)
  }

  // If there's an error, show the fallback UI or our default error UI
  if (hasError) {
    if (fallback) {
      return <>{fallback}</>
    }

    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              <CardTitle>Something went wrong</CardTitle>
            </div>
            <CardDescription>An unexpected error occurred. Our team has been notified.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-md text-sm overflow-auto max-h-[200px]">
              <p className="font-semibold">Error:</p>
              <p className="text-red-600">{error?.message || "Unknown error"}</p>
              {error?.stack && (
                <>
                  <p className="font-semibold mt-2">Stack trace:</p>
                  <pre className="text-xs overflow-auto whitespace-pre-wrap">{error.stack}</pre>
                </>
              )}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => (window.location.href = "/")}>
              Go to Home
            </Button>
            <Button onClick={resetError}>Try Again</Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  // If there's no error, render children normally
  return <>{children}</>
}
