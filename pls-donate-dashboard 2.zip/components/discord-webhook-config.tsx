"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2, Info } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

interface WebhookConfig {
  url: string
  enabled: boolean
  notifications: {
    errors: boolean
    warnings: boolean
    info: boolean
    gameUpdates: boolean
    playerActivity: boolean
    donations: boolean
    bans: boolean
    adminActions: boolean
    systemEvents: boolean
  }
}

export function DiscordWebhookConfig() {
  const [config, setConfig] = useState<WebhookConfig>({
    url: "",
    enabled: false,
    notifications: {
      errors: true,
      warnings: true,
      info: false,
      gameUpdates: true,
      playerActivity: false,
      donations: true,
      bans: true,
      adminActions: true,
      systemEvents: true,
    },
  })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [testing, setTesting] = useState(false)
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null)

  useEffect(() => {
    async function fetchConfig() {
      try {
        const response = await fetch("/api/webhooks/discord/config")
        if (response.ok) {
          const data = await response.json()
          setConfig(data)
        }
      } catch (error) {
        console.error("Failed to fetch Discord webhook config:", error)
        toast({
          title: "Error",
          description: "Failed to load Discord webhook configuration",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    fetchConfig()
  }, [])

  const handleSave = async () => {
    setSaving(true)
    try {
      const response = await fetch("/api/webhooks/discord/config", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(config),
      })

      if (response.ok) {
        toast({
          title: "Success",
          description: "Discord webhook configuration saved successfully",
        })
      } else {
        throw new Error("Failed to save configuration")
      }
    } catch (error) {
      console.error("Failed to save Discord webhook config:", error)
      toast({
        title: "Error",
        description: "Failed to save Discord webhook configuration",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  const handleTest = async () => {
    setTesting(true)
    setTestResult(null)
    try {
      const response = await fetch("/api/webhooks/discord/test", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ url: config.url }),
      })

      const data = await response.json()
      setTestResult({
        success: response.ok,
        message: data.message || (response.ok ? "Test successful!" : "Test failed"),
      })

      if (response.ok) {
        toast({
          title: "Success",
          description: "Discord webhook test successful",
        })
      } else {
        throw new Error(data.message || "Test failed")
      }
    } catch (error) {
      console.error("Discord webhook test failed:", error)
      setTestResult({
        success: false,
        message: error.message || "Test failed",
      })
      toast({
        title: "Error",
        description: "Discord webhook test failed",
        variant: "destructive",
      })
    } finally {
      setTesting(false)
    }
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Discord Webhook Configuration</CardTitle>
          <CardDescription>Loading configuration...</CardDescription>
        </CardHeader>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Discord Webhook Configuration</CardTitle>
        <CardDescription>Configure Discord webhook notifications for your dashboard</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="general">
          <TabsList>
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="help">Help</TabsTrigger>
          </TabsList>
          <TabsContent value="general" className="space-y-4 pt-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="webhook-enabled">Enable Discord Notifications</Label>
                <Switch
                  id="webhook-enabled"
                  checked={config.enabled}
                  onCheckedChange={(checked) => setConfig({ ...config, enabled: checked })}
                />
              </div>
              <p className="text-sm text-muted-foreground">
                When enabled, notifications will be sent to your Discord channel
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="webhook-url">Webhook URL</Label>
              <Input
                id="webhook-url"
                placeholder="https://discord.com/api/webhooks/..."
                value={config.url}
                onChange={(e) => setConfig({ ...config, url: e.target.value })}
              />
              <p className="text-sm text-muted-foreground">
                You can create a webhook URL in your Discord server settings
              </p>
            </div>

            <div className="flex items-center gap-2">
              <Button onClick={handleTest} disabled={!config.url || testing}>
                {testing ? "Testing..." : "Test Webhook"}
              </Button>
            </div>

            {testResult && (
              <Alert variant={testResult.success ? "default" : "destructive"}>
                {testResult.success ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                <AlertTitle>{testResult.success ? "Success" : "Error"}</AlertTitle>
                <AlertDescription>{testResult.message}</AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="notifications" className="space-y-4 pt-4">
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Notification Types</h3>
              <div className="grid gap-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="errors"
                    checked={config.notifications.errors}
                    onCheckedChange={(checked) =>
                      setConfig({
                        ...config,
                        notifications: {
                          ...config.notifications,
                          errors: !!checked,
                        },
                      })
                    }
                  />
                  <Label htmlFor="errors">Errors</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="warnings"
                    checked={config.notifications.warnings}
                    onCheckedChange={(checked) =>
                      setConfig({
                        ...config,
                        notifications: {
                          ...config.notifications,
                          warnings: !!checked,
                        },
                      })
                    }
                  />
                  <Label htmlFor="warnings">Warnings</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="info"
                    checked={config.notifications.info}
                    onCheckedChange={(checked) =>
                      setConfig({
                        ...config,
                        notifications: {
                          ...config.notifications,
                          info: !!checked,
                        },
                      })
                    }
                  />
                  <Label htmlFor="info">Information</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="gameUpdates"
                    checked={config.notifications.gameUpdates}
                    onCheckedChange={(checked) =>
                      setConfig({
                        ...config,
                        notifications: {
                          ...config.notifications,
                          gameUpdates: !!checked,
                        },
                      })
                    }
                  />
                  <Label htmlFor="gameUpdates">Game Updates</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="playerActivity"
                    checked={config.notifications.playerActivity}
                    onCheckedChange={(checked) =>
                      setConfig({
                        ...config,
                        notifications: {
                          ...config.notifications,
                          playerActivity: !!checked,
                        },
                      })
                    }
                  />
                  <Label htmlFor="playerActivity">Player Activity</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="donations"
                    checked={config.notifications.donations}
                    onCheckedChange={(checked) =>
                      setConfig({
                        ...config,
                        notifications: {
                          ...config.notifications,
                          donations: !!checked,
                        },
                      })
                    }
                  />
                  <Label htmlFor="donations">Donations</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="bans"
                    checked={config.notifications.bans}
                    onCheckedChange={(checked) =>
                      setConfig({
                        ...config,
                        notifications: {
                          ...config.notifications,
                          bans: !!checked,
                        },
                      })
                    }
                  />
                  <Label htmlFor="bans">Bans</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="adminActions"
                    checked={config.notifications.adminActions}
                    onCheckedChange={(checked) =>
                      setConfig({
                        ...config,
                        notifications: {
                          ...config.notifications,
                          adminActions: !!checked,
                        },
                      })
                    }
                  />
                  <Label htmlFor="adminActions">Admin Actions</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="systemEvents"
                    checked={config.notifications.systemEvents}
                    onCheckedChange={(checked) =>
                      setConfig({
                        ...config,
                        notifications: {
                          ...config.notifications,
                          systemEvents: !!checked,
                        },
                      })
                    }
                  />
                  <Label htmlFor="systemEvents">System Events</Label>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="help" className="space-y-4 pt-4">
            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>How to set up a Discord webhook</AlertTitle>
              <AlertDescription>
                <ol className="list-decimal pl-5 space-y-2 mt-2">
                  <li>Open your Discord server settings</li>
                  <li>Go to the "Integrations" tab</li>
                  <li>Click on "Webhooks"</li>
                  <li>Click "New Webhook"</li>
                  <li>Give it a name (e.g., "PLS DONATE Dashboard")</li>
                  <li>Choose the channel where notifications should be sent</li>
                  <li>Click "Copy Webhook URL"</li>
                  <li>Paste the URL in the field above</li>
                </ol>
              </AlertDescription>
            </Alert>

            <div className="space-y-2">
              <h3 className="text-lg font-medium">Notification Types</h3>
              <ul className="space-y-2">
                <li>
                  <strong>Errors:</strong> Critical application errors that require attention
                </li>
                <li>
                  <strong>Warnings:</strong> Non-critical issues that might need investigation
                </li>
                <li>
                  <strong>Information:</strong> General system information and updates
                </li>
                <li>
                  <strong>Game Updates:</strong> When games push new data to the dashboard
                </li>
                <li>
                  <strong>Player Activity:</strong> Significant player count changes
                </li>
                <li>
                  <strong>Donations:</strong> Large or notable donations
                </li>
                <li>
                  <strong>Bans:</strong> When players are banned or unbanned
                </li>
                <li>
                  <strong>Admin Actions:</strong> Actions performed by administrators
                </li>
                <li>
                  <strong>System Events:</strong> System maintenance, backups, etc.
                </li>
              </ul>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSave} disabled={saving}>
          {saving ? "Saving..." : "Save Configuration"}
        </Button>
      </CardFooter>
    </Card>
  )
}
