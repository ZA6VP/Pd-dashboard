"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { Loader2, Plus, Trash2 } from "lucide-react"

export function ABTestSettings() {
  const [tests, setTests] = useState([
    {
      id: "1",
      name: "Donation Button Color",
      gameId: "123456789",
      enabled: true,
      variants: [
        { name: "Control", weight: 50 },
        { name: "Blue Button", weight: 25 },
        { name: "Green Button", weight: 25 },
      ],
    },
    {
      id: "2",
      name: "Welcome Message",
      gameId: "987654321",
      enabled: false,
      variants: [
        { name: "Standard", weight: 50 },
        { name: "Friendly", weight: 50 },
      ],
    },
  ])

  const [isLoading, setIsLoading] = useState(false)

  // Sample game options
  const gameOptions = [
    { id: "123456789", name: "PLS DONATE G!" },
    { id: "987654321", name: "PLS DONATE ZAP!" },
  ]

  const handleToggleTest = (id: string) => {
    setTests((prev) => prev.map((test) => (test.id === id ? { ...test, enabled: !test.enabled } : test)))
  }

  const handleSaveChanges = async () => {
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // In a real implementation, you would save the tests to the database
    // const response = await fetch('/api/ab-tests', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ tests })
    // })

    setIsLoading(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Active Tests</h3>
        <Button size="sm">
          <Plus className="w-4 h-4 mr-1" />
          New Test
        </Button>
      </div>

      {tests.map((test) => (
        <Card key={test.id}>
          <CardContent className="p-4">
            <div className="flex flex-col space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-medium">{test.name}</h4>
                  <p className="text-sm text-gray-500">
                    Game: {gameOptions.find((g) => g.id === test.gameId)?.name || test.gameId}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={test.enabled}
                    onCheckedChange={() => handleToggleTest(test.id)}
                    id={`test-${test.id}`}
                  />
                  <Label htmlFor={`test-${test.id}`}>{test.enabled ? "Enabled" : "Disabled"}</Label>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Game</Label>
                <Select defaultValue={test.gameId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a game" />
                  </SelectTrigger>
                  <SelectContent>
                    {gameOptions.map((game) => (
                      <SelectItem key={game.id} value={game.id}>
                        {game.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="mb-2 block">Variants</Label>
                <div className="space-y-2">
                  {test.variants.map((variant, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Input value={variant.name} placeholder="Variant name" className="flex-1" />
                      <Input type="number" value={variant.weight} min="1" max="100" className="w-20" />
                      <Button variant="ghost" size="icon" className="text-gray-500">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  <Button variant="outline" size="sm" className="mt-2">
                    <Plus className="w-4 h-4 mr-1" />
                    Add Variant
                  </Button>
                </div>
              </div>

              <div className="flex justify-end">
                <Button variant="outline" size="sm" className="mr-2">
                  <Trash2 className="w-4 h-4 mr-1" />
                  Delete
                </Button>
                <Button size="sm">Save</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      <div className="flex justify-end">
        <Button onClick={handleSaveChanges} disabled={isLoading}>
          {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
          Save All Changes
        </Button>
      </div>
    </div>
  )
}
