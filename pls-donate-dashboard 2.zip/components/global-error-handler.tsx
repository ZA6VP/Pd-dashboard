"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"

export function GlobalErrorHandler() {
  const router = useRouter()

  useEffect(() => {
    // Function to extract error reference from URL
    const checkForServerError = () => {
      const url = new URL(window.location.href)
      const errorRef = url.searchParams.get("errorRef")

      if (errorRef) {
        // Report the server error
        fetch("/api/system/server-error", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            referenceCode: errorRef,
            message: "Server-side exception detected via URL parameter",
            context: {
              url: window.location.href,
              userAgent: navigator.userAgent,
              timestamp: new Date().toISOString(),
            },
          }),
        }).catch(console.error)

        // Check if this is a specific error code we know about
        fetch("/api/system/specific-error", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            referenceCode: errorRef,
          }),
        }).catch(console.error)

        // Remove the error reference from the URL to prevent repeated reporting
        url.searchParams.delete("errorRef")
        window.history.replaceState({}, "", url.toString())
      }
    }

    // Check for server error on initial load
    checkForServerError()

    // Also check when the route changes
    const handleRouteChange = () => {
      checkForServerError()
    }

    window.addEventListener("popstate", handleRouteChange)

    return () => {
      window.removeEventListener("popstate", handleRouteChange)
    }
  }, [router])

  return null
}
