"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Loader2, Search, User } from "lucide-react"

export function UserSearch() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [user, setUser] = useState<any>(null)

  // Sample user data for demonstration
  const sampleUser = {
    id: 12345,
    username: "ExampleUser",
    displayName: "Example User",
    blurb: "This is my profile description!",
    created: "2015-06-24T18:00:00.000Z",
    isBanned: false,
    lastActivity: "2023-05-15T14:30:00.000Z",
    notes: [
      { author: "ZA6VP", timestamp: "2023-04-10T12:00:00.000Z", text: "User reported for suspicious activity" },
      { author: "Votiue", timestamp: "2023-04-12T15:30:00.000Z", text: "Investigated and found no violations" },
    ],
    punishments: [
      { type: "Warning", reason: "Inappropriate language", expires: "2023-03-15T00:00:00.000Z", author: "q_6nnn" },
    ],
  }

  const handleSearch = () => {
    if (!searchQuery.trim()) return

    setIsLoading(true)
    setUser(null)

    // Simulate API call
    setTimeout(() => {
      setUser(sampleUser)
      setIsLoading(false)
    }, 1000)
  }

  return (
    <div>
      <div className="flex gap-2 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Enter username or user ID"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8"
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
        </div>
        <Button onClick={handleSearch} disabled={isLoading}>
          {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : null}
          Search
        </Button>
      </div>

      {isLoading && (
        <div className="flex justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
        </div>
      )}

      {user && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-1">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center mb-4">
                <div className="w-24 h-24 rounded-full bg-gray-200 flex items-center justify-center mb-2">
                  <User className="h-12 w-12 text-gray-400" />
                </div>
                <h3 className="text-xl font-bold">{user.displayName}</h3>
                <p className="text-gray-500">@{user.username}</p>
                <p className="text-gray-500">ID: {user.id}</p>
              </div>

              <div className="space-y-2 text-sm">
                <div>
                  <span className="font-medium">Account Created:</span> {new Date(user.created).toLocaleDateString()}
                </div>
                <div>
                  <span className="font-medium">Last Activity:</span> {new Date(user.lastActivity).toLocaleDateString()}
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-medium">Account Status:</span>{" "}
                  <span className={user.isBanned ? "text-red-500" : "text-green-500"}>
                    {user.isBanned ? "Banned" : "Active"}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="md:col-span-2">
            <Tabs defaultValue="details">
              <TabsList className="mb-4">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="notes">Notes</TabsTrigger>
                <TabsTrigger value="punishments">Punishments</TabsTrigger>
              </TabsList>

              <TabsContent value="details">
                <Card>
                  <CardContent className="pt-6 space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="blurb">Blurb</Label>
                      <Textarea id="blurb" value={user.blurb} rows={4} />
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch id="approved" checked={!user.isBanned} />
                      <Label htmlFor="approved">Account Approved</Label>
                    </div>

                    <div className="flex justify-end">
                      <Button>Save Changes</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="notes">
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      {user.notes.map((note, index) => (
                        <div key={index} className="border-b pb-3 last:border-0">
                          <div className="flex justify-between text-sm text-gray-500 mb-1">
                            <span>{note.author}</span>
                            <span>{new Date(note.timestamp).toLocaleString()}</span>
                          </div>
                          <p>{note.text}</p>
                        </div>
                      ))}

                      <div className="pt-2">
                        <Label htmlFor="new-note">Add Note</Label>
                        <Textarea id="new-note" placeholder="Enter a new note about this user..." className="mt-1" />
                        <div className="flex justify-end mt-2">
                          <Button>Add Note</Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="punishments">
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      {user.punishments.length > 0 ? (
                        <div className="border rounded-md">
                          <table className="w-full">
                            <thead>
                              <tr className="border-b bg-gray-50">
                                <th className="px-4 py-2 text-left font-medium text-gray-500">Type</th>
                                <th className="px-4 py-2 text-left font-medium text-gray-500">Reason</th>
                                <th className="px-4 py-2 text-left font-medium text-gray-500">Expires</th>
                                <th className="px-4 py-2 text-left font-medium text-gray-500">By</th>
                              </tr>
                            </thead>
                            <tbody>
                              {user.punishments.map((punishment, index) => (
                                <tr key={index} className="border-b last:border-0">
                                  <td className="px-4 py-2">{punishment.type}</td>
                                  <td className="px-4 py-2">{punishment.reason}</td>
                                  <td className="px-4 py-2">{new Date(punishment.expires).toLocaleDateString()}</td>
                                  <td className="px-4 py-2">{punishment.author}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <p className="text-gray-500">No punishments on record</p>
                      )}

                      <div className="pt-2">
                        <Button>Add Punishment</Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      )}
    </div>
  )
}
