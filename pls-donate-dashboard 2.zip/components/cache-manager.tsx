"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"
import { AlertCircle, Loader2, RefreshCw, Trash2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export function CacheManager() {
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  // Cache statistics
  const [cacheStats, setCacheStats] = useState<{
    totalKeys: number
    keysByPrefix: Record<string, number>
    memoryUsage: string
  }>({
    totalKeys: 0,
    keysByPrefix: {},
    memoryUsage: "0 MB",
  })

  // Cache clear options
  const [clearPattern, setClearPattern] = useState<string>("games:*")
  const [isClearing, setIsClearing] = useState(false)
  const [clearDialogOpen, setClearDialogOpen] = useState(false)

  // Common cache patterns
  const cachePatterns = [
    { label: "All Game Data", value: "games:*" },
    { label: "All Store Data", value: "store:*" },
    { label: "All Leaderboard Data", value: "leaderboard:*" },
    { label: "All Ban Data", value: "bans:*" },
    { label: "All Session Data", value: "session:*" },
    { label: "All Analytics Data", value: "analytics:*" },
    { label: "All Cache", value: "*" },
  ]

  // Load cache statistics on component mount
  useEffect(() => {
    fetchCacheStats()
  }, [])

  // Fetch cache statistics from API
  const fetchCacheStats = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/cache/stats")

      if (!response.ok) {
        throw new Error("Failed to fetch cache statistics")
      }

      const data = await response.json()
      setCacheStats(data)
    } catch (error) {
      setError("Failed to load cache statistics")
      console.error(error)
    } finally {
      setIsLoading(false)
    }
  }

  // Clear cache by pattern
  const clearCache = async () => {
    setIsClearing(true)
    setError(null)

    try {
      const response = await fetch("/api/cache/clear", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          pattern: clearPattern,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to clear cache")
      }

      // Show success message
      setSuccess(`Cleared ${data.clearedKeys} cache keys matching pattern "${clearPattern}"`)

      // Close dialog
      setClearDialogOpen(false)

      // Refresh cache statistics
      fetchCacheStats()
    } catch (error) {
      setError(error.message || "Failed to clear cache")
    } finally {
      setIsClearing(false)
    }
  }

  // Clear success message after 5 seconds
  useEffect(() => {
    if (success) {
      const timer = setTimeout(() => {
        setSuccess(null)
      }, 5000)

      return () => clearTimeout(timer)
    }
  }, [success])

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
          <p className="text-gray-500">Loading cache statistics...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive" className="animate-slide-down">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-50 text-green-800 border-green-200 animate-slide-down">
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Cache Statistics</h3>
        <Button variant="outline" size="sm" onClick={fetchCacheStats}>
          <RefreshCw className="h-4 w-4 mr-1" />
          Refresh
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col items-center">
              <h4 className="text-lg font-medium mb-2">Total Keys</h4>
              <p className="text-3xl font-bold">{cacheStats.totalKeys}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col items-center">
              <h4 className="text-lg font-medium mb-2">Memory Usage</h4>
              <p className="text-3xl font-bold">{cacheStats.memoryUsage}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col items-center">
              <h4 className="text-lg font-medium mb-2">Cache Types</h4>
              <p className="text-3xl font-bold">{Object.keys(cacheStats.keysByPrefix).length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-medium">Cache by Prefix</h3>

          <Dialog open={clearDialogOpen} onOpenChange={setClearDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <Trash2 className="h-4 w-4 mr-1" />
                Clear Cache
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Clear Cache</DialogTitle>
                <DialogDescription>
                  Select a pattern to clear specific cache keys. Be careful, this action cannot be undone.
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="clear-pattern">Cache Pattern</Label>
                  <Select value={clearPattern} onValueChange={setClearPattern}>
                    <SelectTrigger id="clear-pattern">
                      <SelectValue placeholder="Select pattern" />
                    </SelectTrigger>
                    <SelectContent>
                      {cachePatterns.map((pattern) => (
                        <SelectItem key={pattern.value} value={pattern.value}>
                          {pattern.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="custom-pattern">Custom Pattern</Label>
                  <Input
                    id="custom-pattern"
                    value={clearPattern}
                    onChange={(e) => setClearPattern(e.target.value)}
                    placeholder="Enter cache pattern (e.g., games:*)"
                  />
                  <p className="text-xs text-gray-500">
                    Use * as a wildcard. For example, "games:*" will clear all game cache.
                  </p>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setClearDialogOpen(false)}>
                  Cancel
                </Button>
                <Button variant="destructive" onClick={clearCache} disabled={isClearing}>
                  {isClearing ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-1" />
                      Clearing...
                    </>
                  ) : (
                    "Clear Cache"
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <div className="border rounded-md overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 dark:bg-gray-800">
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Prefix
                </th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Keys
                </th>
                <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
              {Object.entries(cacheStats.keysByPrefix).length > 0 ? (
                Object.entries(cacheStats.keysByPrefix)
                  .sort((a, b) => b[1] - a[1]) // Sort by key count (descending)
                  .map(([prefix, count]) => (
                    <tr key={prefix} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 animate-fade-in">
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className="font-medium">{prefix}</span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">{count}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-red-500 hover:text-red-700 hover:bg-red-100"
                          onClick={() => {
                            setClearPattern(`${prefix}*`)
                            setClearDialogOpen(true)
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Clear</span>
                        </Button>
                      </td>
                    </tr>
                  ))
              ) : (
                <tr>
                  <td colSpan={3} className="px-4 py-4 text-center text-gray-500">
                    No cache keys found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
