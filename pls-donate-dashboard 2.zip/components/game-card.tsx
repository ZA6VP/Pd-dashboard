import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users } from "lucide-react"

interface GameCardProps {
  game: {
    placeId: number
    name: string
    ownerUserId: number
    groupId?: number
    lastUpdated: Date
    activePlayers: number
  }
}

export function GameCard({ game }: GameCardProps) {
  return (
    <Card className="card-hover-effect">
      <CardHeader>
        <CardTitle>{game.name}</CardTitle>
        <CardDescription>Place ID: {game.placeId}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex items-center">
          <Users className="w-4 h-4 mr-2 text-blue-500" />
          <span>{game.activePlayers.toLocaleString()} Active Players</span>
        </div>
        <p className="text-sm text-gray-500">Last Updated: {new Date(game.lastUpdated).toLocaleDateString()}</p>
        <Button asChild variant="secondary">
          <Link href={`/dashboard/games/${game.placeId}`}>View Details</Link>
        </Button>
      </CardContent>
    </Card>
  )
}
