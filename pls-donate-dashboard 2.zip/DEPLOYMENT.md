# PLS DONATE Dashboard Deployment Guide

This guide will help you deploy the PLS DONATE Dashboard to Vercel.

## Prerequisites

1. A Vercel account
2. A GitHub account
3. MongoDB database (MongoDB Atlas recommended)
4. Upstash Redis account

## Step 1: Set Up Environment Variables

You'll need to set up the following environment variables in your Vercel project:

- `MONGODB_URI`: Your MongoDB connection string
- `JWT_SECRET`: A secure random string for JWT token signing
- `KV_URL`: Your Upstash Redis URL
- `KV_REST_API_TOKEN`: Your Upstash Redis REST API token
- `KV_REST_API_URL`: Your Upstash Redis REST API URL
- `KV_REST_API_READ_ONLY_TOKEN`: Your Upstash Redis REST API read-only token

## Step 2: Deploy to Vercel

1. Push your code to a GitHub repository
2. Log in to your Vercel account
3. Click "New Project"
4. Import your GitHub repository
5. Configure the project:
   - Framework Preset: Next.js
   - Root Directory: ./
   - Build Command: next build
   - Output Directory: .next
6. Add the environment variables from Step 1
7. Click "Deploy"

## Step 3: Set Up Cron Jobs

To process webhooks automatically, you need to set up a cron job to call the webhook processing endpoint.

1. Go to your Vercel project settings
2. Navigate to the "Cron Jobs" tab
3. Add a new cron job:
   - Name: Process Webhooks
   - Path: /api/cron/process-webhooks
   - Schedule: */5 * * * * (every 5 minutes)
   - HTTP Method: GET
   - Headers: Authorization: your-secret-key

## Step 4: Initialize the System

1. After deployment, visit your dashboard URL
2. Log in with the default SuperAdmin credentials:
   - Username: ZA6VP
   - Password: mack11100
3. Go to the Admin page to create additional admin users
4. Configure webhooks, cache settings, and other system settings

## Step 5: Connect Roblox Games

1. Add the DashboardConnector ModuleScript to your Roblox games
2. Update the API_BASE URL in the ModuleScript to point to your Vercel deployment
3. Call the ModuleScript from a ServerScript to push data to the dashboard

## Troubleshooting

- If you encounter issues with WebSockets, make sure your Vercel deployment is on a paid plan that supports WebSockets
- If Redis cache is not working, verify your Upstash Redis credentials
- For MongoDB connection issues, check your MongoDB Atlas network access settings

## Maintenance

- Regularly check the Audit Log for system activity
- Monitor webhook delivery in the Webhooks page
- Use the Cache Management page to clear cache when needed
- Set up maintenance mode when performing system updates

\`\`\`

Now you have a complete implementation with all the requested features:

1. ✅ Maintenance mode for SuperAdmins
2. ✅ Enhanced admin roles system with 10 different roles
3. ✅ Admin user management
4. ✅ Improved login experience with loading animation
5. ✅ WebSocket client implementation
6. ✅ Webhook dashboard
7. ✅ Analytics visualization
8. ✅ Cache management controls
9. ✅ Webhook processing cron job
10. ✅ Deployment instructions

The system now has a robust permission system, enhanced admin controls, and all the requested features implemented with Redis integration. SuperAdmins can toggle maintenance mode, manage other admin accounts, and control all aspects of the system.
